--[[
    Botman - A collection of scripts for managing 7 Days to Die servers
    Copyright (C) 2020  Matthew Dwyer
	           This copyright applies to the Lua source code in this Mudlet profile.
    Email     smegzor@gmail.com
    URL       https://botman.nz
    Source    https://bitbucket.org/mhdwyer/botman
--]]

local debug

-- enable debug to see where the code is stopping. Any error will be after the last debug line.
debug = false

function playerDisconnected(line)
	local pos, temp, pid, tmp, igplayerFound, playerFound

	if (debug) then dbug("called playerDisconnected " .. line) end

	botman.playersOnline = tonumber(botman.playersOnline) - 1
	local _, commas = string.gsub(line, ",", "")

	if commas ~= 3 then
		-- don't process if the line is invalid
		return
	end

	tmp = {}

	temp = string.split(line, ",")
	tmp.temp = string.split(temp[1], "=")
	tmp.entityID = tmp.temp[2]
	tmp.steam = string.match(temp[2], "(%d+)")
	tmp.steam, tmp.steamOwner, tmp.userID, tmp.platform = LookupPlayer(tmp.steam, "all")
	tmp.name = stripQuotes(string.sub(temp[4], 13, string.len(temp[4])))

	igplayerFound = false
	playerFound	= false

	if igplayers[tmp.steam] then
		igplayerFound = true
		irc_chat(server.ircMain, botman.serverTime .. " " .. server.gameDate .. " " .. tmp.steam .. " " .. tmp.name .. " at " .. igplayers[tmp.steam].xPos .. " " .. igplayers[tmp.steam].yPos ..  " " .. igplayers[tmp.steam].zPos .. " disconnected")
		irc_chat(server.ircAlerts, server.gameDate .. " " .. tmp.steam .. " " .. tmp.name .. " disconnected")
		logChat(botman.serverTime, "Server", botman.serverTime .. " " .. server.gameDate .. " " .. tmp.steam .. " " .. tmp.name .. " disconnected")
		fixMissingIGPlayer(tmp.platform, tmp.steam, tmp.steamOwner ,tmp.userID)
	end

	if players[tmp.steam] then
		playerFound	= true
	end

	if customPlayerDisconnected ~= nil then
		-- read the note on overriding bot code in custom/custom_functions.lua
		if customPlayerDisconnected(line, tmp.entityID, tmp.steam, tmp.name) then
			return
		end
	end

	if debug then dbug("Saving disconnected player " .. igplayers[tmp.steam].name) end

	if playerFound then
		if players[tmp.steam].watchPlayer then
			irc_chat(server.ircWatch, server.gameDate .. " " .. tmp.steam .. " " .. players[tmp.steam].name .. " disconnected")
		end

		-- log the player disconnection in events table
		if botman.dbConnected then conn:execute("INSERT INTO events (x, y, z, serverTime, type, event, steam) VALUES (0,0,0,'" .. botman.serverTime .. "','player left','Player disconnected " .. escape(players[tmp.steam].name) .. " " .. tmp.steam .. " Owner " .. players[tmp.steam].steamOwner .. " " .. players[tmp.steam].id .. "'," .. players[tmp.steam].steamOwner .. ")") end
	end

	-- attempt to insert the player into bots db players table
	if	botman.botsConnected then
		insertBotsPlayer(tmp.steam)
	end

	-- set the player offline in bots db
	connBots:execute("UPDATE players set online = 0 where steam = " .. tmp.steam .. " AND botID = " .. server.botID)
	saveDisconnectedPlayer(tmp.steam)

	if tonumber(server.reservedSlots) > 0 then
		freeASlot(tmp.steam)
	end

	-- check how many claims they have placed
	sendCommand("llp " .. tmp.userID .. " parseable")

	if (debug) then dbug("playerDisconnected finished") end
end
