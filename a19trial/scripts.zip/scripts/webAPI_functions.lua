--[[
    Botman - A collection of scripts for managing 7 Days to Die servers
    Copyright (C) 2020  Matthew Dwyer
	           This copyright applies to the Lua source code in this Mudlet profile.
    Email     smegzor@gmail.com
    URL       https://botman.nz
    Source    https://bitbucket.org/mhdwyer/botman
--]]

-- enable debug to see where the code is stopping. Any error will be after the last debug line.
local debug = false -- should be false unless testing
--if debug thendbug("debug webAPI_functions line " .. debugger.getinfo(1).currentline) end


function getAPILogUpdates()
	url = "http://" .. server.IP .. ":" .. server.webPanelPort + 2 .. "/api/getwebuiupdates?adminuser=bot&admintoken=" .. server.allocsWebAPIPassword
	os.remove(homedir .. "/temp/webUIUpdates.txt")
	downloadFile(homedir .. "/temp/webUIUpdates.txt", url)
end


function getAPILog()
	url = "http://" .. server.IP .. ":" .. server.webPanelPort + 2 .. "/api/getlog?firstline=" .. botman.lastLogLine .. "&adminuser=bot&admintoken=" .. server.allocsWebAPIPassword
	os.remove(homedir .. "/temp/log.txt")
	downloadFile(homedir .. "/temp/log.txt", url)
end


function getBMFriends(steam, data)
	local k, v, pid

	-- delete auto-added friends from the MySQL table
	if botman.dbConnected then conn:execute("DELETE FROM friends WHERE steam = " .. steam .. " AND autoAdded = 1") end

	if data == "" then
		return
	end

	for k,v in pairs(data) do
		pid = string.sub(v, 1, 17)

		-- add friends read from bm-listplayerfriends
		if not string.find(friends[steam].friends, pid) then
			addFriend(steam, pid, true)
		end
	end
end


function readAPI_AdminList()
	local file, ln, result, data, index, count, temp, level, steam, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/adminList.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	--flagAdminsForRemoval()
	file = io.open(homedir .. "/temp/adminList.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)
		count = table.maxn(data)

		for con, q in pairs(conQueue) do
			if q.command == "admin list" then
				irc_chat(q.ircUser, data[1])
				irc_chat(q.ircUser, data[2])
			end
		end

		if data[3] == "" then
			botman.noAdminsDefined = true
		else
			botman.noAdminsDefined = false

			for index=3, count-1, 1 do
				temp = string.split(data[index], ":")
				temp[1] = string.trim(temp[1])
				temp[2] = string.trim(temp[2])
				level = tonumber(temp[1])
				steam = string.trim(string.sub(temp[2], 1, 18))

				if tonumber(steam) > 0 then
					-- add the steamid to the staffList table
					staffList[steam] = {}
					staffList[steam].adminLevel = tonumber(level)

					if players[steam] then
						players[steam].accessLevel = tonumber(level)
						players[steam].newPlayer = false
						players[steam].silentBob = false
						players[steam].walkies = false
						players[steam].timeout = false
						players[steam].prisoner = false
						players[steam].exiled = false
						players[steam].canTeleport = true
						players[steam].botHelp = true
						players[steam].hackerScore = 0
						players[steam].testAsPlayer = nil

						if botman.dbConnected then conn:execute("UPDATE players SET newPlayer = 0, silentBob = 0, walkies = 0, exiled = 0, canTeleport = 1, botHelp = 1, accessLevel = " .. level .. " WHERE steam = " .. steam) end
						if botman.dbConnected then conn:execute("INSERT INTO staff (steam, adminLevel) VALUES (" .. steam .. "," .. level .. ") ON DUPLICATE KEY UPDATE adminLevel = " .. level) end

						if players[steam].botTimeout and igplayers[steam] then
							gmsg(server.commandPrefix .. "return " .. v.name)
						end
					end
				end

				for con, q in pairs(conQueue) do
					if q.command == "admin list" then
						irc_chat(q.ircUser, data[index])
					end
				end
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == "admin list" then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/adminList.txt")

	if botman.noAdminsDefined then
		irc_chat(server.ircMain, "ALERT!  There are no admins defined in the admin list!")
	end
end


function readAPI_BanList()
	local file, ln, result, data, k, v, temp, con, q
	local bannedTo, steam, reason
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/banList.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		--botman.resendBanList = true
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/banList.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if k > 2 and v ~= "" then
				if v ~= "" then
					temp = string.split(v, " - ")

					bannedTo = string.trim(temp[3] .. " " .. temp[4])
					steam = string.trim(temp[6])
					reason = ""

					if temp[8] then
						reason = string.trim(temp[8])
					end

					if botman.dbConnected then
						conn:execute("INSERT INTO bans (BannedTo, steam, reason, expiryDate) VALUES ('" .. bannedTo .. "'," .. steam .. ",'" .. escape(reason) .. "',STR_TO_DATE('" .. bannedTo .. "', '%Y-%m-%d %H:%i:%s'))")
					end

					for con, q in pairs(conQueue) do
						if q.command == "ban list" then
							irc_chat(q.ircUser, data[k])
						end
					end
				end
			else
				for con, q in pairs(conQueue) do
					if q.command == "ban list" then
						irc_chat(q.ircUser, data[k])
					end
				end
			end
		end

	end

	file:close()
	loadBans()

	for con, q in pairs(conQueue) do
		if q.command == "ban list" then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/banList.txt")
end


function readAPI_BMAnticheatReport()
	local file, ln, result, data, tmp, temp, k, v
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/bm-anticheat-report.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/bm-anticheat-report.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" and v ~= "End Report" then
				if string.find(v, "--NAME") and (not string.find(line, "unauthorized locked container")) then
					tmp = {}
					tmp.name = string.sub(v, string.find(v, "-NAME:") + 6, string.find(v, "--ID:") - 2)
					tmp.id = string.sub(v, string.find(v, "-ID:") + 4, string.find(v, "--LVL:") - 2)
					tmp.reason = "hacking"
					tmp.hack = ""
					tmp.level = string.sub(v, string.find(v, "-LVL:") + 5)
					tmp.level = string.match(tmp.level, "(-?%d+)")
					tmp.alert = string.sub(v, string.find(v, "-LVL:") + 5)
					tmp.alert = string.sub(tmp.alert, string.find(tmp.alert, " ") + 1)

					if (not staffList[tmp.id]) and (not players[tmp.id].testAsPlayer) and (not bans[tmp.id]) and (not anticheatBans[tmp.id]) then
						if string.find(v, " spawned ") then
							temp = string.split(tmp.alert, " ")
							tmp.entity = stripQuotes(temp[3])
							tmp.x = string.match(temp[4], "(-?\%d+)")
							tmp.y = string.match(temp[5], "(-?\%d+)")
							tmp.z = string.match(temp[6], "(-?\%d+)")
							tmp.hack = "spawned " .. tmp.entity .. " at " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z

							if tonumber(tmp.level) > 2 then
								irc_chat(server.ircMain, "ALERT! Unauthorised admin detected. Player " .. tmp.name .. " Steam: " .. tmp.id .. " Permission level: " .. tmp.level .. " " .. tmp.alert)
								irc_chat(server.ircAlerts, "ALERT! Unauthorised admin detected. Player " .. tmp.name .. " Steam: " .. tmp.id .. " Permission level: " .. tmp.level .. " " .. tmp.alert)
							end
						else
							tmp.x = players[tmp.id].xPos
							tmp.y = players[tmp.id].yPos
							tmp.z = players[tmp.id].zPos
							tmp.hack = "using dm at " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z

							if tonumber(tmp.level) > 2 then
								irc_chat(server.ircMain, "ALERT! Unauthorised admin detected. Player " .. tmp.name .. " Steam: " .. tmp.id .. " Permission level: " .. tmp.level .. " " .. tmp.alert)
								irc_chat(server.ircAlerts, "ALERT! Unauthorised admin detected. Player " .. tmp.name .. " Steam: " .. tmp.id .. " Permission level: " .. tmp.level .. " " .. tmp.alert)
							end
						end

						if tonumber(tmp.level) > 2 then
							anticheatBans[tmp.id] = {}
							banPlayer(tmp.id, "10 years", tmp.reason, "")
							logHacker(botman.serverTime, "Botman anticheat detected " .. tmp.id .. " " .. tmp.name .. " " .. tmp.hack)
							message("say [" .. server.chatColour .. "]Banning player " .. tmp.name .. " 10 years for using hacks.[-]")
							irc_chat("#hackers", "[BANNED] Player " .. tmp.id .. " " .. tmp.name .. " has been banned for hacking by anticheat.")
							irc_chat("#hackers", v)
						end
					end
				end
			end
		end
	end

	file:close()
	os.remove(homedir .. "/temp/bm-anticheat-report.txt")
end


function readAPI_BMUptime()
	local file, ln, result, data, temp, tmp
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/bm-uptime.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/bm-uptime.txt", "r")

	for ln in file:lines() do
		temp = string.split(ln, ":")

		-- hours
		tmp  = tonumber(string.match(temp[4], "(%d+)"))
		server.uptime = tmp * 60 * 60

		-- minutes
		tmp  = tonumber(string.match(temp[5], "(%d+)"))
		server.uptime = server.uptime + (tmp * 60)

		-- seconds
		tmp  = tonumber(string.match(temp[6], "(%d+)"))
		server.uptime = server.uptime + tmp
		server.serverStartTimestamp = os.time() - server.uptime
	end

	file:close()
	os.remove(homedir .. "/temp/bm-uptime.txt")
end


function readAPI_BMListPlayerBed()
	local file, ln, result, data, temp, pname, pid, x, y, z, i
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/bm-listplayerbed.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/bm-listplayerbed.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" then
				if not string.find(v, "The player") then
					temp = string.split(v, ": ")
					pname = temp[1]

					temp = string.split(v, ", ")
					i = table.maxn(temp)

					x = temp[i - 2]
					x = string.split(x, " ")
					x = x[table.maxn(x)]

					y = temp[i - 1]
					z = temp[i]

					pid = LookupPlayer(pname, "all")
					players[pid].bedX = x
					players[pid].bedY = y
					players[pid].bedZ = z

					if botman.dbConnected then conn:execute("UPDATE players SET bedX = " .. x .. ", bedY = " .. y .. ", bedZ = " .. z.. " WHERE steam = " .. pid) end
				else
					pid = string.sub(v, 11, string.find(v, " does ") - 1)
					players[pid].bedX = 0
					players[pid].bedY = 0
					players[pid].bedZ = 0
					if botman.dbConnected then conn:execute("UPDATE players SET bedX = 0, bedY = 0, bedZ = 0 WHERE steam = " .. pid) end
				end
			end
		end
	end

	file:close()
	os.remove(homedir .. "/temp/bm-listplayerbed.txt")
end


function readAPI_BMListPlayerFriends()
	local file, ln, result, data, temp, pname, pid, k, v
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/bm-listplayerfriends.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/bm-listplayerfriends.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			pid = string.sub(v, 15,31)
			temp=string.sub(v, string.find(v, "Friends=") + 8)

			if temp ~= "" then
				temp = string.split(temp, ",")
			end

			getBMFriends(pid, temp)
		end
	end

	file:close()
	os.remove(homedir .. "/temp/bm-listplayerfriends.txt")
end


function readAPI_BMReadConfig()

	local file, ln, result, data, fileSize, k, v

	fileSize = lfs.attributes (homedir .. "/temp/bm-config.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	botman.config = {}
	file = io.open(homedir .. "/temp/bm-config.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if q.command == "bm-readconfig" then
					irc_chat(q.ircUser, v)
				end
			end

			table.insert(botman.config, v)
		end

		processBotmanConfig()
	end

	file:close()
	os.remove(homedir .. "/temp/bm-config.txt")

	for con, q in pairs(conQueue) do
		if q.command == "bm-readconfig" then
			conQueue[con] = nil
		end
	end
end


function readAPI_BMResetRegionsList()
	local file, ln, result, data, temp, x, z, fileSize, k, v

	fileSize = lfs.attributes (homedir .. "/temp/bm-resetregions-list.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	for k,v in pairs(resetRegions) do
		v.inConfig = false
	end

	file = io.open(homedir .. "/temp/bm-resetregions-list.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if q.command == "bm-resetregions list" then
					irc_chat(q.ircUser, v)
				end
			end

			if string.find(v, "r.", nil, true) then
				temp = string.split(v, "%.")
				x = temp[2]
				z = temp[3]

				if not resetRegions[v .. ".7rg"] then
					resetRegions[v .. ".7rg"] = {}
				end

				resetRegions[v .. ".7rg"].x = x
				resetRegions[v .. ".7rg"].z = z
				resetRegions[v .. ".7rg"].inConfig = true
				conn:execute("INSERT INTO resetZones (region, x, z) VALUES ('" .. escape(v .. ".7rg") .. "'," .. x .. "," .. z .. ")")
			end
		end
	end

	file:close()
	os.remove(homedir .. "/temp/bm-resetregions-list.txt")

	for con, q in pairs(conQueue) do
		if q.command == "bm-resetregions list" then
			conQueue[con] = nil
		end
	end

	-- for k,v in pairs(resetRegions) do
		-- if not v.inConfig then
			-- sendCommand("bm-resetregions add " .. v.x .. "." .. v.z)
		-- end
	-- end

	tempTimer(3, [[loadResetZones(true)]])
end


function readAPI_Command()
	local file, ln, result, curr, totalPlayersOnline, temp, data, k, v, getData
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/command.txt", "size")

	-- abort if the file is empty and switch back to using telnet
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/command.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		for con, q in pairs(conQueue) do
			if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
				if string.find(result.result, "\n") then
					data = splitCRLF(result.result)

					for k,v in pairs(data) do
						irc_chat(q.ircUser, data[k])
					end
				else
					irc_chat(q.ircUser, result.result)
				end
			end
		end

		if string.find(result.command, "admin") and not string.find(result.command, "list") then
			tempTimer( 2, [[sendCommand("admin list")]] )
		end

		if string.sub(result.result, 1, 4) == "Day " then
			gameTimeTrigger(stripMatching(result.result, "\\r\\n"))
			gameTimeTrigger(stripMatching(result.result, "\\n"))
			file:close()
			return
		end

		if string.sub(result.command, 1, 3) == "sg " then
			result.result = stripMatching(result.result, "\\r\\n")
			result.result = stripMatching(result.result, "\\n")
			matchAll(result.result)
			file:close()
			return
		end

		if result.parameters == "bot_RemoveInvalidItems" then
			removeInvalidItems()
			file:close()
			return
		end

		if string.find(result.parameters, "LagCheck") then
			matchAll("pm " .. result.parameters)
			file:close()
			return
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/command.txt")
end


function readAPI_GetServerInfo()  -- not finished.  May not need as gg already works fine.
	local file, ln, result, data, k, v, con, q, gg
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/getserverinfo.txt", "size")

end


function readAPI_GG()
	local file, ln, result, data, k, v, con, q, gg
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/gg.txt", "size")
	GamePrefs = {}

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		--botman.resendGG = true
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/gg.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		botman.readGG = true

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if q.command == "gg" then
					irc_chat(q.ircUser, data[k])
				end
			end

			if v ~= "" then
				matchAll(v)
			end
		end

		botman.readGG = false
	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == "gg" then
			conQueue[con] = nil
		end
	end

	if botman.dbConnected then conn:execute("INSERT INTO webInterfaceJSON (ident, recipient, json) VALUES ('GamePrefs','panel','" .. escape(yajl.to_string(GamePrefs)) .. "')") end

	os.remove(homedir .. "/temp/gg.txt")
	initSlots()
end


function readAPI_GT()
	local file, ln, result, data, k, v, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/gametime.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/gametime.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if q.command == "gt" then
					irc_chat(q.ircUser, data[k])
				end
			end

			if v ~= "" then
				gameTimeTrigger(v)
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == "gt" then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/gametime.txt")
end


function readAPI_Help()
	local file, ln, result, data, k, v, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/help.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/help.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if string.find(q.command, "help") then
					irc_chat(q.ircUser, v)
				end
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if string.find(q.command, "help") then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/help.txt")
end


function readAPI_Inventories()
	if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

	local file, ln, result, data, k, v, index, count, steam, playerName
	local slot, quantity, quality, itemName
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/inventories.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

	file = io.open(homedir .. "/temp/inventories.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		count = table.maxn(result)

		--if debug then display(result) end

		for index=1, count, 1 do
			if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

			steam = result[index].steamid
			playerName = result[index].playername

			if (debug) then
				dbug("steam = " .. steam)
				dbug("playerName = " .. playerName)
			end

			if (igplayers[steam].inventoryLast ~= igplayers[steam].inventory) then
				igplayers[steam].inventoryLast = igplayers[steam].inventory
			end

			igplayers[steam].inventory = ""
			igplayers[steam].oldBelt = igplayers[steam].belt
			igplayers[steam].belt = ""
			igplayers[steam].oldPack = igplayers[steam].pack
			igplayers[steam].pack = ""
			igplayers[steam].oldEquipment = igplayers[steam].equipment
			igplayers[steam].equipment = ""

			for k,v in pairs(result[index].belt) do
				if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

				if v ~= "" then
					slot = k

					if type(v) == "table" then
						quantity = v.count
						quality = v.quality
						itemName = v.name

						igplayers[steam].inventory = igplayers[steam].inventory .. quantity .. "," .. itemName .. "," .. quality .. "|"
						igplayers[steam].belt = igplayers[steam].belt .. slot .. "," .. quantity .. "," .. itemName .. "," .. quality .. "|"
					end
				end
			end

			for k,v in pairs(result[index].bag) do
				if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

				if v ~= "" then
					slot = k

					if type(v) == "table" then
						quantity = v.count
						quality = v.quality
						itemName = v.name

						igplayers[steam].inventory = igplayers[steam].inventory .. quantity .. "," .. itemName .. "," .. quality .. "|"
						igplayers[steam].pack = igplayers[steam].pack .. slot .. "," .. quantity .. "," .. itemName .. "," .. quality .. "|"
					end
				end
			end

			for k,v in pairs(result[index].equipment) do
				if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

				if v ~= "" then
					slot = k

					if type(v) == "table" then
						quality = v.quality
						itemName = v.name
						igplayers[steam].equipment = igplayers[steam].equipment .. slot .. "," .. itemName .. "," .. quality .. "|"
					end
				end
			end

			if debug then
				dbug("belt = " .. igplayers[steam].belt)
				dbug("bag = " .. igplayers[steam].pack)
				dbug("inventory = " .. igplayers[steam].equipment)
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

	CheckInventory()
	os.remove(homedir .. "/temp/inventories.txt")
end


function readAPI_Hostiles()
	local file, ln, result, temp, data, k, v, cursor, errorString
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/hostiles.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	end

	botman.lastServerResponseTimestamp = os.time()
	file = io.open(homedir .. "/temp/hostiles.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		for k,v in pairs(result) do
			if v ~= "" then
				loc = inLocation(v.position.x, v.position.z)

				if loc ~= false then
					if locations[loc].killZombies then
						removeEntityCommand(v.id)
					end
				end
			end
		end
	end

	file:close()
	os.remove(homedir .. "/temp/hostiles.txt")
end


function readAPI_LE()
	local file, ln, result, temp, data, k, v, entityID, entity, cursor, errorString,  con, q, tmp
	local fileSize, i

	fileSize = lfs.attributes (homedir .. "/temp/le.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	if botman.dbConnected then
		connMEM:execute("DELETE FROM entities")
	end

	file = io.open(homedir .. "/temp/le.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		if string.find(result.result, "\n") then
			data = splitCRLF(result.result)

			for k,v in pairs(data) do
				if string.find(data[k], "id=") then
					listEntities(data[k])
				end
			end
		end

	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == result.command then
			if string.find(result.result, "\n") then
				for k,v in pairs(data) do
					irc_chat(q.ircUser, data[k])
				end
			else
				irc_chat(q.ircUser, result.result)
			end
		end
	end

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/le.txt")
end


function readAPI_LKP()
	local file, ln, result, temp, data, k, v, cursor, errorString
	local name, gameID, steamID, IP, playtime, seen, p1, p2
	local pattern = "(%d+)-(%d+)-(%d+) (%d+):(%d+)"
	local runyear, runmonth, runday, runhour, runminute, seenTimestamp, tmp
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/lkp.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/lkp.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" then
				if string.sub(v, 1, 5) ~= "Total" then
					if botman.dbConnected then
						connSQL:execute("INSERT INTO LKPQueue (line) VALUES ('" .. escape(v) .. "')")
					end

					-- gather the data for the current player
					temp = string.split(v, ", ")

					if temp[3] ~= nil then
						steamID = string.match(temp[3], "=(-?%d+)")

						if players[steamID] then
							players[steamID].notInLKP = false
						end
					end
				end

				for con, q in pairs(conQueue) do
					if q.command == "lkp" then
						irc_chat(q.ircUser, data[k])
					end
				end
			end
		end

		if result.parameters ~= "-online" and botman.archivePlayers then
			botman.archivePlayers = nil

			--	Everyone who is flagged notInLKP gets archived.
			for k,v in pairs(players) do
				if v.notInLKP then
					if botman.dbConnected then connSQL:execute("INSERT INTO miscQueue (steam, command) VALUES ('" .. k .. "', 'archive player')") end
				end
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == "lkp" then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/lkp.txt")
end


function readAPI_LI()
	local file, ln, result, temp, data, k, v, entityID, entity, cursor, errorString, con, q
	local fileSize, updateItemsList

	fileSize = lfs.attributes (homedir .. "/temp/li.txt", "size")
	updateItemsList = false
	spawnableItems = {}

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/li.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		if result.parameters == "*" then
			updateItemsList = true
		end

		if string.find(result.result, "\n") then
			data = splitCRLF(result.result)

			for k,v in pairs(data) do
				if not string.find(data[k], " matching items.") then
					if botman.dbConnected then
						temp = string.trim(data[k])
						if temp ~= "" and updateItemsList then
							--conn:execute("INSERT INTO spawnableItems (itemName) VALUES ('" .. escape(temp) .. "')")
							spawnableItems[temp] = {}
						end
					end
				end
			end
		end

		for con, q in pairs(conQueue) do
			if string.sub(q.command, 1, 3) == "li " then
				if string.find(result.result, "\n") then
					for k,v in pairs(data) do
						temp = string.trim(data[k])
						irc_chat(q.ircUser, temp)
					end
				else
					irc_chat(q.ircUser, result.result)
				end
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	if updateItemsList then
		removeInvalidItems()
		spawnableItems = {}
		tempTimer(3, [[loadShop()]])
	end

	os.remove(homedir .. "/temp/li.txt")
end


function readAPI_LLP()
	local file, ln, result, temp, coords, data, k, v, a, b, cursor, errorString, con, q
	local steam, x, y, z, keystoneCount, region, loc, reset, expired, noPlayer, archived
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/llp.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	end

	botman.lastServerResponseTimestamp = os.time()
	connSQL:execute("DELETE FROM keystones WHERE x = 0 AND y = 0 AND z = 0")

	file = io.open(homedir .. "/temp/llp.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		for con, q in pairs(conQueue) do
			if string.find(q.command, result.command) then
				if string.find(result.result, "\n") then
					data = splitCRLF(result.result)

					for k,v in pairs(data) do
						irc_chat(q.ircUser, data[k])
					end
				else
					irc_chat(q.ircUser, result.result)
				end
			end
		end

		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" then
				temp = splitCRLF(v)

				for a,b in pairs(temp) do
					if string.find(b, "Player ") then
						steam = string.sub(b, 9, string.find(b, ')\"') - 1)
						steam = string.sub(steam, - 17)
						noPlayer = true
						archived = false

						if string.find(b, "protected: True", nil, true) then
							expired = false
						end

						if string.find(b, "protected: False", nil, true) then
							expired = true
						end

						if players[steam] then
							noPlayer = false

							if players[steam].removedClaims == nil then
								players[steam].removedClaims = 0
							end
						end

						if playersArchived[steam] then
							noPlayer = false
							archived = true

							if playersArchived[steam].removedClaims == nil then
								playersArchived[steam].removedClaims = 0
							end
						end
					end

					if string.find(b, "owns ") and string.find(b, " keystones") then
						keystoneCount = string.sub(b, string.find(b, "owns ") + 5, string.find(b, " keystones") - 1)
						if not noPlayer then
							if not archived then
								players[steam].keystones = keystoneCount
							else
								playersArchived[steam].keystones = keystoneCount
							end
						end
					end

					if string.find(b, "location") then
						b = string.sub(b, string.find(b, "location") + 9)
						claimRemoved = false

						coords = string.split(b, ",")
						x = tonumber(coords[1])
						y = tonumber(coords[2])
						z = tonumber(coords[3])

						if tonumber(y) > 0 then
							if botman.dbConnected then
								connSQL:execute("UPDATE keystones SET removed = 0 WHERE steam = '" .. steam .. "' AND x = " .. x .. " AND y = " .. y .. " AND z = " .. z)
							end

							-- if not keystones[x .. y .. z] then
								-- keystones[x .. y .. z] = {}
								-- keystones[x .. y .. z].x = x
								-- keystones[x .. y .. z].y = y
								-- keystones[x .. y .. z].z = z
								-- keystones[x .. y .. z].steam = steam
							-- end

							-- keystones[x .. y .. z].expired = players[steam].claimsExpired
							-- keystones[x .. y .. z].removed = 0
							-- keystones[x .. y .. z].remove = false

							if not noPlayer then
								if not archived then
									if players[steam].removeClaims or (expired and server.removeExpiredClaims) then
										keystones[x .. y .. z].remove = true
									end
								else
									if playersArchived[steam].removeClaims or (expired and server.removeExpiredClaims) then
										keystones[x .. y .. z].remove = true
									end
								end
							else
								if expired and server.removeExpiredClaims then
									keystones[x .. y .. z].remove = true
								end
							end

							if not isAdmin(steam) then
								region = getRegion(x, z)
								loc, reset = inLocation(x, z)

								if not noPlayer then
									if not archived then
										if (resetRegions[region] or reset or players[steam].removeClaims) and not players[steam].testAsPlayer then
											claimRemoved = true
											if botman.dbConnected then connSQL:execute("INSERT INTO persistentQueue (steam, command, timerDelay) VALUES ('" .. steam .. "','" .. connMEM:escape("rlp " .. x .. " " .. y .. " " .. z) .. "','" .. os.time() + 5 .. "')") end
										else
											if botman.dbConnected then connSQL:execute("INSERT INTO keystones (steam, x, y, z, expired) VALUES ('" .. steam .. "'," .. x .. "," .. y .. "," .. z .. "," .. dbBool(expired) .. ")") end
										end
									else
										if (resetRegions[region] or reset or playersArchived[steam].removeClaims) and not playersArchived[steam].testAsPlayer then
											claimRemoved = true
											if botman.dbConnected then connSQL:execute("INSERT INTO persistentQueue (steam, command, timerDelay) VALUES ('" .. steam .. "','" .. connMEM:escape("rlp " .. x .. " " .. y .. " " .. z) .. "','" .. os.time() + 5 .. "')") end
										else
											if botman.dbConnected then connSQL:execute("INSERT INTO keystones (steam, x, y, z, expired) VALUES ('" .. steam .. "'," .. x .. "," .. y .. "," .. z .. "," .. dbBool(expired) .. ")") end
										end
									end
								else
									if (resetRegions[region] or reset) and server.removeExpiredClaims then
										claimRemoved = true
										if botman.dbConnected then connSQL:execute("INSERT INTO persistentQueue (steam, command, timerDelay) VALUES ('" .. steam .. "','" .. connMEM:escape("rlp " .. x .. " " .. y .. " " .. z) .. "','" .. os.time() + 5 .. "')") end
									else
										if botman.dbConnected then connSQL:execute("INSERT INTO keystones (steam, x, y, z, expired) VALUES ('" .. steam .. "'," .. x .. "," .. y .. "," .. z .. "," .. dbBool(expired) .. ")") end
									end
								end
							else
								if botman.dbConnected then connSQL:execute("INSERT INTO keystones (steam, x, y, z, expired) VALUES ('" .. steam .. "'," .. x .. "," .. y .. "," .. z .. "," .. dbBool(expired) .. ")") end
							end

							if not claimRemoved then
								if not keystones[x .. y .. z] then
									keystones[x .. y .. z] = {}
									keystones[x .. y .. z].x = x
									keystones[x .. y .. z].y = y
									keystones[x .. y .. z].z = z
									keystones[x .. y .. z].steam = steam
								end

								keystones[x .. y .. z].removed = 0
								keystones[x .. y .. z].remove = false

								if archived then
									keystones[x .. y .. z].expired = playersArchived[steam].claimsExpired
								else
									if not noPlayer then
										keystones[x .. y .. z].expired = players[steam].claimsExpired
									else
										keystones[x .. y .. z].expired = true
									end
								end
							end
						end
					end
				end
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/llp.txt")
end


function readAPI_LPF()
	local file, ln, result, data, k, v, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/lpf.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	end

	botman.lastServerResponseTimestamp = os.time()
	file = io.open(homedir .. "/temp/lpf.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if string.sub(q.command, 1, 3) == "lpf" then
					irc_chat(q.ircUser, data[k])
				end
			end

			if not string.find(v, "Player") and v ~= "" then
				getFriends(v)
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/lpf.txt")
end


function readAPI_PlayersOnline()
	local file, ln, result, index, totalPlayersOnline, con, q
	local fileSize, k, v, lpdata, success, errorMessage

	fileSize = lfs.attributes (homedir .. "/temp/playersOnline.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/playersOnline.txt", "r")
	playersOnlineList = {}

	if botman.trackingTicker == nil then
		botman.trackingTicker = 0
	end

	botman.trackingTicker = botman.trackingTicker + 1

	for ln in file:lines() do
		result = yajl.to_value(ln)

		if result == "[]" then
			botman.playersOnline =	0
		else
			botman.playersOnline = table.maxn(result)
		end

		for index=1, botman.playersOnline, 1 do
			lpdata = {}
			lpdata.steam = result[index].steamid
			lpdata.entityid = result[index].entityid
			lpdata.score = result[index].score
			lpdata.zombiekills = result[index].zombiekills
			lpdata.level = math.floor(result[index].level)
			lpdata.playerdeaths = result[index].playerdeaths
			lpdata.ping = result[index].ping
			lpdata.ip = result[index].ip
			lpdata.name = result[index].name
			lpdata.playerkills = result[index].playerkills
			lpdata.x = result[index].position.x
			lpdata.y = result[index].position.y
			lpdata.z = result[index].position.z
			lpdata.rawPosition = lpdata.x .. lpdata.y .. lpdata.z

			playersOnlineList[lpdata.steam] = {}
			playersOnlineList[lpdata.steam].faulty = false

			success, errorMessage = pcall(playerInfo, lpdata)

			if not success then
				windowMessage(server.windowDebug, "!! Fault detected in playerinfo\n")
				windowMessage(server.windowDebug, "Last debug line " .. playersOnlineList[lpdata.steam].debugLine .. "\n")
				windowMessage(server.windowDebug, "Faulty player " .. lpdata.steam .. " " .. lpdata.name ..  "\n")
				windowMessage(server.windowDebug, ln .. "\n")
				windowMessage(server.windowDebug, "----------\n")

				playersOnlineList[lpdata.steam].faulty = true
				fixMissingPlayer(lpdata.steam)
				fixMissingIGPlayer(lpdata.steam)
			end

			for con, q in pairs(conQueue) do
				if q.command == "lp" then
					irc_chat(q.ircUser, data[k])
				end
			end
		end
	end

	if tonumber(botman.trackingTicker) > 2 then
		botman.trackingTicker = 0
	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == "lp" then
			conQueue[con] = nil
		end
	end

	for k,v in pairs(igplayers) do
		if not playersOnlineList[k] then
			v.killTimer = 2
		end
	end

	if botman.initReservedSlots then
		initSlots()
		botman.initReservedSlots = false
	end

	os.remove(homedir .. "/temp/playersOnline.txt")
end


function readAPI_PGD()
	local file, ln, result, data, k, v
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/pgd.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	end

	botman.lastServerResponseTimestamp = os.time()
	file = io.open(homedir .. "/temp/pgd.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" then
				matchAll(v)
			end
		end

	end

	file:close()
	os.remove(homedir .. "/temp/pgd.txt")
end


function readAPI_PUG()
	local file, ln, result, data, k, v
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/pug.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	end

	botman.lastServerResponseTimestamp = os.time()
	file = io.open(homedir .. "/temp/pug.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" then
				matchAll(v)
			end
		end

	end

	file:close()
	os.remove(homedir .. "/temp/pug.txt")
end


function writeAPILog(line)
	-- log the chat
	file = io.open(homedir .. "/telnet_logs/" .. os.date("%Y_%m_%d") .. "_API_log.txt", "a")
	file:write(botman.serverTime .. "; " .. string.trim(line) .. "\n")
	file:close()
end


function readAPI_ReadLog()
	local file, fileSize, ln, result, temp, data, k, v
	local uptime, date, time, msg, handled, skipLog

	fileSize = lfs.attributes (homedir .. "/temp/log.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/log.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		for k,v in pairs(result.entries) do
			msg = v.msg

			uptime = v.uptime
			date = v.date
			time = v.time

			skipLog = false
			handled = false

			-- do some wibbly-wobbly timey-wimey stuff
			botman.serverTime = date .. " " .. time
			botman.serverTimeStamp = dateToTimestamp(botman.serverTime)

			if not botman.serverTimeSync then
				botman.serverTimeSync = 0
			end

			if botman.serverTimeSync == 0 then
				botman.serverTimeSync = -(os.time() - botman.serverTimeStamp)
			end

			botman.serverHour = string.sub(time, 1, 2)
			botman.serverMinute = string.sub(time, 4, 5)
			specialDay = ""

			if (string.find(botman.serverTime, "02-14", 5, 10)) then specialDay = "valentine" end
			if (string.find(botman.serverTime, "12-25", 5, 10)) then specialDay = "christmas" end

			if server.dateTest == nil then
				server.dateTest = date
			end

			if not handled then
				-- stuff to ignore
				if string.find(msg, "WebCommandResult") then
					handled = true
					--skipLog = true
				end

				if string.find(msg, "SleeperVolume") then
					handled = true
					skipLog = true
				end
			end

			-- handle errors in the log by passing them to matchAll where they are collated
			if not handled then
				if string.find(msg, "NaN") then
					handled = true
					skipLog = true
					matchAll(msg, date, time)
				end
			end

			if not handled then
				if string.find(msg, "INF Delta out") then
					handled = true
					skipLog = true
					matchAll(msg, date, time)
				end
			end

			if not handled then
				if string.find(msg, "INF Missing ") then
					handled = true
					skipLog = true
					matchAll(msg, date, time)
				end
			end

			if not handled then
				if string.find(msg, "INF Error ") then
					handled = true
					skipLog = true
					matchAll(msg, date, time)
				end
			end

			if not handled then
				if string.find(msg, "IndexOutOfRangeException") then
					handled = true
					skipLog = true
					matchAll(msg, date, time)
				end
			end

			if not handled then
				if string.find(msg, "Unbalanced") then
					handled = true
					skipLog = true
					matchAll(msg, date, time)
				end
			end

			if not handled then
				if string.find(msg, "NullReferenceException") then
					handled = true
					skipLog = true
					matchAll(msg, date, time)
				end
			end

			if not handled then
				if string.find(msg, "WRN ") then
					handled = true
					skipLog = true
					matchAll(msg, date, time)
				end
			end

			if not handled then
				if string.find(msg, "NullReferenceException") then
					handled = true
					skipLog = true
					matchAll(msg, date, time)
				end
			end

			-- everything else
			if not handled then
				if string.find(msg, "Chat:", nil, true) or string.find(msg, "Chat (from", nil, true) then --  and not string.find(msg, " to 'Party')", nil, true) and not string.find(msg, " to 'Friend')", nil, true)
					gmsg(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "to 'Global'", nil, true) then --  and not string.find(msg, " to 'Party')", nil, true) and not string.find(msg, " to 'Friend')", nil, true)
					gmsg(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "Executing command 'pm ", nil, true) or string.find(msg, "Denying command 'pm", nil, true) then
					gmsg(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "Chat command from", nil, true) then --  or string.find(msg, "GMSG:", nil, true)
					gmsg(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "denied: Too many players on the server!", nil, true) then
					playerDenied(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "Player connected") then
					playerConnected(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "Player disconnected") then
					playerDisconnected(msg)
					handled = true
				end
			end

			if not handled then
				if server.enableScreamerAlert then
					if string.find(msg, "AIDirector: Spawning scouts", nil, true) then
						scoutsWarning(msg)
						handled = true
					end
				end
			end

			if not handled then
				if string.find(msg, "Telnet executed 'tele ", nil, true) or string.find(msg, "Executing command 'tele ", nil, true) then
					teleTrigger(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "Heap:", nil, true) then
					memTrigger(msg)
					handled = true
				end
			end

			if not handled then
				if string.sub(msg, 1, 4) == "Day " then
					gameTimeTrigger(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "INF Player with ID") then
					overstackTrigger(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "banned until") then
					collectBan(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "Executing command 'ban remove", nil, true) then
					unbanPlayer(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "eliminated") or string.find(msg, "killed by") then
					pvpPolice(msg)
					handled = true
				end
			end

			if not handled then
				if server.enableAirdropAlert then
					if string.find(msg, "AIAirDrop: Spawned supply crate") then
						airDropAlert(msg)
						handled = true
					end
				end
			end

			-- if nothing else processed the log line send it to matchAll
			if not handled then
				matchAll(msg, date, time)
			end

			if not skipLog then
				writeAPILog(msg)
			end
		end
	end

	file:close()
end


function readAPI_SE()
	local file, ln, result, temp, data, k, v, getData, entityID, entity, cursor, errorString
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/se.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	end

	botman.lastServerResponseTimestamp = os.time()
	file = io.open(homedir .. "/temp/se.txt", "r")
	getData = false

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if q.command == "se" then
					irc_chat(q.ircUser, data[k])
				end
			end

			if (string.find(v, "please specify one of the entities")) then
				-- flag all the zombies for removal so we can detect deleted zeds
				if botman.dbConnected then
					conn:execute("UPDATE gimmeZombies SET remove = 1")
					conn:execute("UPDATE otherEntities SET remove = 1")
				end

				getData = true
			else
				if getData then
					if v ~= "" then
						temp = string.split(v, "-")

						entityID = string.trim(temp[1])
						entity = string.trim(temp[2])

						if string.find(v, "ombie") then
							if botman.dbConnected then conn:execute("INSERT INTO gimmeZombies (zombie, entityID) VALUES ('" .. entity .. "'," .. entityID .. ") ON DUPLICATE KEY UPDATE remove = 0") end
							updateGimmeZombies(entityID, entity)
						else
							if botman.dbConnected then conn:execute("INSERT INTO otherEntities (entity, entityID) VALUES ('" .. entity .. "'," .. entityID .. ") ON DUPLICATE KEY UPDATE remove = 0") end
							updateOtherEntities(entityID, entity)
						end
					end
				end
			end
		end
	end

	file:close()

	if botman.dbConnected then conn:execute("DELETE FROM gimmeZombies WHERE remove = 1 OR zombie LIKE '%Template%'") end
	loadGimmeZombies()

	if botman.dbConnected then conn:execute("DELETE FROM otherEntities WHERE remove = 1 OR entity LIKE '%Template%' OR entity LIKE '%invisible%'") end
	loadOtherEntities()

	if botman.dbConnected then
		cursor,errorString = conn:execute("SELECT MAX(entityID) AS maxZeds FROM gimmeZombies")
		row = cursor:fetch({}, "a")
		botman.maxGimmeZombies = tonumber(row.maxZeds)
	end

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/se.txt")
end


function readAPI_MEM()
	local file, ln, result, data, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/mem.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/mem.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		for con, q in pairs(conQueue) do
			if q.command == result.command then
				if string.find(result.result, "\n") then
					data = splitCRLF(result.result)

					for k,v in pairs(data) do
						irc_chat(q.ircUser, data[k])
					end
				else
					irc_chat(q.ircUser, result.result)
				end
			end
		end

		data = stripMatching(result.result, "\\r\\n")
		data = stripMatching(result.result, "\\n")
		memTrigger(data)
	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == result.command then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/mem.txt")
end


function readAPI_webUIUpdates()
	local file, ln, result, data, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/webUIUpdates.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.botOffline or botman.APIOffline then
			irc_chat(server.ircMain, "The bot has connected to the server API.")
		end

		if botman.APIOffline then
			botman.APIOffline = false
		end

		toggleTriggers("api online")

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/webUIUpdates.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		result.newlogs = tonumber(result.newlogs)
		botman.newlogs = result.newlogs

		if not botman.lastLogLine then
			botman.lastLogLine = result.newlogs
		end

		if tonumber(botman.lastLogLine) < botman.newlogs then
			getAPILog()
		end

		botman.lastLogLine = botman.newlogs + 1

		if tonumber(result.players) >= 0 then
			botman.playersOnline = tonumber(result.players)
		else
			botman.playersOnline = 0
		end
	end

	file:close()
end


function readAPI_Version()
	local file, ln, result, data, k, v, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/installedMods.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	modVersions = {}
	server.allocs = false
	server.botman = false
	server.otherManager = false

	file = io.open(homedir .. "/temp/installedMods.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" then
				matchAll(v)
			end

			for con, q in pairs(conQueue) do
				if q.command == "version" then
					irc_chat(q.ircUser, data[k])
				end
			end
		end

	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == "version" then
			conQueue[con] = nil
		end
	end

	if server.allocs and server.botman then
		botMaintenance.modsInstalled = true
	else
		botMaintenance.modsInstalled = false
	end

	saveBotMaintenance()

	if botman.dbConnected then
		conn:execute("DELETE FROM webInterfaceJSON WHERE ident = 'modVersions'")
		conn:execute("INSERT INTO webInterfaceJSON (ident, recipient, json) VALUES ('modVersions','panel','" .. escape(yajl.to_string(modVersions)) .. "')")
	end

	os.remove(homedir .. "/temp/installedMods.txt")
	table.save(homedir .. "/data_backup/modVersions.lua", modVersions)
end
