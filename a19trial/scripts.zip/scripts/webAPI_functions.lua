--[[
    Botman - A collection of scripts for managing 7 Days to Die servers
    Copyright (C) 2020  Matthew Dwyer
	           This copyright applies to the Lua source code in this Mudlet profile.
    Email     smegzor@gmail.com
    URL       https://botman.nz
    Source    https://bitbucket.org/mhdwyer/botman
--]]

-- enable debug to see where the code is stopping. Any error will be after the last debug line.
local debug = false -- should be false unless testing


function getAPILogUpdates()
	url = "http://" .. server.IP .. ":" .. server.webPanelPort + 2 .. "/api/getwebuiupdates?adminuser=bot&admintoken=" .. server.allocsWebAPIPassword
	os.remove(homedir .. "/temp/webUIUpdates.txt")
	downloadFile(homedir .. "/temp/webUIUpdates.txt", url)
end


function getAPILog()
	url = "http://" .. server.IP .. ":" .. server.webPanelPort + 2 .. "/api/getlog?firstline=" .. botman.lastLogLine .. "&adminuser=bot&admintoken=" .. server.allocsWebAPIPassword
	os.remove(homedir .. "/temp/log.txt")
	downloadFile(homedir .. "/temp/log.txt", url)
end


function getBMFriends(steam, data)
	local k, v, pid

	-- delete auto-added friends from the MySQL table
	if botman.dbConnected then conn:execute("DELETE FROM friends WHERE steam = " .. steam .. " AND autoAdded = 1") end

	if data == "" then
		return
	end

	for k,v in pairs(data) do
		pid = string.sub(v, 1, 17)

		-- add friends read from bm-listplayerfriends
		if not string.find(friends[steam].friends, pid) then
			addFriend(steam, pid, true)
		end
	end
end


function API_PlayerInfo(data)
	-- EDIT THIS FUNCTION WITH CARE.  This function is central to player management.  Some lines need to be run before others.
	-- Lua will stop execution wherever it strikes a fault (usually trying to use a non-existing variable)
	-- enable debugging to see roughly where the bot gets to.  It should reach 'end API_Playerinfo'.
	-- Good luck :)

	if customAPIPlayerInfo ~= nil then
		-- read the note on overriding bot code in custom/custom_functions.lua
		if customAPIPlayerInfo(data) then
			return
		end
	end

	local tmp = {}
	local debug, posX, posY, posZ, lastX, lastY, lastZ, lastDist, mapCenterDistance, regionX, regionZ, chunkX, chunkZ, exile, prison, steam
	local steamtest, admin, lastGimme, lastLogin, playerAccessLevel, temp, settings
	local xPosOld, yPosOld, zPosOld, position, outsideMap, outsideMapDonor, fields, values, flag
	local k, v, key
	local timestamp = os.time()
	local region = ""
	local resetZone = false
	local dist, hotspot, currentLocation

	data.level = math.floor(data.level)
	steam = tostring(data.steamid)

	debug = false -- should be false unless testing

	-- Set debugPlayerInfo to the steam id or player name that you want to monitor.  If the player is not on the server, the bot will reset debugPlayerInfo to zero.
	debugPlayerInfo = 0 -- should be 0 unless testing against a steam id

	exile = LookupLocation("exile")
	prison = LookupLocation("prison")
	flag = ""
	ping = tonumber(data.ping)
	posX = data.position.x
	posY = data.position.y
	posZ = data.position.z
	intX = posX
	intY = posY
	intZ = posZ

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	position = posX .. posY .. posZ

	region = getRegion(intX, intZ)
	regionX, regionZ, chunkX, chunkZ = getRegionChunkXZ(intX, intZ)

	if (resetRegions[region]) then
		resetZone = true
	else
		resetZone = false
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- check for invalid or missing steamid.  kick if not passed
	steamtest = tonumber(steam)
	if (steamtest == nil) then
		sendCommand("kick " .. data.entityid)
		irc_chat(server.ircMain, "Player " .. data.name .. " kicked for invalid Steam ID: " .. steam)
		faultyPlayerinfo = false
		return
	end

	if (string.len(steam) < 17) then
		sendCommand("kick " .. data.entityid)
		irc_chat(server.ircMain, "Player " .. data.name .. " kicked for invalid Steam ID: " .. steam)
		faultyPlayerinfo = false
		return
	end

	-- add to in-game players table
	if (igplayers[steam] == nil) then
		igplayers[steam] = {}
		igplayers[steam].id = data.entityid
		igplayers[steam].name = data.name
		igplayers[steam].steam = steam
		igplayers[steam].steamOwner = steam

		fixMissingIGPlayer(steam)
	end

	if igplayers[steam].readCounter == nil then
		igplayers[steam].readCounter = 0
	else
		igplayers[steam].readCounter = igplayers[steam].readCounter + 1
	end

	if igplayers[steam].checkNewPlayer == nil then
		fixMissingIGPlayer(steam)
	end

	-- if player is missing from player lua table, try to load them from the database.
	if (players[steam] == nil) then
		loadPlayers(steam)

		-- exit here if the bot started up less than 2 minutes ago.
		-- this is an attempt to fix a bug/issue where a non-new player isn't found in the data and is reset as new when they actually exist already.
		-- hopefully it gives the bot time to sort that out and not stuff up :O
		if os.time() - botman.botStarted < 120 then
			return
		end
	end

	-- add to players table
	if (players[steam] == nil) then
		players[steam] = {}
		players[steam].id = data.entityid
		players[steam].name = data.name
		players[steam].steam = steam

		if tonumber(data.score) == 0 and tonumber(data.zombiekills) == 0 and tonumber(data.playerdeaths) == 0 then
			players[steam].newPlayer = true
			setGroupMembership(steam, "new players", true)
		else
			players[steam].newPlayer = false
			setGroupMembership(steam, "new players", false)
		end

		players[steam].watchPlayer = true
		players[steam].watchPlayerTimer = os.time() + 2419200 -- stop watching in one month or until no longer a new player
		players[steam].ip = data.ip
		players[steam].exiled = false

		irc_chat(server.ircMain, "###  New player joined " .. data.name .. " steam: " .. steam.. " id: " .. data.entityid .. " ###")
		irc_chat(server.ircAlerts, "New player joined " .. server.gameDate)

		if botman.dbConnected then
			conn:execute("INSERT INTO events (x, y, z, serverTime, type, event, steam) VALUES (" .. posX .. "," .. posY .. "," .. posZ .. ",'" .. botman.serverTime .. "','new player','New player joined (webAPI) " .. data.name .. " steam: " .. steam.. " id: " .. data.entityid .. "'," .. steam .. ")")
			conn:execute("INSERT INTO players (steam, name, id, IP, newPlayer, watchPlayer, watchPlayerTimer) VALUES (" .. steam .. ",'" .. escape(data.name) .. "'," .. data.entityid .. "," .. data.ip .. ",1,1, " .. os.time() + 2419200 .. ")")
		end

		fixMissingPlayer(steam)

		-- don't initially warn the player about pvp or pve zone.  Too many players complain about it when the bot is restarted.  We can warn them next time their zone changes.
		if pvpZone(posX, posZ) then
			if players[steam].alertPVP == true then
				players[steam].alertPVP = false
			end
		else
			if players[steam].alertPVP == false then
				players[steam].alertPVP = true
			end
		end

		if not server.optOutGlobalBots then
			CheckBlacklist(steam, data.ip)
		end
	end

	settings = getSettings(steam)

	if igplayers[steam].greet then
		if tonumber(igplayers[steam].greetdelay) > 0 then
			igplayers[steam].greetdelay = igplayers[steam].greetdelay -1
		end
	end

	if tonumber(data.ping) > 0 then
		igplayers[steam].ping = tonumber(data.ping)
		players[steam].ping = tonumber(data.ping)
	else
		igplayers[steam].ping = 0
		players[steam].ping = 0
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	if faultyInfo == steam then
		-- Attempt to fix the fault assuming it set some stuff because of it
		if igplayers[steam].yPosLastOK == 0 then
			igplayers[steam].xPosLastOK = intX
			igplayers[steam].yPosLastOK = intY
			igplayers[steam].zPosLastOK = intZ
		end
	end

	playerAccessLevel = accessLevel(steam)

	if isAdmin(steam) then
		-- admins don't hack (no lie) ^^
		players[steam].hackerScore = 0
		admin = true
	else
		admin = false
	end

	if data.ip ~= "" and players[steam].ip == "" then
		players[steam].IP = data.ip

		if not server.optOutGlobalBots then
			CheckBlacklist(steam, data.ip)
		end
	end

	-- ping kick
	if (not whitelist[steam]) and (not isDonor(steam)) and (not admin) then
		if (server.pingKickTarget == "new" and players[steam].newPlayer) or server.pingKickTarget == "all" then
			if tonumber(data.ping) < tonumber(server.pingKick) and tonumber(server.pingKick) > 0 then
				igplayers[steam].highPingCount = tonumber(igplayers[steam].highPingCount) - 1
				if tonumber(igplayers[steam].highPingCount) < 0 then igplayers[steam].highPingCount = 0 end
			end

			if tonumber(data.ping) > tonumber(server.pingKick) and tonumber(server.pingKick) > 0 then
				igplayers[steam].highPingCount = tonumber(igplayers[steam].highPingCount) + 1

				if tonumber(igplayers[steam].highPingCount) > 15 then
					irc_chat(server.ircMain, "Kicked " .. data.name .. " steam: " .. steam.. " for high ping " .. data.ping)
					kick(steam, "High ping kicked.")
					return
				end
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	if tonumber(intY) > 0 and tonumber(intY) < 500 then
		igplayers[steam].lastTP = nil
		forgetLastTP(steam)
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	if players[steam].location ~= "" and igplayers[steam].spawnedInWorld then --  and igplayers[steam].teleCooldown < 1
		igplayers[steam].teleCooldown = 0

		-- spawn the player at location
		if (locations[players[steam].location]) then
			temp = players[steam].location
			players[steam].location = ""
			if botman.dbConnected then conn:execute("UPDATE players SET location = '' WHERE steam = " .. steam) end

			irc_chat(server.ircMain, "Player " .. steam .. " " .. data.name .. " is being moved to " .. temp)
			irc_chat(server.ircAlerts, "Player " .. steam .. " " .. data.name .. " is being moved to " .. temp)
			message(string.format("pm %s [%s]You are being moved to %s[-]", steam, server.chatColour, temp))
			randomTP(steam, temp, true)
		end

		if (players[steam].location == "return player") then
			if players[steam].xPosTimeout ~= 0 and players[steam].zPosTimeout ~= 0 then
				cmd = "tele " .. steam .. " " .. players[steam].xPosTimeout .. " " .. players[steam].yPosTimeout .. " " .. players[steam].zPosTimeout
				players[steam].xPosTimeout = 0
				players[steam].yPosTimeout = 0
				players[steam].zPosTimeout = 0
			else
				cmd = "tele " .. steam .. " " .. players[steam].xPosOld .. " " .. players[steam].yPosOld .. " " .. players[steam].zPosOld
			end

			players[steam].location = ""
			if botman.dbConnected then conn:execute("UPDATE players SET location = '' WHERE steam = " .. steam) end
			teleport(cmd, steam)
		end
	end

	if tonumber(players[steam].hackerScore) >= 10000 then
		players[steam].hackerScore = 0

		if igplayers[steam].hackerDetection ~= nil then
			message(string.format("say [%s]Banning %s. Hacking suspected. Evidence: " .. igplayers[steam].hackerDetection .. "[-]", server.chatColour, players[steam].name))
		else
			message(string.format("say [%s]Banning %s. Detected possible evidence of hacking.[-]", server.chatColour, players[steam].name))
		end

		banPlayer(steam, "1 year", "Automatic ban for suspected hacking. Admins have been alerted.", "")

		-- if the player has any pending global bans, activate them
		if botman.botsConnected then
			connBots:execute("UPDATE bans set GBLBanActive = 1 WHERE GBLBan = 1 AND steam = " .. steam)
		end
	else
		if tonumber(players[steam].hackerScore) >= 49  then
			-- if the player has pending global bans recorded against them, we ban them early and also activate the global ban
			if tonumber(players[steam].pendingBans) > 0 then
				players[steam].hackerScore = 0
				if igplayers[steam].hackerDetection ~= nil then
					message(string.format("say [%s]Temp banning %s. May be hacking. Detected " .. igplayers[steam].hackerDetection .. "[-]", server.chatColour, players[steam].name))
				else
					message(string.format("say [%s]Temp banning %s 1 week. Detected clipping or flying too much. Admins have been alerted.[-]", server.chatColour, players[steam].name))
				end

				banPlayer(steam, "1 week", "Automatic ban for suspected hacking. Admins have been alerted.", "")

				-- activate the pending bans
				if botman.botsConnected then
					connBots:execute("UPDATE bans set GBLBanActive = 1 WHERE GBLBan = 1 AND steam = " .. steam)
				end
			end
		end

		if tonumber(igplayers[steam].flyCount) > 2 and not isAdmin(steam)  then
			players[steam].hackerScore = 0
			if igplayers[steam].hackerDetection ~= nil then
				message(string.format("say [%s]Temp banning %s 1 week for suspected hacking. Detected " .. igplayers[steam].hackerDetection .. "[-]", server.chatColour, players[steam].name))
			else
				message(string.format("say [%s]Temp banning %s 1 week for suspected hacking.[-]", server.chatColour, players[steam].name))
			end

			banPlayer(steam, "1 week", "Automatic ban for suspected hacking. Admins have been alerted.", "")

			-- if the player has any pending global bans, activate them
			if botman.botsConnected then
				connBots:execute("UPDATE bans set GBLBanActive = 1 WHERE GBLBan = 1 AND steam = " .. steam)
			end
		end

		if tonumber(players[steam].hackerScore) >= 60 then
			players[steam].hackerScore = 0
			if igplayers[steam].hackerDetection ~= nil then
				message(string.format("say [%s]Temp banning %s 1 week for suspected hacking. Detected " .. igplayers[steam].hackerDetection .. "[-]", server.chatColour, players[steam].name))
			else
				message(string.format("say [%s]Temp banning %s 1 week for suspected hacking.[-]", server.chatColour, players[steam].name))
			end

			banPlayer(steam, "1 week", "Automatic ban for suspected hacking. Admins have been alerted.", "")

			-- if the player has any pending global bans, activate them
			if botman.botsConnected then
				connBots:execute("UPDATE bans set GBLBanActive = 1 WHERE GBLBan = 1 AND steam = " .. steam)
			end
		end
	end


	-- test for hackers teleporting
	if server.hackerTPDetection and igplayers[steam].spawnChecked == false and not igplayers[steam].spawnPending then
		igplayers[steam].spawnChecked = true

		-- ignore tele spawns for 10 seconds after the last legit tp to allow for lag and extra tp commands on delayed tp servers.
		if (os.time() - igplayers[steam].lastTPTimestamp > 10) and (igplayers[steam].spawnedCoordsOld ~= igplayers[steam].spawnedCoords)then
			if not (players[steam].timeout or players[steam].botTimeout or players[steam].ignorePlayer) then
				if tonumber(intX) ~= 0 and tonumber(intZ) ~= 0 and tonumber(igplayers[steam].xPos) ~= 0 and tonumber(igplayers[steam].zPos) ~= 0 then
					dist = 0

					if igplayers[steam].spawnedInWorld and igplayers[steam].spawnedReason == "teleport" and igplayers[steam].spawnedCoordsOld ~= "0 0 0" then
						dist = distancexz(posX, posZ, igplayers[steam].xPos, igplayers[steam].zPos)
					end

					if (dist >= 900) then
						if tonumber(igplayers[steam].tp) < 1 then
							if players[steam].newPlayer == true then
								new = " [FF8C40]NEW player "
							else
								new = " [FF8C40]Player "
							end

							if not admin then
								irc_chat(server.ircMain, botman.serverTime .. " Player " .. data.entityid .. " " .. steam .. " name: " .. data.name .. " detected teleporting to " .. intX .. " " .. intY .. " " .. intZ .. " distance " .. string.format("%-8.2d", dist))
								irc_chat(server.ircAlerts, server.gameDate .. " player " .. data.entityid .. " " .. steam .. " name: " .. data.name .. " detected teleporting to " .. intX .. " " .. intY .. " " .. intZ .. " distance " .. string.format("%-8.2d", dist))

								igplayers[steam].hackerTPScore = tonumber(igplayers[steam].hackerTPScore) + 1
								players[steam].watchPlayer = true
								players[steam].watchPlayerTimer = os.time() + 259200 -- watch for 3 days
								if botman.dbConnected then conn:execute("UPDATE players SET watchPlayer = 1, watchPlayerTimer = " .. os.time() + 259200 .. " WHERE steam = " .. steam) end

								if players[steam].exiled == true or players[steam].newPlayer then
									igplayers[steam].hackerTPScore = tonumber(igplayers[steam].hackerTPScore) + 1
								end

								if igplayers[steam].hackerTPScore > 0 and players[steam].newPlayer and tonumber(players[steam].ping) > 180 then
									if locations[exile] and not players[steam].prisoner then
										players[steam].exiled = true
									else
										igplayers[steam].hackerTPScore = tonumber(igplayers[steam].hackerTPScore) + 1
									end
								end

								if tonumber(igplayers[steam].hackerTPScore) > 1 then
									igplayers[steam].hackerTPScore = 0
									igplayers[steam].tp = 0
									message(string.format("say [%s]Temp banning %s 1 week for unexplained teleporting. An admin will investigate the circumstances.[-]", server.chatColour, players[steam].name))
									banPlayer(steam, "1 week", "We detected unusual teleporting from you and are investigating the circumstances.", "")

									-- if the player has any pending global bans, activate them
									if botman.botsConnected then
										connBots:execute("UPDATE bans set GBLBanActive = 1 WHERE GBLBan = 1 AND steam = " .. steam)
									end
								end

								alertAdmins(data.entityid .. " name: " .. data.name .. " detected teleporting! In fly mode, type " .. server.commandPrefix .. "near " .. data.entityid .. " to shadow them.", "warn")
							end
						end

						igplayers[steam].tp = 0
					else
						igplayers[steam].tp = 0
					end
				end
			end
		end

		igplayers[steam].spawnChecked = true
		igplayers[steam].spawnedCoordsOld = igplayers[steam].spawnedCoords
	end

	igplayers[steam].lastLP = os.time()

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	players[steam].id = data.entityid
	players[steam].name = data.name
	players[steam].steamOwner = igplayers[steam].steamOwner
	igplayers[steam].id = data.entityid
	igplayers[steam].name = data.name
	igplayers[steam].steam = steam

	if igplayers[steam].deaths ~= nil then
		if tonumber(igplayers[steam].deaths) < tonumber(data.playerdeaths) then
			if tonumber(igplayers[steam].yPosLast) > 0 then
				players[steam].deathX = igplayers[steam].xPosLast
				players[steam].deathY = igplayers[steam].yPosLast
				players[steam].deathZ = igplayers[steam].zPosLast

				igplayers[steam].deadX = igplayers[steam].xPosLast
				igplayers[steam].deadY = igplayers[steam].yPosLast
				igplayers[steam].deadZ = igplayers[steam].zPosLast
				igplayers[steam].teleCooldown = 1000

				irc_chat(server.ircMain, "Player " .. steam .. " name: " .. data.name .. "'s death recorded at " .. igplayers[steam].deadX .. " " .. igplayers[steam].deadY .. " " .. igplayers[steam].deadZ)
				irc_chat(server.ircAlerts, server.gameDate .. " player " .. steam .. " name: " .. data.name .. "'s death recorded at " .. igplayers[steam].deadX .. " " .. igplayers[steam].deadY .. " " .. igplayers[steam].deadZ)

				message("say [" .. server.chatColour .. "]" .. data.name .. " has died.[-]")

				r = randSQL(14)
				if (r == 1) then message("say [" .. server.chatColour .. "]" .. data.name .. " removed themselves from the gene pool.[-]") end
				if (r == 2) then message("say [" .. server.chatColour .. "]LOL!  Didn't run far away enough did you " .. data.name .. "?[-]") end
				if (r == 3) then message("say [" .. server.chatColour .. "]And the prize for most creative way to end themselves goes to.. " .. data.name .. "[-]") end
				if (r == 4) then message("say [" .. server.chatColour .. "]" .. data.name .. " really shouldn't handle explosives.[-]") end
				if (r == 5) then message("say Oh no! " .. data.name .. " died.  What a shame.[-]") end
				if (r == 6) then message("say [" .. server.chatColour .. "]Great effort there " .. data.name .. ". I'm awarding " .. data.score .. " points.[-]") end
				if (r == 7) then message("say [" .. server.chatColour .. "]LOL! REKT[-]") end

				if (r == 8) then
					message("say [" .. server.chatColour .. "]We are gathered here today to remember with sadness the passing of " .. data.name .. ". Rest in pieces. Amen.[-]")
				end

				if (r == 9) then message("say [" .. server.chatColour .. "]" .. data.name .. " cut the wrong wire.[-]") end
				if (r == 10) then message("say [" .. server.chatColour .. "]" .. data.name .. " really showed that explosive who's boss![-]") end
				if (r == 11) then message("say [" .. server.chatColour .. "]" .. data.name .. " shouldn't play Russian Roulette with a fully loaded gun.[-]") end
				if (r == 12) then message("say [" .. server.chatColour .. "]" .. data.name .. " added a new stain to the floor.[-]") end
				if (r == 13) then message("say [" .. server.chatColour .. "]ISIS got nothing on " .. data.name .. "'s suicide bomber skillz.[-]") end
				if (r == 14) then message("say [" .. server.chatColour .. "]" .. data.name .. " reached a new low with that death. Six feet under.[-]") end

				players[steam].packCooldown = os.time() + settings.packCooldown
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	igplayers[steam].xPosLast = igplayers[steam].xPos
	igplayers[steam].yPosLast = igplayers[steam].yPos
	igplayers[steam].zPosLast = igplayers[steam].zPos
	igplayers[steam].xPos = posX
	igplayers[steam].yPos = posY
	igplayers[steam].zPos = posZ

	-- also add intX etc to prevent bad code breaking because it can't find it
	igplayers[steam].intX = posX
	igplayers[steam].intY = posY
	igplayers[steam].intZ = posZ

	igplayers[steam].playerKills = data.playerkills
	igplayers[steam].deaths = data.playerdeaths
	igplayers[steam].zombies = data.zombiekills
	igplayers[steam].score = data.score

	if igplayers[steam].oldLevel == nil then
		igplayers[steam].oldLevel = data.level
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- hacker detection
	if tonumber(igplayers[steam].oldLevel) ~= -1 then
		if tonumber(data.level) - tonumber(igplayers[steam].oldLevel) > 50 and not admin and server.alertLevelHack then
			alertAdmins(data.entityid .. " name: " .. data.name .. " detected possible level hacking!  Old level was " .. igplayers[steam].oldLevel .. " new level is " .. data.level .. " an increase of " .. tonumber(data.level) - tonumber(igplayers[steam].oldLevel), "alert")
			irc_chat(server.ircAlerts, server.gameDate .. " " .. steam .. " name: " .. data.name .. " detected possible level hacking!  Old level was " .. igplayers[steam].oldLevel .. " new level is " .. data.level .. " an increase of " .. tonumber(data.level) - tonumber(igplayers[steam].oldLevel))
		end

		if server.checkLevelHack then
			if tonumber(data.level) - tonumber(igplayers[steam].oldLevel) > 50 and not admin then
				players[steam].hackerScore = 10000
				igplayers[steam].hackerDetection = "Suspected level hack. (" .. data.level .. ") an increase of " .. tonumber(data.level) - tonumber(igplayers[steam].oldLevel)
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	players[steam].level = data.level
	igplayers[steam].level = data.level
	igplayers[steam].oldLevel = data.level
	igplayers[steam].killTimer = 0 -- to help us detect a player that has disconnected unnoticed
	igplayers[steam].raiding = false
	igplayers[steam].regionX = regionX
	igplayers[steam].regionZ = regionZ
	igplayers[steam].chunkX = chunkX
	igplayers[steam].chunkZ = chunkZ

	if pvpZone(posX, posZ) then
		igplayers[steam].currentLocationPVP = true
	else
		igplayers[steam].currentLocationPVP = false
	end

	if (igplayers[steam].xPosLast == nil) then
		igplayers[steam].xPosLast = posX
		igplayers[steam].yPosLast = posY
		igplayers[steam].zPosLast = posZ
		igplayers[steam].xPosLastOK = intX
		igplayers[steam].yPosLastOK = intY
		igplayers[steam].zPosLastOK = intZ
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	atHome(steam)
	currentLocation = inLocation(intX, intZ)

	if currentLocation ~= false then
		igplayers[steam].currentLocationPVP = locations[currentLocation].pvp
		igplayers[steam].inLocation = currentLocation
		players[steam].inLocation = currentLocation

		resetZone = locations[currentLocation].resetZone

		if locations[currentLocation].killZombies then
			server.scanZombies = true
		end
	else
		players[steam].inLocation = ""
		igplayers[steam].inLocation = ""
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	if server.showLocationMessages then
		if igplayers[steam].alertLocation ~= currentLocation and currentLocation ~= false then
			if locations[currentLocation].public or admin then
				message(string.format("pm %s [%s]Welcome to %s[-]", steam, server.chatColour, currentLocation))
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	if currentLocation == false then
		if server.showLocationMessages then
			if igplayers[steam].alertLocation ~= "" then
				if not locations[igplayers[steam].alertLocation] then
					igplayers[steam].alertLocation = ""
				else
					if locations[igplayers[steam].alertLocation].public or admin then
						message(string.format("pm %s [%s]You have left %s[-]", steam, server.chatColour, igplayers[steam].alertLocation))
					end
				end
			end
		end

		igplayers[steam].alertLocation = ""
	else
		igplayers[steam].alertLocation = currentLocation
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- fix weird cash bug
	if tonumber(players[steam].cash) < 0 then
		players[steam].cash = 0
	end

	-- convert zombie kills to cash
	if (tonumber(igplayers[steam].zombies) > tonumber(players[steam].zombies)) and (math.abs(igplayers[steam].zombies - players[steam].zombies) < 20) then
		if server.allowBank then
			players[steam].cash = tonumber(players[steam].cash) + math.abs(igplayers[steam].zombies - players[steam].zombies) * settings.zombieKillRewardDonors

			if (players[steam].watchCash) then
				message(string.format("pm %s [%s]+%s %s $%s in the bank[-]", steam, server.chatColour, math.abs(igplayers[steam].zombies - players[steam].zombies) * settings.zombieKillReward, server.moneyPlural, string.format("%d", players[steam].cash)))
			end
		end

		if igplayers[steam].doge then
			dogePhrase = dogeWOW() .. " " .. dogeWOW() .. " "

			r = randSQL(10)
			if r == 1 then dogePhrase = dogePhrase .. "WOW" end
			if r == 3 then dogePhrase = dogePhrase .. "Excite" end
			if r == 5 then dogePhrase = dogePhrase .. "Amaze" end
			if r == 7 then dogePhrase = dogePhrase .. "OMG" end
			if r == 9 then dogePhrase = dogePhrase .. "Respect" end

			message(string.format("pm %s [%s]" .. dogePhrase .. "[-]", steam, server.chatColour))
		end

		if server.allowBank then
			-- update the lottery prize pool
			server.lottery = server.lottery + (math.abs(igplayers[steam].zombies - players[steam].zombies) * settings.lotteryMultiplier)
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- update player record of zombies
	players[steam].zombies = igplayers[steam].zombies

	if tonumber(players[steam].playerKills) < tonumber(data.playerkills) then
		players[steam].playerKills = data.playerkills
	end

	if tonumber(players[steam].deaths) < tonumber(data.playerdeaths) then
		players[steam].deaths = data.playerdeaths
	end

	if tonumber(players[steam].score) < tonumber(data.score) then
		players[steam].score = data.score
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	players[steam].xPos = posX
	players[steam].yPos = posY
	players[steam].zPos = posZ

	mapCenterDistance = distancexz(intX,intZ,0,0)
	outsideMap = squareDistance(intX, intZ, settings.mapSize)

	if (players[steam].alertReset == nil) then
		players[steam].alertReset = true
	end

	if (igplayers[steam].greet) then
		if tonumber(igplayers[steam].greetdelay) == 0 then
			igplayers[steam].greet = false

			if not server.noGreetingMessages then
				if server.welcome ~= nil and server.welcome ~= "" then
					message(string.format("pm %s [%s]%s[-]", steam, server.chatColour, server.welcome))
				else
					message("pm " .. steam .. " [" .. server.chatColour .. "]Welcome to " .. server.serverName .. "!  Type " .. server.commandPrefix .. "info, " .. server.commandPrefix .. "rules or " .. server.commandPrefix .. "help for commands.[-]")
					message(string.format("pm %s [%s]We have a server manager bot called %s[-]", steam, server.chatColour, server.botName))
				end

				if (tonumber(igplayers[steam].zombies) ~= 0) then
					if isDonor(steam) then
						welcome = "pm " .. steam .. " [" .. server.chatColour .. "]Welcome back " .. data.name .. "! Thanks for supporting us. =D[-]"
					else
						welcome = "pm " .. steam .. " [" .. server.chatColour .. "]Welcome back " .. data.name .. "![-]"
					end

					if (string.find(botman.serverTime, "02-14", 5, 10)) then welcome = "pm " .. steam .. " [" .. server.chatColour .. "]Happy Valentines Day " .. data.name .. "! ^^[-]" end

					message(welcome)
				else
					message("pm " .. steam .. " [" .. server.chatColour .. "]Welcome " .. data.name .. "![-]")
				end

				if (players[steam].timeout == true) then
					message("pm " .. steam .. " [" .. server.warnColour .. "]You are in timeout, not glitched or lagged.  You will stay here until released by an admin.[-]")
				end

				if (botman.scheduledRestart) then
					message("pm " .. steam .. " [" .. server.alertColour .. "]<!>[-][" .. server.warnColour .. "] SERVER WILL REBOOT SHORTLY [-][" .. server.alertColour .. "]<!>[-]")
				end

				if server.MOTD ~= "" then
					if botman.dbConnected then connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]" .. server.MOTD .. "[-]") .. "')") end
				end

				if tonumber(players[steam].removedClaims) > 0 then
					if botman.dbConnected then connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]I am holding " .. players[steam].removedClaims .. " land claim blocks for you. Type " .. server.commandPrefix .. "give claims to receive them.[-]") .. "')") end
				end

				if botman.dbConnected then
					cursor,errorString = connSQL:execute("SELECT count(*) FROM mail WHERE recipient = '" .. steam .. "' and status = 0")
					rowSQL = cursor:fetch({}, "a")
					rowCount = rowSQL["count(*)"]

					if rowCount > 0 then
						connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]NEW MAIL HAS ARRIVED!  Type " .. server.commandPrefix .. "read mail to read it now or " .. server.commandPrefix .. "help mail for more options.[-]") .. "')")
					end
				end

				if players[steam].newPlayer == true and server.rules ~= "" then
					if botman.dbConnected then connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]" .. server.rules .."[-]") .. "')") end
				end

				if server.warnBotReset == true and playerAccessLevel == 0 then
					if botman.dbConnected then
						connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]ALERT!  It appears that the server has been reset.[-]") .. "')")
						connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]To reset me type " .. server.commandPrefix .. "reset bot.[-]") .. "')")
						connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]To dismiss this alert type " .. server.commandPrefix .. "no reset.[-]") .. "')")
					end
				end

				if (not players[steam].santa) and specialDay == "christmas" then
					if botman.dbConnected then connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]HO HO HO! Merry Christmas!  Type " .. server.commandPrefix .. "santa to open your Christmas stocking![-]") .. "')") end
				end
			else
				if (players[steam].timeout == true) then
					message("pm " .. steam .. " [" .. server.warnColour .. "]You are in timeout, not glitched or lagged.  You will stay here until released by an admin.[-]")
				end

				if botman.dbConnected then
					cursor,errorString = connSQL:execute("SELECT count(*) FROM mail WHERE recipient = '" .. steam .. "' AND status = 0")
					rowSQL = cursor:fetch({}, "a")
					rowCount = rowSQL["count(*)"]

					if rowCount > 0 then
						if botman.dbConnected then connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]NEW MAIL HAS ARRIVED!  Type " .. server.commandPrefix .. "read mail to read it now or " .. server.commandPrefix .. "help mail for more options.[-]") .. "')") end
					end
				end

				if (botman.scheduledRestart) then
					message("pm " .. steam .. " [" .. server.alertColour .. "]<!>[-][" .. server.warnColour .. "] SERVER WILL REBOOT SHORTLY [-][" .. server.alertColour .. "]<!>[-]")
				end
			end

			-- run commands from the connectQueue now that the player has spawned and hopefully paying attention to chat
			tempTimer( 3, [[processConnectQueue("]].. steam .. [[")]] )
			-- also check for removed claims
			tempTimer(10, [[CheckClaimsRemoved("]] .. steam .. [[")]] )
		end
	end


	if igplayers[steam].alertLocation == "" and currentLocation ~= false then
		if botman.dbConnected then connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]Welcome to " .. currentLocation .. "[-]") .. "')") end
		igplayers[steam].alertLocation = currentLocation
	end


	if (igplayers[steam].teleCooldown > 0) then
		igplayers[steam].teleCooldown = tonumber(igplayers[steam].teleCooldown) - 1
	end

	igplayers[steam].sessionPlaytime = os.time() - igplayers[steam].sessionStart

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	if players[steam].newPlayer == true then
		if (igplayers[steam].sessionPlaytime + players[steam].timeOnServer > (server.newPlayerTimer * 60) or tonumber(data.level) > tonumber(server.newPlayerMaxLevel)) then
			players[steam].newPlayer = false
			players[steam].watchPlayer = false
			players[steam].watchPlayerTimer = 0

			if botman.dbConnected then conn:execute("UPDATE players SET newPlayer = 0, watchPlayer = 0, watchPlayerTimer = 0 WHERE steam = " .. steam) end

			if string.upper(players[steam].chatColour) == "FFFFFF" then
				setChatColour(steam, players[steam].accessLevel)
			end

			setGroupMembership(steam, "New Players", false)
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- if we are following a player and they move more than 50 meters away, teleport us close to them.
	if igplayers[steam].following ~= nil then
		if igplayers[igplayers[steam].following] and players[igplayers[steam].following].timeout == false and players[igplayers[steam].following].botTimeout == false then
			followDistance = 50
			if igplayers[steam].followDistance ~= nil then followDistance = tonumber(igplayers[steam].followDistance) end

			dist = distancexz(igplayers[steam].xPos, igplayers[steam].zPos, igplayers[igplayers[steam].following].xPos, igplayers[igplayers[steam].following].zPos)
			if dist > followDistance and igplayers[igplayers[steam].following].yPos > 0 then
				-- teleport close to the player
				igplayers[steam].tp = 1
				igplayers[steam].hackerTPScore = 0
				sendCommand("tele " .. steam .. " " .. igplayers[igplayers[steam].following].xPos .. " " .. igplayers[igplayers[steam].following].yPos - 30 .. " " .. igplayers[igplayers[steam].following].zPos)
			end
		end
	end


	if (igplayers[steam].alertLocationExit ~= nil) then
		dist = distancexz(igplayers[steam].xPos, igplayers[steam].zPos, locations[igplayers[steam].alertLocationExit].x, locations[igplayers[steam].alertLocationExit].z)
		size = tonumber(locations[igplayers[steam].alertLocationExit].size)

		if (dist > tonumber(locations[igplayers[steam].alertLocationExit].size) + 100) then
			igplayers[steam].alertLocationExit = nil

			message("pm " .. steam .. " [" .. server.chatColour .. "]You have moved too far away from the location. If you still wish to do " .. server.commandPrefix .. "protect location, please start again.[-]")
			faultyPlayerinfo = false
			return
		end

		if (dist > tonumber(locations[igplayers[steam].alertLocationExit].size) + 10) and (dist <  tonumber(locations[igplayers[steam].alertLocationExit].size) + 30) then
			locations[igplayers[steam].alertLocationExit].exitX = intX
			locations[igplayers[steam].alertLocationExit].exitY = intY
			locations[igplayers[steam].alertLocationExit].exitZ = intZ
			locations[igplayers[steam].alertLocationExit].protected = true

			if botman.dbConnected then conn:execute("UPDATE locations SET exitX = " .. intX .. ", exitY = " .. intY .. ", exitZ = " .. intZ .. ", protected = 1 WHERE name = '" .. escape(igplayers[steam].alertLocationExit) .. "'") end
			message("pm " .. steam .. " [" .. server.chatColour .. "]You have enabled protection for " .. igplayers[steam].alertLocationExit .. ".[-]")

			igplayers[steam].alertLocationExit = nil

			faultyPlayerinfo = false
			return
		end
	end


	if (igplayers[steam].alertVillageExit ~= nil) then
		dist = distancexz(igplayers[steam].xPos, igplayers[steam].zPos, locations[igplayers[steam].alertVillageExit].x, locations[igplayers[steam].alertVillageExit].z)
		size = tonumber(locations[igplayers[steam].alertVillageExit].size)

		if (dist > tonumber(locations[igplayers[steam].alertVillageExit].size) + 100) then
			igplayers[steam].alertVillageExit = nil

			message("pm " .. steam .. " [" .. server.chatColour .. "]You have moved too far away from " .. igplayers[steam].alertVillageExit .. ". Return to " .. igplayers[steam].alertVillageExit .. " and type " .. server.commandPrefix .. "protect village " .. igplayers[steam].alertVillageExit .. " again.[-]")
			faultyPlayerinfo = false
			return
		end

		if (dist >  tonumber(locations[igplayers[steam].alertVillageExit].size) + 20) and (dist <  tonumber(locations[igplayers[steam].alertVillageExit].size) + 100) then
			locations[igplayers[steam].alertVillageExit].exitX = intX
			locations[igplayers[steam].alertVillageExit].exitY = intY
			locations[igplayers[steam].alertVillageExit].exitZ = intZ
			locations[igplayers[steam].alertVillageExit].protected = true

			if botman.dbConnected then conn:execute("UPDATE locations SET exitX = " .. intX .. ", exitY = " .. intY .. ", exitZ = " .. intZ .. ", protected = 1 WHERE name = '" .. escape(igplayers[steam].alertVillageExit) .. "'") end
			message("pm " .. steam .. " [" .. server.chatColour .. "]You have enabled protection for " .. igplayers[steam].alertVillageExit .. "[-]")

			igplayers[steam].alertVillageExit = nil

			faultyPlayerinfo = false
			return
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	if (igplayers[steam].alertBaseExit) then
		tmp.key = igplayers[steam].alertBaseKey
		tmp.dist = distancexz(intX, intZ, bases[tmp.key].x, bases[tmp.key].z)
		tmp.size = tonumber(bases[tmp.key].size)

		if (tmp.dist > 200) then
			igplayers[steam].alertBaseExit = nil
			igplayers[steam].alertBaseKey = nil

			message("pm " .. steam .. " [" .. server.chatColour .. "]You have moved too far away from the base. If you still wish to do " .. server.commandPrefix .. "protect, please start again.[-]")
			faultyPlayerinfo = false
			return
		end

		if (tmp.dist > tmp.size + 15) and (tmp.dist < tmp.size + 50) then
			bases[tmp.key].exitX = intX
			bases[tmp.key].exitY = intY + 1
			bases[tmp.key].exitZ = intZ
			bases[tmp.key].protect = true
			if botman.dbConnected then conn:execute("UPDATE bases SET protect = 1 WHERE steam = " .. bases[tmp.key].steam .. " and baseNumber = " .. bases[tmp.key].baseNumber) end

			if (admin and steam ~= bases[tmp.key].steam) then
				message("pm " .. steam .. " [" .. server.chatColour .. "]You have set an exit teleport for " .. players[bases[tmp.key].steam].name .. "'s base.[-]")
			else
				message("pm " .. steam .. " [" .. server.chatColour .. "]You have set an exit teleport for your base.  You can test it with " .. server.commandPrefix .. "test base.[-]")
			end

			igplayers[steam].alertBaseExit = nil
			igplayers[steam].alertBaseKey = nil

			faultyPlayerinfo = false
			return
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	x = math.floor(igplayers[steam].xPos / 512)
	z = math.floor(igplayers[steam].zPos / 512)

	if admin and server.enableRegionPM then
		if (igplayers[steam].region ~= "r." .. x .. "." .. z .. ".7rg") then
			message("pm " .. steam .. " [" .. server.chatColour .. "]Region r." .. x .. " " .. z .. ".7rg[-]")
		end
	end

	igplayers[steam].region = region
	igplayers[steam].regionX = x
	igplayers[steam].regionZ = z

	-- timeout
	if (players[steam].timeout == true or players[steam].botTimeout == true) and igplayers[steam].spawnedInWorld then
		if (intY < 30000) then
			igplayers[steam].tp = 1
			igplayers[steam].hackerTPScore = 0
			sendCommand("tele " .. steam .. " " .. intX .. " " .. 60000 .. " " .. intZ)
		end

		faultyPlayerinfo = false
		return
	end

	-- emergency return from timeout
	if (not players[steam].timeout and not  players[steam].botTimeout) and intY > 1000 and not admin then
		igplayers[steam].tp = 1
		igplayers[steam].hackerTPScore = 0

		if players[steam].yPosTimeout == 0 then
			sendCommand("tele " .. steam .. " " .. intX .. " -1 " .. intZ)
		else
			sendCommand("tele " .. steam .. " " .. players[steam].xPosTimeout .. " " .. players[steam].yPosTimeout .. " " .. players[steam].zPosTimeout)
		end

		players[steam].xPosTimeout = 0
		players[steam].yPosTimeout = 0
		players[steam].zPosTimeout = 0
		faultyPlayerinfo = false
		return
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- add to tracker table
	dist = distancexyz(intX, intY, intZ, igplayers[steam].xPosLast, igplayers[steam].yPosLast, igplayers[steam].zPosLast)

	if (dist > 2) and tonumber(intY) < 10000 then
		-- record the players position
		if igplayers[steam].raiding then
			flag = flag .. "R"
		end

		if igplayers[steam].illegalInventory then
			flag = flag .. "B"
		end

		if igplayers[steam].flying or igplayers[steam].noclip then
			flag = flag .. "F"
		end

		--if tonumber(botman.trackingTicker) == 3 then
			connTRAK:execute("INSERT INTO tracker (steam, timestamp, x, y, z, session, flag) VALUES (" .. steam .. "," .. botman.serverTimeStamp .. "," .. intX .. "," .. intY .. "," .. intZ .. "," .. players[steam].sessionCount .. ",'" .. flag .. "')")
		--end

		if igplayers[steam].location ~= nil then
			if botman.dbConnected then connSQL:execute("INSERT INTO locationSpawns (location, x, y, z) VALUES ('" .. igplayers[steam].location .. "'," .. intX .. "," .. intY + 1 .. "," .. intZ .. ")") end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- prevent player exceeding the map limit unless they are an admin except when ignoreadmins is false
	if not isDestinationAllowed(steam, intX, intZ) then
		message("pm " .. steam .. " [" .. server.warnColour .. "]This map is restricted to " .. (settings.mapSize / 1000) .. " km from the center.[-]")

		igplayers[steam].tp = 1
		igplayers[steam].hackerTPScore = 0

		if not isDestinationAllowed(steam, igplayers[steam].xPosLastOK, igplayers[steam].zPosLastOK) then
			send ("tele " .. steam .. " 1 -1 0") -- if we don't know where to send the player, send them to the middle of the map. This should only happen rarely.
			message("pm " .. steam .. " [" .. server.warnColour .. "]You have been moved to the center of the map.[-]")
		else
			send ("tele " .. steam .. " " .. igplayers[steam].xPosLastOK .. " " .. igplayers[steam].yPosLastOK .. " " .. igplayers[steam].zPosLastOK)
		end

		faultyPlayerinfo = false
		return
	end

	if players[steam].exiled == true and locations[exile] and not players[steam].prisoner then
		if (distancexz( intX, intZ, locations[exile].x, locations[exile].z ) > tonumber(locations[exile].size)) then
			randomTP(steam, exile, true)
			faultyPlayerinfo = false
			return
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- left prison zone warning
	if (locations[prison]) then
		if (distancexz( intX, intZ, locations[prison].x, locations[prison].z ) > tonumber(locations[prison].size)) then
			if (players[steam].alertPrison == false) then
				players[steam].alertPrison = true
			end
		end

		if (players[steam].prisoner) then
			if (locations[prison]) then
				if (squareDistanceXZXZ(locations[prison].x, locations[prison].z, intX, intZ, locations[prison].size)) then
					players[steam].alertPrison = false
					randomTP(steam, prison, true)
				end
			end

			faultyPlayerinfo = false
			return
		end

		-- entered prison zone warning
		if (distancexz( intX, intZ, locations[prison].x, locations[prison].z ) < tonumber(locations[prison].size)) then
			if (players[steam].alertPrison == true) then
				if (not players[steam].prisoner) and server.showLocationMessages then
					message("pm " .. steam .. " [" .. server.warnColour .. "]You have entered the prison.  Continue at your own risk.[-]")
				end
				players[steam].alertPrison = false
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- freeze!
	if (players[steam].freeze == true) then
		dist = distancexz(posX, posZ, players[steam].prisonxPosOld, players[steam].prisonzPosOld)

		if dist > 2 then
			igplayers[steam].tp = 1
			igplayers[steam].hackerTPScore = 0
			sendCommand("tele " .. steam .. " " .. players[steam].prisonxPosOld .. " " .. players[steam].prisonyPosOld .. " " .. players[steam].prisonzPosOld)
		end

		faultyPlayerinfo = false
		return
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- remove player from location if the location is closed or their level is outside level restrictions
	if currentLocation ~= false then
		tmp = {}
		tmp.bootPlayer = false

		if not locations[currentLocation].open and not admin then
			tmp.bootPlayer = true
		end

		-- check player level restrictions on the location
		if (tonumber(locations[currentLocation].minimumLevel) > 0 or tonumber(locations[currentLocation].maximumLevel) > 0) and not admin then
			if tonumber(locations[currentLocation].minimumLevel) > 0 and data.level < tonumber(locations[currentLocation].minimumLevel) then
				tmp.bootPlayer = true
			end

			if tonumber(locations[currentLocation].minimumLevel) > 0 and tonumber(locations[currentLocation].maximumLevel) > 0 and (data.level < tonumber(locations[currentLocation].minimumLevel) or data.level > tonumber(locations[currentLocation].maximumLevel)) then
				tmp.bootPlayer = true
			end

			if tonumber(locations[currentLocation].maximumLevel) > 0 and data.level > tonumber(locations[currentLocation].maximumLevel) then
				tmp.bootPlayer = true
			end
		end

		-- check player access level restrictions on the location
		if playerAccessLevel > tonumber(locations[currentLocation].accessLevel) and not admin then
			tmp.bootPlayer = true
		end

		if tmp.bootPlayer then
			tmp = {}
			tmp.side = randSQL(4)
			tmp.offset = randSQL(50)

			if tmp.side == 1 then
				tmp.x = locations[currentLocation].x - (locations[currentLocation].size + 20 + tmp.offset)
				tmp.z = locations[currentLocation].z
			end

			if tmp.side == 2 then
				tmp.x = locations[currentLocation].x + (locations[currentLocation].size + 20 + tmp.offset)
				tmp.z = locations[currentLocation].z
			end

			if tmp.side == 3 then
				tmp.x = locations[currentLocation].x
				tmp.z = locations[currentLocation].z - (locations[currentLocation].size + 20 + tmp.offset)
			end

			if tmp.side == 4 then
				tmp.x = locations[currentLocation].x
				tmp.z = locations[currentLocation].z + (locations[currentLocation].size + 20 + tmp.offset)
			end

			tmp.cmd = "tele " .. steam .. " " .. tmp.x .. " -1 " .. tmp.z
			teleport(tmp.cmd, steam)
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- teleport lookup
	if (igplayers[steam].teleCooldown < 1) and (players[steam].prisoner == false) then
		tp = ""
		tp, match = LookupTeleport(posX, posY, posZ)
		if (tp ~= nil and teleports[tp].active == true) then
			ownerid = LookupOfflinePlayer(teleports[tp].owner)
			if (players[steam].walkies ~= true) then
				if (admin or (teleports[tp].owner == igplayers[steam].steam or teleports[tp].public == true or isFriend(ownerid, steam))) and teleports[tp].active then
					if match == 1 then
						-- check access level restrictions on the teleport
						if (playerAccessLevel >= tonumber(teleports[tp].maximumAccess) and playerAccessLevel <= tonumber(teleports[tp].minimumAccess)) or admin then
							if isDestinationAllowed(steam, teleports[tp].dx, teleports[tp].dz) then
								igplayers[steam].teleCooldown = 4
								cmd = "tele " .. steam .. " " .. teleports[tp].dx .. " " .. teleports[tp].dy .. " " .. teleports[tp].dz
								teleport(cmd, steam)

								faultyPlayerinfo = false
								return
							end
						end
					end

					if match == 2 and teleports[tp].oneway == false then
						-- check access level restrictions on the teleport
						if (playerAccessLevel >= tonumber(teleports[tp].maximumAccess) and playerAccessLevel <= tonumber(teleports[tp].minimumAccess)) or admin then
							if isDestinationAllowed(steam, teleports[tp].x, teleports[tp].z) then
								igplayers[steam].teleCooldown = 4
								cmd = "tele " .. steam .. " " .. teleports[tp].x .. " " .. teleports[tp].y .. " " .. teleports[tp].z
								teleport(cmd, steam)

								faultyPlayerinfo = false
								return
							end
						end
					end
				end
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- linked waypoint lookup
	if (igplayers[steam].teleCooldown < 1) and (players[steam].prisoner == false) then
		tmp = {}
		tmp.wpid = LookupWaypoint(posX, posY, posZ)

		if tonumber(tmp.wpid) > 0 then
			tmp.linkedID = waypoints[tmp.wpid].linked

			if (waypoints[tmp.wpid].shared and isFriend(waypoints[tmp.wpid].steam, steam) or waypoints[tmp.wpid].steam == steam) and tonumber(tmp.linkedID) > 0 then
				-- reject if not an admin and player teleporting has been disabled
				if settings.allowTeleporting and not server.disableLinkedWaypoints then
					if isDestinationAllowed(steam, waypoints[tmp.linkedID].x, waypoints[tmp.linkedID].z) then
						if players[steam].waypointCooldown < os.time() then
							if not admin then
								if tonumber(settings.waypointCost) > 0 then
									if tonumber(players[steam].cash) >= tonumber(settings.waypointCost) then
										igplayers[steam].teleCooldown = 3
										players[steam].waypointCooldown = os.time() + server.waypointCooldown
										players[steam].cash = tonumber(players[steam].cash) - settings.waypointCost

										cmd = "tele " .. steam .. " " .. waypoints[tmp.linkedID].x .. " " .. waypoints[tmp.linkedID].y .. " " .. waypoints[tmp.linkedID].z
										teleport(cmd, steam)

										faultyPlayerinfo = false
										return
									end
								else
									igplayers[steam].teleCooldown = 3
									players[steam].waypointCooldown = os.time() + settings.waypointCooldown
									cmd = "tele " .. steam .. " " .. waypoints[tmp.linkedID].x .. " " .. waypoints[tmp.linkedID].y .. " " .. waypoints[tmp.linkedID].z
									teleport(cmd, steam)

									faultyPlayerinfo = false
									return
								end
							else
								igplayers[steam].teleCooldown = 3
								cmd = "tele " .. steam .. " " .. waypoints[tmp.linkedID].x .. " " .. waypoints[tmp.linkedID].y .. " " .. waypoints[tmp.linkedID].z
								teleport(cmd, steam)

								faultyPlayerinfo = false
								return
							end
						end
					end
				else
					if admin then
						igplayers[steam].teleCooldown = 3
						cmd = "tele " .. steam .. " " .. waypoints[tmp.linkedID].x .. " " .. waypoints[tmp.linkedID].y .. " " .. waypoints[tmp.linkedID].z
						teleport(cmd, steam)

						faultyPlayerinfo = false
						return
					end
				end
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- left reset zone warning
	if (not resetZone) then
		if (players[steam].alertReset == false) then
			message("pm " .. steam .. " [" .. server.chatColour .. "]You are out of the reset zone.[-]")
			players[steam].alertReset = true
			faultyPlayerinfo = false
		end
	end


	-- entered reset zone warning
	if (resetZone) then
		if (players[steam].alertReset == true) then
			message("pm " .. steam .. " [" .. server.warnColour .. "]You are in a reset zone. Don't build here.[-]")
			players[steam].alertReset = false
			faultyPlayerinfo = false

			-- check for claims in the reset zone not owned by staff and remove them
			checkRegionClaims(x, z)
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	if	baseProtection(steam, posX, posY, posZ) and not resetZone then
		faultyPlayerinfo = false
		return
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	if (igplayers[steam].deadX ~= nil) and igplayers[steam].spawnedInWorld and igplayers[steam].spawnedReason ~= "fake reason" then
		dist = math.abs(distancexz(igplayers[steam].deadX, igplayers[steam].deadZ, posX, posZ))
		cmd = ""

		if (dist > 2) then
			igplayers[steam].deadX = nil
			igplayers[steam].deadY = nil
			igplayers[steam].deadZ = nil

			if players[steam].bed ~= "" then
				if tonumber(players[steam].bedX) ~= 0 and tonumber(players[steam].bedY) ~= 0 and tonumber(players[steam].bedZ) ~= 0 then
					cmd = "tele " .. steam .. " " .. players[steam].bedX .. " " .. players[steam].bedY .. " " .. players[steam].bedZ
					teleport(cmd, steam)
				end
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- hotspot lookup
	hotspot = LookupHotspot(posX, posY, posZ)

	if (hotspot ~= nil) then
		tmp.skipHotspot = false

		if (igplayers[steam].lastHotspot ~= hotspot) then
			for k, v in pairs(lastHotspots[steam]) do
				if v == hotspot then -- don't add or display this hotspot yet.  we've seen it recently
					tmp.skipHotspot = true
				end
			end

			if not tmp.skipHotspot then
				igplayers[steam].lastHotspot = hotspot
				message("pm " .. steam .. " [" .. server.chatColour .. "]" .. hotspots[hotspot].hotspot .. "[-]")

				if (lastHotspots[steam] == nil) then lastHotspots[steam] = {} end
				if (table.maxn(lastHotspots[steam]) > 4) then
					table.remove(lastHotspots[steam], 1)
				end

				table.insert(lastHotspots[steam],  hotspot)
			end
		end
	end


	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	if igplayers[steam].rawPosition ~= position then
		igplayers[steam].afk = os.time() + tonumber(server.idleKickTimer)
		igplayers[steam].rawPosition = position
	end

	if (tonumber(botman.playersOnline) >= tonumber(server.maxPlayers) or server.idleKickAnytime) and not admin and server.idleKick then
		if (igplayers[steam].afk - os.time() < 0) then
			kick(steam, "You were kicked because you idled too long, but you can rejoin at any time.")
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	if igplayers[steam].spawnedInWorld then
		if igplayers[steam].greet then
			if tonumber(igplayers[steam].greetdelay) > 0 then
				-- Player has spawned.  We can greet them now and do other stuff that waits for spawn
				igplayers[steam].greetdelay = 0
			end
		end

		if tonumber(igplayers[steam].teleCooldown) > 100 then
			igplayers[steam].teleCooldown = 3
		end

		if igplayers[steam].doFirstSpawnedTasks then
			igplayers[steam].doFirstSpawnedTasks = nil

			if server.botman then
				if players[steam].mute then
					mutePlayerChat(steam , "true")
				end

				if players[steam].chatColour ~= "" then
					if string.upper(string.sub(players[steam].chatColour, 1, 6)) ~= "FFFFFF" then
						setPlayerColour(steam, stripAllQuotes(players[steam].chatColour))
					else
						setChatColour(steam, players[steam].accessLevel)
					end
				else
					setChatColour(steam, players[steam].accessLevel)
				end

				-- limit ingame chat length to block chat bombs.
				cmd = steam .. ", 300"
				setPlayerChatLimit(cmd)
			end
		end
	end

	if igplayers[steam].currentLocationPVP then
		if players[steam].alertPVP == true then
			message("pm " .. steam .. " [" .. server.alertColour .. "]You have entered a PVP zone!  Players are allowed to kill you![-]")
			players[steam].alertPVP = false
			faultyPlayerinfo = false
		end
	else
		if players[steam].alertPVP == false then
			message("pm " .. steam .. " [" .. server.warnColour .. "]You have entered a PVE zone.  Do not kill other players![-]")
			players[steam].alertPVP = true
			faultyPlayerinfo = false
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug API_PlayerInfo line " .. debugger.getinfo(1).currentline) end

	-- stuff to do after everything else

	-- record this coord as the last one that the player was allowed to be at.  if their next step is not allowed, they get returned to this one.
	igplayers[steam].xPosLastOK = intX
	igplayers[steam].yPosLastOK = intY
	igplayers[steam].zPosLastOK = intZ

	faultyPlayerinfo = false

	if (steam == debugPlayerInfo) then
		if debug then dbug("end API_Playerinfo", true) end
	end
end


function readAPI_AdminList()
	local file, ln, result, data, index, count, temp, level, steam, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/adminList.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("adminlist.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	flagAdminsForRemoval()
	file = io.open(homedir .. "/temp/adminList.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)
		count = table.maxn(data)

		for con, q in pairs(conQueue) do
			if q.command == "admin list" then
				irc_chat(q.ircUser, data[1])
				irc_chat(q.ircUser, data[2])
			end
		end

		if data[3] == "" then
			botman.noAdminsDefined = true
		else
			botman.noAdminsDefined = false

			for index=3, count-1, 1 do
				temp = string.split(data[index], ":")
				temp[1] = string.trim(temp[1])
				temp[2] = string.trim(temp[2])
				level = tonumber(temp[1])
				steam = string.trim(string.sub(temp[2], 1, 18))

				-- add the steamid to the staffList table
				staffList[steam] = {}
				staffList[steam].adminLevel = tonumber(level)

				if players[steam] then
					players[steam].accessLevel = tonumber(level)
					players[steam].newPlayer = false
					players[steam].silentBob = false
					players[steam].walkies = false
					players[steam].timeout = false
					players[steam].prisoner = false
					players[steam].exiled = false
					players[steam].canTeleport = true
					players[steam].botHelp = true
					players[steam].hackerScore = 0
					players[steam].testAsPlayer = nil

					if botman.dbConnected then conn:execute("UPDATE players SET newPlayer = 0, silentBob = 0, walkies = 0, exiled = 0, canTeleport = 1, botHelp = 1, accessLevel = " .. level .. " WHERE steam = " .. steam) end

					if players[steam].botTimeout and igplayers[steam] then
						gmsg(server.commandPrefix .. "return " .. v.name)
					end
				end

				for con, q in pairs(conQueue) do
					if q.command == "admin list" then
						irc_chat(q.ircUser, data[index])
					end
				end
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == "admin list" then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/adminList.txt")

	if botman.noAdminsDefined then
		irc_chat(server.ircMain, "ALERT!  There are no admins defined in the admin list!")
	end
end


function readAPI_BanList()
	local file, ln, result, data, k, v, temp, con, q
	local bannedTo, steam, reason
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/banList.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("banlist.txt file size = " .. fileSize)
		--botman.resendBanList = true
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/banList.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if k > 2 and v ~= "" then
				if v ~= "" then
					temp = string.split(v, " - ")

					bannedTo = string.trim(temp[3] .. " " .. temp[4])
					steam = string.trim(temp[6])
					reason = ""

					if temp[8] then
						reason = string.trim(temp[8])
					end

					if botman.dbConnected then
						conn:execute("INSERT INTO bans (BannedTo, steam, reason, expiryDate) VALUES ('" .. bannedTo .. "'," .. steam .. ",'" .. escape(reason) .. "',STR_TO_DATE('" .. bannedTo .. "', '%Y-%m-%d %H:%i:%s'))")
					end

					for con, q in pairs(conQueue) do
						if q.command == "ban list" then
							irc_chat(q.ircUser, data[k])
						end
					end
				end
			else
				for con, q in pairs(conQueue) do
					if q.command == "ban list" then
						irc_chat(q.ircUser, data[k])
					end
				end
			end
		end

	end

	file:close()
	loadBans()

	for con, q in pairs(conQueue) do
		if q.command == "ban list" then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/banList.txt")
end


function readAPI_BMAnticheatReport()
	local file, ln, result, data, tmp, temp, k, v
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/bm-anticheat-report.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("bm-anticheat-report.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/bm-anticheat-report.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" and v ~= "End Report" then
				if string.find(v, "--NAME") and (not string.find(line, "unauthorized locked container")) then
					tmp = {}
					tmp.name = string.sub(v, string.find(v, "-NAME:") + 6, string.find(v, "--ID:") - 2)
					tmp.id = string.sub(v, string.find(v, "-ID:") + 4, string.find(v, "--LVL:") - 2)
					tmp.reason = "hacking"
					tmp.hack = ""
					tmp.level = string.sub(v, string.find(v, "-LVL:") + 5)
					tmp.level = string.match(tmp.level, "(-?%d+)")
					tmp.alert = string.sub(v, string.find(v, "-LVL:") + 5)
					tmp.alert = string.sub(tmp.alert, string.find(tmp.alert, " ") + 1)

					if (not staffList[tmp.id]) and (not players[tmp.id].testAsPlayer) and (not bans[tmp.id]) and (not anticheatBans[tmp.id]) then
						if string.find(v, " spawned ") then
							temp = string.split(tmp.alert, " ")
							tmp.entity = stripQuotes(temp[3])
							tmp.x = string.match(temp[4], "(-?\%d+)")
							tmp.y = string.match(temp[5], "(-?\%d+)")
							tmp.z = string.match(temp[6], "(-?\%d+)")
							tmp.hack = "spawned " .. tmp.entity .. " at " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z

							if tonumber(tmp.level) > 2 then
								irc_chat(server.ircMain, "ALERT! Unauthorised admin detected. Player " .. tmp.name .. " Steam: " .. tmp.id .. " Permission level: " .. tmp.level .. " " .. tmp.alert)
								irc_chat(server.ircAlerts, "ALERT! Unauthorised admin detected. Player " .. tmp.name .. " Steam: " .. tmp.id .. " Permission level: " .. tmp.level .. " " .. tmp.alert)
							end
						else
							tmp.x = players[tmp.id].xPos
							tmp.y = players[tmp.id].yPos
							tmp.z = players[tmp.id].zPos
							tmp.hack = "using dm at " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z

							if tonumber(tmp.level) > 2 then
								irc_chat(server.ircMain, "ALERT! Unauthorised admin detected. Player " .. tmp.name .. " Steam: " .. tmp.id .. " Permission level: " .. tmp.level .. " " .. tmp.alert)
								irc_chat(server.ircAlerts, "ALERT! Unauthorised admin detected. Player " .. tmp.name .. " Steam: " .. tmp.id .. " Permission level: " .. tmp.level .. " " .. tmp.alert)
							end
						end

						if tonumber(tmp.level) > 2 then
							anticheatBans[tmp.id] = {}
							banPlayer(tmp.id, "10 years", tmp.reason, "")
							logHacker(botman.serverTime, "Botman anticheat detected " .. tmp.id .. " " .. tmp.name .. " " .. tmp.hack)
							message("say [" .. server.chatColour .. "]Banning player " .. tmp.name .. " 10 years for using hacks.[-]")
							irc_chat("#hackers", "[BANNED] Player " .. tmp.id .. " " .. tmp.name .. " has been banned for hacking by anticheat.")
							irc_chat("#hackers", v)
							--connBots:execute("INSERT INTO events (server, serverTime, type, event, steam) VALUES ('" .. escape(server.serverName) .. "','" .. botman.serverTime .. "','player banned','Player banned by anticheat " .. escape(tmp.name) .. "'," .. tmp.id .. ")")
						end
					end
				end
			end
		end
	end

	file:close()
	os.remove(homedir .. "/temp/bm-anticheat-report.txt")
end


function readAPI_BMUptime()
	local file, ln, result, data, temp, tmp
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/bm-uptime.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("bm-uptime.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/bm-uptime.txt", "r")

	for ln in file:lines() do
		temp = string.split(ln, ":")

		-- hours
		tmp  = tonumber(string.match(temp[4], "(%d+)"))
		server.uptime = tmp * 60 * 60

		-- minutes
		tmp  = tonumber(string.match(temp[5], "(%d+)"))
		server.uptime = server.uptime + (tmp * 60)

		-- seconds
		tmp  = tonumber(string.match(temp[6], "(%d+)"))
		server.uptime = server.uptime + tmp
		server.serverStartTimestamp = os.time() - server.uptime
	end

	file:close()
	os.remove(homedir .. "/temp/bm-uptime.txt")
end


function readAPI_BMListPlayerBed()
	local file, ln, result, data, temp, pname, pid, x, y, z, i
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/bm-listplayerbed.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("bm-listplayerbed.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/bm-listplayerbed.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" then
				if not string.find(v, "The player") then
					temp = string.split(v, ": ")
					pname = temp[1]

					temp = string.split(v, ", ")
					i = table.maxn(temp)

					x = temp[i - 2]
					x = string.split(x, " ")
					x = x[table.maxn(x)]

					y = temp[i - 1]
					z = temp[i]

					pid = LookupPlayer(pname, "all")
					players[pid].bedX = x
					players[pid].bedY = y
					players[pid].bedZ = z

					if botman.dbConnected then conn:execute("UPDATE players SET bedX = " .. x .. ", bedY = " .. y .. ", bedZ = " .. z.. " WHERE steam = " .. pid) end
				else
					pid = string.sub(v, 11, string.find(v, " does ") - 1)
					players[pid].bedX = 0
					players[pid].bedY = 0
					players[pid].bedZ = 0
					if botman.dbConnected then conn:execute("UPDATE players SET bedX = 0, bedY = 0, bedZ = 0 WHERE steam = " .. pid) end
				end
			end
		end
	end

	file:close()
	os.remove(homedir .. "/temp/bm-listplayerbed.txt")
end


function readAPI_BMListPlayerFriends()
	local file, ln, result, data, temp, pname, pid, k, v
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/bm-listplayerfriends.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("bm-listplayerbed.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/bm-listplayerfriends.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			pid = string.sub(v, 15,31)
			temp=string.sub(v, string.find(v, "Friends=") + 8)

			if temp ~= "" then
				temp = string.split(temp, ",")
			end

			getBMFriends(pid, temp)
		end
	end

	file:close()
	os.remove(homedir .. "/temp/bm-listplayerfriends.txt")
end


function readAPI_BMReadConfig()

	local file, ln, result, data, fileSize, k, v

	fileSize = lfs.attributes (homedir .. "/temp/bm-config.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("bm-config.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	botman.config = {}
	file = io.open(homedir .. "/temp/bm-config.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if q.command == "bm-readconfig" then
					irc_chat(q.ircUser, v)
				end
			end

			table.insert(botman.config, v)
		end

		processBotmanConfig()
	end

	file:close()
	os.remove(homedir .. "/temp/bm-config.txt")

	for con, q in pairs(conQueue) do
		if q.command == "bm-readconfig" then
			conQueue[con] = nil
		end
	end
end


function readAPI_BMResetRegionsList()
	local file, ln, result, data, temp, x, z, fileSize, k, v

	fileSize = lfs.attributes (homedir .. "/temp/bm-resetregions-list.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("bm-resetregions-list.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	for k,v in pairs(resetRegions) do
		v.inConfig = false
	end

	file = io.open(homedir .. "/temp/bm-resetregions-list.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if q.command == "bm-resetregions list" then
					irc_chat(q.ircUser, v)
				end
			end

			if string.find(v, "r.", nil, true) then
				temp = string.split(v, "%.")
				x = temp[2]
				z = temp[3]

				if not resetRegions[v .. ".7rg"] then
					resetRegions[v .. ".7rg"] = {}
				end

				resetRegions[v .. ".7rg"].x = x
				resetRegions[v .. ".7rg"].z = z
				resetRegions[v .. ".7rg"].inConfig = true
				conn:execute("INSERT INTO resetZones (region, x, z) VALUES ('" .. escape(v .. ".7rg") .. "'," .. x .. "," .. z .. ")")
			end
		end
	end

	file:close()
	os.remove(homedir .. "/temp/bm-resetregions-list.txt")

	for con, q in pairs(conQueue) do
		if q.command == "bm-resetregions list" then
			conQueue[con] = nil
		end
	end

	-- for k,v in pairs(resetRegions) do
		-- if not v.inConfig then
			-- sendCommand("bm-resetregions add " .. v.x .. "." .. v.z)
		-- end
	-- end

	tempTimer(3, [[loadResetZones(true)]])
end


function readAPI_Command()
display("readAPI_Command()")
	local file, ln, result, curr, totalPlayersOnline, temp, data, k, v, getData
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/command.txt", "size")

	-- abort if the file is empty and switch back to using telnet
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("command.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/command.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		for con, q in pairs(conQueue) do
			if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
				if string.find(result.result, "\n") then
					data = splitCRLF(result.result)

					for k,v in pairs(data) do
						irc_chat(q.ircUser, data[k])
					end
				else
					irc_chat(q.ircUser, result.result)
				end
			end
		end

		if string.find(result.command, "admin") and not string.find(result.command, "list") then
			tempTimer( 2, [[sendCommand("admin list")]] )
		end

		if string.sub(result.result, 1, 4) == "Day " then
			gameTimeTrigger(stripMatching(result.result, "\\r\\n"))
			gameTimeTrigger(stripMatching(result.result, "\\n"))
			file:close()
			return
		end

		if string.sub(result.command, 1, 3) == "sg " then
			result.result = stripMatching(result.result, "\\r\\n")
			result.result = stripMatching(result.result, "\\n")
			matchAll(result.result)
			file:close()
			return
		end

		if result.parameters == "bot_RemoveInvalidItems" then
			removeInvalidItems()
			file:close()
			return
		end

		if string.find(result.parameters, "LagCheck") then
			matchAll("pm " .. result.parameters)
			file:close()
			return
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/command.txt")
end


function readAPI_GG()
	local file, ln, result, data, k, v, con, q, gg
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/gg.txt", "size")
	GamePrefs = {}

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		--botman.resendGG = true
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/gg.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		botman.readGG = true

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if q.command == "gg" then
					irc_chat(q.ircUser, data[k])
				end
			end

			if v ~= "" then
				matchAll(v)
			end
		end

		botman.readGG = false
	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == "gg" then
			conQueue[con] = nil
		end
	end

	if botman.dbConnected then conn:execute("INSERT INTO webInterfaceJSON (ident, recipient, json) VALUES ('GamePrefs','panel','" .. escape(yajl.to_string(GamePrefs)) .. "')") end

	os.remove(homedir .. "/temp/gg.txt")
	dbug("called initSlots by readapi_gg")
	initSlots()
end


function readAPI_GT()
	local file, ln, result, data, k, v, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/gametime.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("gametime.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/gametime.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if q.command == "gt" then
					irc_chat(q.ircUser, data[k])
				end
			end

			if v ~= "" then
				gameTimeTrigger(v)
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == "gt" then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/gametime.txt")
end


function readAPI_Help()
	local file, ln, result, data, k, v, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/help.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("help.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/help.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if string.find(q.command, "help") then
					irc_chat(q.ircUser, v)
				end
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if string.find(q.command, "help") then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/help.txt")
end


function readAPI_Inventories()
	if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

	local file, ln, result, data, k, v, index, count, steam, playerName
	local slot, quantity, quality, itemName
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/inventories.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("inventories.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

	file = io.open(homedir .. "/temp/inventories.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		count = table.maxn(result)

		--if debug then display(result) end

		for index=1, count, 1 do
			if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

			steam = result[index].steamid
			playerName = result[index].playername

			if (debug) then
				dbug("steam = " .. steam)
				dbug("playerName = " .. playerName)
			end

			if (igplayers[steam].inventoryLast ~= igplayers[steam].inventory) then
				igplayers[steam].inventoryLast = igplayers[steam].inventory
			end

			igplayers[steam].inventory = ""
			igplayers[steam].oldBelt = igplayers[steam].belt
			igplayers[steam].belt = ""
			igplayers[steam].oldPack = igplayers[steam].pack
			igplayers[steam].pack = ""
			igplayers[steam].oldEquipment = igplayers[steam].equipment
			igplayers[steam].equipment = ""

			for k,v in pairs(result[index].belt) do
				if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

				if v ~= "" then
					slot = k

					if type(v) == "table" then
						quantity = v.count
						quality = v.quality
						itemName = v.name

						igplayers[steam].inventory = igplayers[steam].inventory .. quantity .. "," .. itemName .. "," .. quality .. "|"
						igplayers[steam].belt = igplayers[steam].belt .. slot .. "," .. quantity .. "," .. itemName .. "," .. quality .. "|"
					end
				end
			end

			for k,v in pairs(result[index].bag) do
				if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

				if v ~= "" then
					slot = k

					if type(v) == "table" then
						quantity = v.count
						quality = v.quality
						itemName = v.name

						igplayers[steam].inventory = igplayers[steam].inventory .. quantity .. "," .. itemName .. "," .. quality .. "|"
						igplayers[steam].pack = igplayers[steam].pack .. slot .. "," .. quantity .. "," .. itemName .. "," .. quality .. "|"
					end
				end
			end

			for k,v in pairs(result[index].equipment) do
				if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

				if v ~= "" then
					slot = k

					if type(v) == "table" then
						quality = v.quality
						itemName = v.name
						igplayers[steam].equipment = igplayers[steam].equipment .. slot .. "," .. itemName .. "," .. quality .. "|"
					end
				end
			end

			if debug then
				dbug("belt = " .. igplayers[steam].belt)
				dbug("bag = " .. igplayers[steam].pack)
				dbug("inventory = " .. igplayers[steam].equipment)
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	if (debug) then dbug("debug readAPI_Inventories line " .. debugger.getinfo(1).currentline) end

	CheckInventory()
	os.remove(homedir .. "/temp/inventories.txt")
end


function readAPI_Hostiles()
	local file, ln, result, temp, data, k, v, cursor, errorString
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/hostiles.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("hostiles.txt file size = " .. fileSize)
		return
	end

	botman.lastServerResponseTimestamp = os.time()
	file = io.open(homedir .. "/temp/hostiles.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		for k,v in pairs(result) do
			if v ~= "" then
				loc = inLocation(v.position.x, v.position.z)

				if loc ~= false then
					if locations[loc].killZombies then
						if not server.lagged then
							removeEntityCommand(v.id)
						end
					end
				end
			end
		end
	end

	file:close()
	os.remove(homedir .. "/temp/hostiles.txt")
end


function readAPI_LE()
	local file, ln, result, temp, data, k, v, entityID, entity, cursor, errorString,  con, q, tmp
	local fileSize, i

	fileSize = lfs.attributes (homedir .. "/temp/le.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("le.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	if botman.dbConnected then
		connMEM:execute("DELETE FROM entities")
	end

	file = io.open(homedir .. "/temp/le.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		if string.find(result.result, "\n") then
			data = splitCRLF(result.result)

			for k,v in pairs(data) do
display(data[k])

				if string.find(data[k], "id=") then
					listEntities(data[k])
				end
			end
		end

	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == result.command then
			if string.find(result.result, "\n") then
				for k,v in pairs(data) do
					irc_chat(q.ircUser, data[k])
				end
			else
				irc_chat(q.ircUser, result.result)
			end
		end
	end

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/le.txt")
end


function readAPI_LKP()
	local file, ln, result, temp, data, k, v, cursor, errorString
	local name, gameID, steamID, IP, playtime, seen, p1, p2
	local pattern = "(%d+)-(%d+)-(%d+) (%d+):(%d+)"
	local runyear, runmonth, runday, runhour, runminute, seenTimestamp, tmp
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/lkp.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("lkp.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/lkp.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" then
				if string.sub(v, 1, 5) ~= "Total" then
					if botman.dbConnected then
						connSQL:execute("INSERT INTO LKPQueue (line) VALUES ('" .. escape(v) .. "')")
					end

					-- gather the data for the current player
					temp = string.split(v, ", ")

					if temp[3] ~= nil then
						steamID = string.match(temp[3], "=(-?%d+)")

						if players[steamID] then
							players[steamID].notInLKP = false
						end
					end
				end

				for con, q in pairs(conQueue) do
					if q.command == "lkp" then
						irc_chat(q.ircUser, data[k])
					end
				end
			end
		end

		if result.parameters ~= "-online" and botman.archivePlayers then
			botman.archivePlayers = nil

			--	Everyone who is flagged notInLKP gets archived.
			for k,v in pairs(players) do
				if v.notInLKP then
					if botman.dbConnected then connSQL:execute("INSERT INTO miscQueue (steam, command) VALUES ('" .. k .. "', 'archive player')") end
				end
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == "lkp" then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/lkp.txt")
end


function readAPI_LI()
	local file, ln, result, temp, data, k, v, entityID, entity, cursor, errorString, con, q
	local fileSize, updateItemsList

	fileSize = lfs.attributes (homedir .. "/temp/li.txt", "size")
	updateItemsList = false
	spawnableItems = {}

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("li.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/li.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		if result.parameters == "*" then
			updateItemsList = true
		end

		if string.find(result.result, "\n") then
			data = splitCRLF(result.result)

			for k,v in pairs(data) do
				if not string.find(data[k], " matching items.") then
					if botman.dbConnected then
						temp = string.trim(data[k])
						if temp ~= "" and updateItemsList then
							--conn:execute("INSERT INTO spawnableItems (itemName) VALUES ('" .. escape(temp) .. "')")
							spawnableItems[temp] = {}
						end
					end
				end
			end
		end

		for con, q in pairs(conQueue) do
			if string.sub(q.command, 1, 3) == "li " then
				if string.find(result.result, "\n") then
					for k,v in pairs(data) do
						temp = string.trim(data[k])
						irc_chat(q.ircUser, temp)
					end
				else
					irc_chat(q.ircUser, result.result)
				end
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	if updateItemsList then
		removeInvalidItems()
		spawnableItems = {}
		tempTimer(3, [[loadShop()]])
	end

	os.remove(homedir .. "/temp/li.txt")
end


function readAPI_LLP()
	local file, ln, result, temp, coords, data, k, v, a, b, cursor, errorString, con, q
	local steam, x, y, z, keystoneCount, region, loc, reset, expired, noPlayer, archived
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/llp.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("llp.txt file size = " .. fileSize)
		return
	end

	botman.lastServerResponseTimestamp = os.time()
	connSQL:execute("DELETE FROM keystones WHERE x = 0 AND y = 0 AND z = 0")

	file = io.open(homedir .. "/temp/llp.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		for con, q in pairs(conQueue) do
			if string.find(q.command, result.command) then
				if string.find(result.result, "\n") then
					data = splitCRLF(result.result)

					for k,v in pairs(data) do
						irc_chat(q.ircUser, data[k])
					end
				else
					irc_chat(q.ircUser, result.result)
				end
			end
		end

		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" then
				temp = splitCRLF(v)

				for a,b in pairs(temp) do
					if string.find(b, "Player ") then
						steam = string.sub(b, 9, string.find(b, ')\"') - 1)
						steam = string.sub(steam, - 17)
						noPlayer = true
						archived = false

						if string.find(b, "protected: True", nil, true) then
							expired = false
						end

						if string.find(b, "protected: False", nil, true) then
							expired = true
						end

						if players[steam] then
							noPlayer = false

							if players[steam].removedClaims == nil then
								players[steam].removedClaims = 0
							end
						end

						if playersArchived[steam] then
							noPlayer = false
							archived = true

							if playersArchived[steam].removedClaims == nil then
								playersArchived[steam].removedClaims = 0
							end
						end
					end

					if string.find(b, "owns ") and string.find(b, " keystones") then
						keystoneCount = string.sub(b, string.find(b, "owns ") + 5, string.find(b, " keystones") - 1)
						if not noPlayer then
							if not archived then
								players[steam].keystones = keystoneCount
							else
								playersArchived[steam].keystones = keystoneCount
							end
						end
					end

					if string.find(b, "location") then
						b = string.sub(b, string.find(b, "location") + 9)
						claimRemoved = false

						coords = string.split(b, ",")
						x = tonumber(coords[1])
						y = tonumber(coords[2])
						z = tonumber(coords[3])

						if tonumber(y) > 0 then
							if botman.dbConnected then
								connSQL:execute("UPDATE keystones SET removed = 0 WHERE steam = '" .. steam .. "' AND x = " .. x .. " AND y = " .. y .. " AND z = " .. z)
							end

							-- if not keystones[x .. y .. z] then
								-- keystones[x .. y .. z] = {}
								-- keystones[x .. y .. z].x = x
								-- keystones[x .. y .. z].y = y
								-- keystones[x .. y .. z].z = z
								-- keystones[x .. y .. z].steam = steam
							-- end

							-- keystones[x .. y .. z].expired = players[steam].claimsExpired
							-- keystones[x .. y .. z].removed = 0
							-- keystones[x .. y .. z].remove = false

							if not noPlayer then
								if not archived then
									if players[steam].removeClaims or (expired and server.removeExpiredClaims) then
										keystones[x .. y .. z].remove = true
									end
								else
									if playersArchived[steam].removeClaims or (expired and server.removeExpiredClaims) then
										keystones[x .. y .. z].remove = true
									end
								end
							else
								if expired and server.removeExpiredClaims then
									keystones[x .. y .. z].remove = true
								end
							end

							if not isAdmin(steam) then
								region = getRegion(x, z)
								loc, reset = inLocation(x, z)

								if not noPlayer then
									if not archived then
										if (resetRegions[region] or reset or players[steam].removeClaims) and not players[steam].testAsPlayer then
											claimRemoved = true
											if botman.dbConnected then connSQL:execute("INSERT INTO persistentQueue (steam, command, timerDelay) VALUES ('" .. steam .. "','" .. connMEM:escape("rlp " .. x .. " " .. y .. " " .. z) .. "','" .. os.time() + 5 .. "')") end

											--if botman.dbConnected then conn:execute("INSERT INTO keystones (steam, x, y, z, remove, removed, expired) VALUES (" .. steam .. "," .. x .. "," .. y .. "," .. z .. ", 1, 0," .. dbBool(expired) .. ") ON DUPLICATE KEY UPDATE remove = 1, removed = 0, expired = " .. dbBool(expired)) end
										else
											if botman.dbConnected then connSQL:execute("INSERT INTO keystones (steam, x, y, z, expired) VALUES ('" .. steam .. "'," .. x .. "," .. y .. "," .. z .. "," .. dbBool(expired) .. ")") end
										end
									else
										if (resetRegions[region] or reset or playersArchived[steam].removeClaims) and not playersArchived[steam].testAsPlayer then
											claimRemoved = true
											if botman.dbConnected then connSQL:execute("INSERT INTO persistentQueue (steam, command, timerDelay) VALUES ('" .. steam .. "','" .. connMEM:escape("rlp " .. x .. " " .. y .. " " .. z) .. "','" .. os.time() + 5 .. "')") end

											--if botman.dbConnected then conn:execute("INSERT INTO keystones (steam, x, y, z, remove, removed, expired) VALUES (" .. steam .. "," .. x .. "," .. y .. "," .. z .. ", 1, 0," .. dbBool(expired) .. ") ON DUPLICATE KEY UPDATE remove = 1, removed = 0, expired = " .. dbBool(expired)) end
										else
											if botman.dbConnected then connSQL:execute("INSERT INTO keystones (steam, x, y, z, expired) VALUES ('" .. steam .. "'," .. x .. "," .. y .. "," .. z .. "," .. dbBool(expired) .. ")") end
										end
									end
								else
									if (resetRegions[region] or reset) and server.removeExpiredClaims then
										claimRemoved = true
										if botman.dbConnected then connSQL:execute("INSERT INTO persistentQueue (steam, command, timerDelay) VALUES ('" .. steam .. "','" .. connMEM:escape("rlp " .. x .. " " .. y .. " " .. z) .. "','" .. os.time() + 5 .. "')") end

										--if botman.dbConnected then conn:execute("INSERT INTO keystones (steam, x, y, z, remove, removed, expired) VALUES (" .. steam .. "," .. x .. "," .. y .. "," .. z .. ", 1, 0," .. dbBool(expired) .. ") ON DUPLICATE KEY UPDATE remove = 1, removed = 0, expired = " .. dbBool(expired)) end
									else
										if botman.dbConnected then connSQL:execute("INSERT INTO keystones (steam, x, y, z, expired) VALUES ('" .. steam .. "'," .. x .. "," .. y .. "," .. z .. "," .. dbBool(expired) .. ")") end
									end
								end
							else
								if botman.dbConnected then connSQL:execute("INSERT INTO keystones (steam, x, y, z, expired) VALUES ('" .. steam .. "'," .. x .. "," .. y .. "," .. z .. "," .. dbBool(expired) .. ")") end
							end

							if not claimRemoved then
								if not keystones[x .. y .. z] then
									keystones[x .. y .. z] = {}
									keystones[x .. y .. z].x = x
									keystones[x .. y .. z].y = y
									keystones[x .. y .. z].z = z
									keystones[x .. y .. z].steam = steam
								end

								keystones[x .. y .. z].removed = 0
								keystones[x .. y .. z].remove = false

								if archived then
									keystones[x .. y .. z].expired = playersArchived[steam].claimsExpired
								else
									if not noPlayer then
										keystones[x .. y .. z].expired = players[steam].claimsExpired
									else
										keystones[x .. y .. z].expired = true
									end
								end
							end
						end
					end
				end
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/llp.txt")
end


function readAPI_LPF()
	local file, ln, result, data, k, v, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/lpf.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("lpf.txt file size = " .. fileSize)
		return
	end

	botman.lastServerResponseTimestamp = os.time()
	file = io.open(homedir .. "/temp/lpf.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if string.sub(q.command, 1, 3) == "lpf" then
					irc_chat(q.ircUser, data[k])
				end
			end

			if not string.find(v, "Player") and v ~= "" then
				getFriends(v)
			end
		end
	end

	file:close()

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/lpf.txt")
end


function readAPI_PlayersOnline()
	local file, ln, result, index, totalPlayersOnline, con, q
	local fileSize, k, v

	fileSize = lfs.attributes (homedir .. "/temp/playersOnline.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("playersOnline.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/playersOnline.txt", "r")
	playersOnlineList = {}

	if botman.trackingTicker == nil then
		botman.trackingTicker = 0
	end

	botman.trackingTicker = botman.trackingTicker + 1

	for ln in file:lines() do
		result = yajl.to_value(ln)

		if result == "[]" then
			botman.playersOnline =	0
		else
			botman.playersOnline = table.maxn(result)
		end

		for index=1, botman.playersOnline, 1 do
			playersOnlineList[result[index].steamid] = {}
			API_PlayerInfo(result[index])

			for con, q in pairs(conQueue) do
				if q.command == "lp" then
					irc_chat(q.ircUser, data[k])
				end
			end
		end
	end

	if tonumber(botman.trackingTicker) > 2 then
		botman.trackingTicker = 0
	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == "lp" then
			conQueue[con] = nil
		end
	end

	for k,v in pairs(igplayers) do
		if not playersOnlineList[k] then
			v.killTimer = 2
		end
	end

	if botman.initReservedSlots then
		initSlots()
		botman.initReservedSlots = false
	end

	os.remove(homedir .. "/temp/playersOnline.txt")
end


function readAPI_PGD()
	local file, ln, result, data, k, v
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/pgd.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	end

	botman.lastServerResponseTimestamp = os.time()
	file = io.open(homedir .. "/temp/pgd.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" then
				matchAll(v)
			end
		end

	end

	file:close()
	os.remove(homedir .. "/temp/pgd.txt")
end


function readAPI_PUG()
	local file, ln, result, data, k, v
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/pug.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("pug.txt file size = " .. fileSize)
		return
	end

	botman.lastServerResponseTimestamp = os.time()
	file = io.open(homedir .. "/temp/pug.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" then
				matchAll(v)
			end
		end

	end

	file:close()
	os.remove(homedir .. "/temp/pug.txt")
end


function writeAPILog(line)
	-- log the chat
	file = io.open(homedir .. "/log/" .. os.date("%Y_%m_%d") .. "_API_log.txt", "a")
	file:write(botman.serverTime .. "; " .. string.trim(line) .. "\n")
	file:close()
end


function readAPI_ReadLog()
	local file, fileSize, ln, result, temp, data, k, v
	local uptime, date, time, msg, handled

	fileSize = lfs.attributes (homedir .. "/temp/log.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
		-- botman.lastAPIResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/log.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		botman.lastLogLine = tonumber(result.lastLine) - 1

		for k,v in pairs(result.entries) do
			msg = v.msg

			uptime = v.uptime
			date = v.date
			time = v.time

			if botman.serverTime == "" or botman.serverTimeStamp == 0 then
				botman.serverTime = date .. " " .. time
				botman.serverTimeStamp = dateToTimestamp(botman.serverTime)
				handled = false

				writeAPILog(msg)

				botman.serverHour = string.sub(time, 1, 2)
				botman.serverMinute = string.sub(time, 4, 5)
				specialDay = ""

				if (string.find(botman.serverTime, "02-14", 5, 10)) then specialDay = "valentine" end
				if (string.find(botman.serverTime, "12-25", 5, 10)) then specialDay = "christmas" end
			end

			if server.dateTest == nil then
				server.dateTest = date
			end

			if string.find(msg, "Chat:", nil, true) or string.find(msg, "Chat (from", nil, true) then --  and not string.find(msg, " to 'Party')", nil, true) and not string.find(msg, " to 'Friend')", nil, true)
				gmsg(msg)
				handled = true
			end

			if string.find(msg, "Executing command 'pm ", nil, true) or string.find(msg, "Denying command 'pm", nil, true) then
				gmsg(msg)
				handled = true
			end

			if string.find(msg, "Chat command from", nil, true) then --  or string.find(msg, "GMSG:", nil, true)
				gmsg(msg)
				handled = true
			end

			if not handled then
				if string.find(msg, "denied: Too many players on the server!", nil, true) then
					playerDenied(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "Player connected") then
					playerConnected(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "Player disconnected") then
					playerDisconnected(msg)
					handled = true
				end
			end

			if not handled then
				if server.enableScreamerAlert then
					if string.find(msg, "AIDirector: Spawning scouts", nil, true) then
						scoutsWarning(msg)
						handled = true
					end
				end
			end

			if not handled then
				if string.find(msg, "Telnet executed 'tele ", nil, true) or string.find(msg, "Executing command 'tele ", nil, true) then
					teleTrigger(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "Heap:", nil, true) then
					memTrigger(msg)
					handled = true
				end
			end

			if not handled then
				if string.sub(msg, 1, 4) == "Day " then
					gameTimeTrigger(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "INF Player with ID") then
					overstackTrigger(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "banned until") then
					collectBan(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "Executing command 'ban remove", nil, true) then
					unbanPlayer(msg)
					handled = true
				end
			end

			if not handled then
				if string.find(msg, "eliminated") or string.find(msg, "killed by") then
					pvpPolice(msg)
					handled = true
				end
			end

			if not handled then
				if server.enableAirdropAlert then
					if string.find(msg, "AIAirDrop: Spawned supply crate") then
						airDropAlert(msg)
						handled = true
					end
				end
			end


			if not handled then
				matchAll(msg, date, time)
			end
		end
	end

	file:close()
	os.remove(homedir .. "/temp/log.txt")
end


function readAPI_SE()
	local file, ln, result, temp, data, k, v, getData, entityID, entity, cursor, errorString
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/se.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("se.txt file size = " .. fileSize)
		return
	end

	botman.lastServerResponseTimestamp = os.time()
	file = io.open(homedir .. "/temp/se.txt", "r")
	getData = false

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			for con, q in pairs(conQueue) do
				if q.command == "se" then
					irc_chat(q.ircUser, data[k])
				end
			end

			if (string.find(v, "please specify one of the entities")) then
				-- flag all the zombies for removal so we can detect deleted zeds
				if botman.dbConnected then
					conn:execute("UPDATE gimmeZombies SET remove = 1")
					conn:execute("UPDATE otherEntities SET remove = 1")
				end

				getData = true
			else
				if getData then
					if v ~= "" then
						temp = string.split(v, "-")

						entityID = string.trim(temp[1])
						entity = string.trim(temp[2])

						if string.find(v, "ombie") then
							if botman.dbConnected then conn:execute("INSERT INTO gimmeZombies (zombie, entityID) VALUES ('" .. entity .. "'," .. entityID .. ") ON DUPLICATE KEY UPDATE remove = 0") end
							updateGimmeZombies(entityID, entity)
						else
							if botman.dbConnected then conn:execute("INSERT INTO otherEntities (entity, entityID) VALUES ('" .. entity .. "'," .. entityID .. ") ON DUPLICATE KEY UPDATE remove = 0") end
							updateOtherEntities(entityID, entity)
						end
					end
				end
			end
		end
	end

	file:close()

	if botman.dbConnected then conn:execute("DELETE FROM gimmeZombies WHERE remove = 1 OR zombie LIKE '%Template%'") end
	loadGimmeZombies()

	if botman.dbConnected then conn:execute("DELETE FROM otherEntities WHERE remove = 1 OR entity LIKE '%Template%' OR entity LIKE '%invisible%'") end
	loadOtherEntities()

	if botman.dbConnected then
		cursor,errorString = conn:execute("SELECT MAX(entityID) AS maxZeds FROM gimmeZombies")
		row = cursor:fetch({}, "a")
		botman.maxGimmeZombies = tonumber(row.maxZeds)
	end

	for con, q in pairs(conQueue) do
		if (q.command == result.command) or (q.command == result.command .. " " .. result.parameters) then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/se.txt")
end


function readAPI_MEM()
	local file, ln, result, data, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/mem.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("mem.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/mem.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)

		for con, q in pairs(conQueue) do
			if q.command == result.command then
				if string.find(result.result, "\n") then
					data = splitCRLF(result.result)

					for k,v in pairs(data) do
						irc_chat(q.ircUser, data[k])
					end
				else
					irc_chat(q.ircUser, result.result)
				end
			end
		end

		data = stripMatching(result.result, "\\r\\n")
		data = stripMatching(result.result, "\\n")
		memTrigger(data)
	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == result.command then
			conQueue[con] = nil
		end
	end

	os.remove(homedir .. "/temp/mem.txt")
end


function readAPI_webUIUpdates()
	local file, ln, result, data, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/webUIUpdates.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
		return
	else
		if botman.botOffline then
			irc_chat(server.ircMain, "The bot has connected to the server API.")
		end

		if botman.APIOffline then
			botman.APIOffline = false
		end

		toggleTriggers("api online")

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	file = io.open(homedir .. "/temp/webUIUpdates.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		result.newlogs = tonumber(result.newlogs)

		if botman.lastLogLine == nil then
			botman.lastLogLine = result.newlogs
		end

		if result.newlogs < botman.lastLogLine then
			botman.lastLogLine = 0

			if result.newlogs - botman.lastLogLine > 500 then
				botman.lastLogLine = result.newlogs - 100
			end
		end

		if result.newlogs >= botman.lastLogLine then
			botman.lastLogLine = botman.lastLogLine + 1

			if result.newlogs - botman.lastLogLine > 500 and os.time() - botman.lastAPIResponseTimestamp > 30 then
				botman.lastLogLine = result.newlogs - 100
			end

			getAPILog()
		end

		if tonumber(result.players) >= 0 then
			botman.playersOnline = tonumber(result.players)
		else
			botman.playersOnline = 0
		end
	end

	file:close()
	os.remove(homedir .. "/temp/webUIUpdates.txt")
end


function readAPI_Version()
	local file, ln, result, data, k, v, con, q
	local fileSize

	fileSize = lfs.attributes (homedir .. "/temp/installedMods.txt", "size")

	-- abort if the file is empty
	if fileSize == nil or tonumber(fileSize) == 0 then
dbugi("installedMods.txt file size = " .. fileSize)
		return
	else
		if botman.APIOffline then
			botman.APIOffline = false
			toggleTriggers("api online")
		end

		botman.botOffline = false
		botman.botOfflineCount = 0
		botman.lastServerResponseTimestamp = os.time()
	end

	modVersions = {}
	server.allocs = false
	server.botman = false
	server.otherManager = false

	file = io.open(homedir .. "/temp/installedMods.txt", "r")

	for ln in file:lines() do
		result = yajl.to_value(ln)
		data = splitCRLF(result.result)

		for k,v in pairs(data) do
			if v ~= "" then
				matchAll(v)
			end

			for con, q in pairs(conQueue) do
				if q.command == "version" then
					irc_chat(q.ircUser, data[k])
				end
			end
		end

	end

	file:close()

	for con, q in pairs(conQueue) do
		if q.command == "version" then
			conQueue[con] = nil
		end
	end

	if server.allocs and server.botman then
		botMaintenance.modsInstalled = true
	else
		botMaintenance.modsInstalled = false
	end

	saveBotMaintenance()

	if botman.dbConnected then
		conn:execute("DELETE FROM webInterfaceJSON WHERE ident = 'modVersions'")
		conn:execute("INSERT INTO webInterfaceJSON (ident, recipient, json) VALUES ('modVersions','panel','" .. escape(yajl.to_string(modVersions)) .. "')")
	end

	os.remove(homedir .. "/temp/installedMods.txt")
	table.save(homedir .. "/data_backup/modVersions.lua", modVersions)
end
