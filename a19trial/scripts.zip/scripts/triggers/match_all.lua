--[[
    Botman - A collection of scripts for managing 7 Days to Die servers
    Copyright (C) 2020  Matthew Dwyer
	           This copyright applies to the Lua source code in this Mudlet profile.
    Email     smegzor@gmail.com
    URL       https://botman.nz
    Source    https://bitbucket.org/mhdwyer/botman
--]]

local debug

-- enable debug to see where the code is stopping. Any error will be after the last debug line.
debug = false -- should be false unless testing

function matchAll(line, logDate, logTime)
	local pname, pid, number, died, coords, words, temp, msg, claimRemoved
	local dy, mth, yr, hr, min, sec, pm, reason, timestamp, banDate
	local fields, values, x, y, z, id, loc, reset, steam, k, v, rows, tmp
	local pref, value, isChat, cmd
	local cursor, errorString

	if botman.debugAll then
		--debug = true
	end

if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	-- set counter to help detect the bot going offline
	botman.botOfflineCount = 0
	botman.botOffline = false
	botman.lastServerResponseTimestamp = os.time()

	isChat = false

	if botman.botDisabled then
		return
	end

	if botman.getMetrics then
		metrics.telnetLines = metrics.telnetLines + 1
	end

	if string.find(line, "StackTrace:") then -- ignore lines containing this.
		if botman.getMetrics then
			metrics.errors = metrics.errors + 1

			if not metrics.errorStackTrace then
				metrics.errorStackTrace = true
				metrics.errorLines[metrics.errorLinesCount] = line
				metrics.errorLinesCount = metrics.errorLinesCount + 1
			end
		end

		return
	end

	if string.find(line, "SleeperVolume") then -- ignore lines containing this.
		return
	end

	if string.find(line, "ERR ") then -- ignore lines containing this.
		if botman.getMetrics then
			metrics.errors = metrics.errors + 1

			if not metrics.errorERR then
				metrics.errorERR = true
				metrics.errorLines[metrics.errorLinesCount] = line
				metrics.errorLinesCount = metrics.errorLinesCount + 1
			end
		end

		return
	end

if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	-- monitor falling blocks so we can report if it gets excessive in a region
	if string.find(line, "EntityFallingBlock") then
		temp = string.split(line, ",")
		x = string.sub(temp[2], string.find(temp[2], "pos=") + 5)
		y = string.trim(temp[3])
		z = string.trim(string.sub(temp[4], 1, string.len(temp[4]) - 1))
		x = math.floor(x)
		y = math.floor(y)
		z = math.floor(z)

		temp = getRegion(x,z)
		if not fallingBlocks[temp] then
			fallingBlocks[temp] = {}
			fallingBlocks[temp].count = 1
			fallingBlocks[temp].x = x
			fallingBlocks[temp].y = y
			fallingBlocks[temp].z = z
		else
			fallingBlocks[temp].count = fallingBlocks[temp].count + 1
			fallingBlocks[temp].x = x
			fallingBlocks[temp].y = y
			fallingBlocks[temp].z = z
		end

		return
	end


	if string.find(line, "WRN Invalid Admintoken used from", nil, true) and string.find(line, server.botsIP, nil, true) then
		if server.useAllocsWebAPI then
			botman.APIOffline = false
			toggleTriggers("api offline")
		end

		if not botman.webTokensListSent then
			send("webtokens list")
			botman.webTokensListSent = os.time()
		else
			if os.time() - botman.webTokensListSent > 60 then
				send("webtokens list")
				botman.webTokensListSent = os.time()
			end
		end

		return
	end


	if string.find(line, "WRN ") then -- ignore lines containing this.
		if not string.find(line, "DENSITYMISMATCH") then

			return
		end
	end

	if string.find(line, "NaN") then -- ignore lines containing this.
		if botman.getMetrics then
			metrics.errors = metrics.errors + 1

			if not metrics.errorNAN then
				metrics.errorNAN = true
				metrics.errorLines[metrics.errorLinesCount] = line
				metrics.errorLinesCount = metrics.errorLinesCount + 1
			end
		end

		return
	end

	if string.find(line, "INF Delta out") then -- ignore lines containing this.
		if botman.getMetrics then
			metrics.errors = metrics.errors + 1

			if not metrics.errorDelta then
				metrics.errorDelta = true
				metrics.errorLines[metrics.errorLinesCount] = line
				metrics.errorLinesCount = metrics.errorLinesCount + 1
			end
		end

		return
	end

	if string.find(line, "INF Missing ") then -- ignore lines containing this.
		if botman.getMetrics then
			metrics.errors = metrics.errors + 1
		end

		return
	end

	if string.find(line, "INF Error ") then -- ignore lines containing this.
		if botman.getMetrics then
			metrics.errors = metrics.errors + 1

			if not metrics.errorINFError then
				metrics.errorINFError = true
				metrics.errorLines[metrics.errorLinesCount] = line
				metrics.errorLinesCount = metrics.errorLinesCount + 1
			end
		end

		return
	end

	if string.find(line, "IndexOutOfRangeException") then -- ignore lines containing this.
		if botman.getMetrics then
			metrics.errors = metrics.errors + 1

			if not metrics.errorIndex then
				metrics.errorIndex = true
				metrics.errorLines[metrics.errorLinesCount] = line
				metrics.errorLinesCount = metrics.errorLinesCount + 1
			end
		end

		return
	end

	if string.find(line, "Unbalanced") then -- ignore lines containing this.
		if botman.getMetrics then
			metrics.errors = metrics.errors + 1

			if not metrics.errorUnbalanced then
				metrics.errorUnbalanced = true
				metrics.errorLines[metrics.errorLinesCount] = line
				metrics.errorLinesCount = metrics.errorLinesCount + 1
			end
		end

		return
	end

	if string.find(line, "->") then -- ignore lines containing this.
		return
	end

if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	if string.find(line, "NullReferenceException:") then -- ignore lines containing this.
		if botman.getMetrics then
			metrics.errors = metrics.errors + 1

			if not metrics.errorNULREF then
				metrics.errorNULREF = true
				metrics.errorLines[metrics.errorLinesCount] = line
				metrics.errorLinesCount = metrics.errorLinesCount + 1
			end
		end

		return
	end

if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	if server.readLogUsingTelnet then
		logTelnet(line)
	end

if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	if string.find(line, "Chat") or string.find(line, "BCM") then
		isChat = true
	end

	if customMatchAll ~= nil then
		-- read the note on overriding bot code in custom/custom_functions.lua
		if customMatchAll(line) then

			return
		end
	end

	if string.find(line, "*** ERROR: unknown command 'webtokens'") then -- revert to using telnet
		if server.useAllocsWebAPI then
			server.useAllocsWebAPI = false
			conn:execute("UPDATE server set useAllocsWebAPI = 0")
			irc_chat(server.ircMain, "Alloc's mod missing or not fully installed.  The bot is using telnet.")
		end

		return
	end


	if string.find(line, "*** ERROR: Executing command 'admin'") then -- abort processing the admin list
		-- abort reading admin list
		getAdminList = nil

		return
	end

	if string.find(line, "WRN ") then

		return
	end

if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	-- grab the server time
	if string.find(line, "INF ") then
		if string.find(string.sub(line, 1, 19), os.date("%Y")) then
			botman.serverTime = string.sub(line, 1, 10) .. " " .. string.sub(line, 12, 19)

			if botman.serverTimeStamp == 0 then
				botman.serverTimeStamp = dateToTimestamp(botman.serverTime)

				if not botman.serverTimeSync then
					botman.serverTimeSync = 0
				end

				if botman.serverTimeSync == 0 then
					botman.serverTimeSync = -(os.time() - botman.serverTimeStamp)
				end
			end

			botman.serverHour = string.sub(line, 12, 13)
			botman.serverMinute = string.sub(line, 15, 16)
			specialDay = ""

			if (string.find(botman.serverTime, "02-14", 5, 10)) then specialDay = "valentine" end
			if (string.find(botman.serverTime, "12-25", 5, 10)) then specialDay = "christmas" end

			if server.dateTest == nil then
				server.dateTest = string.sub(botman.serverTime, 1, 10)
			end
		end
	end

if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	if (string.sub(line, 1, 4) == os.date("%Y")) then
		badPlayerJoined = false
		badJoinLine = ""

		if readAnticheat then
			readAnticheat = nil
		end

		if botman.readGG then
			botman.readGG = false -- must be false not nil

			if botman.dbConnected then conn:execute("INSERT INTO webInterfaceJSON (ident, recipient, json) VALUES ('GamePrefs','panel','" .. escape(yajl.to_string(GamePrefs)) .. "')") end

			if botman.initReservedSlots then
				initSlots()
				botman.initReservedSlots = false
			else
				-- setup or adjust the number of slots in the slots table
				addOrRemoveSlots()
			end
		end

		if readWebTokens then
			readWebTokens = nil

			if not botTokenFound then
				botTokenFound = nil

				if server.useAllocsWebAPI then
					server.allocsWebAPIPassword = generatePassword(20)
					conn:execute("UPDATE server set allocsWebAPIUser = 'bot', allocsWebAPIPassword = '" .. escape(server.allocsWebAPIPassword) .. "'")
					botman.APIOffline = false
					toggleTriggers("api offline")
					send("webtokens add bot " .. server.allocsWebAPIPassword .. " 0")
					botman.lastBotCommand = "webtokens add bot"
				end
			end
		end
	end

	if not server.useAllocsWebAPI then
		if (string.sub(line, 1, 4) == os.date("%Y")) then
			if echoConsole then
				echoConsole = false
				echoConsoleTo = nil
			end

			if readResetRegions then
				tempTimer(3, [[loadResetZones(true)]])
			end

			readResetRegions = nil
			readWebTokens = nil
			botTokenFound = nil
			botman.listItems = false

			if getZombies then
				getZombies = nil

				if botman.dbConnected then conn:execute("DELETE FROM gimmeZombies WHERE remove = 1 OR zombie LIKE '%Template%'") end
				loadGimmeZombies()

				if botman.dbConnected then conn:execute("DELETE FROM otherEntities WHERE remove = 1 OR entity LIKE '%Template%' OR entity LIKE '%invisible%'") end
				loadOtherEntities()
			end

			if collectBans then
				collectBans = false
				loadBans()
			end

			if readVersion then
				readVersion = nil
				resetVersion = nil
				table.save(homedir .. "/data_backup/modVersions.lua", modVersions)
				if botman.dbConnected then conn:execute("INSERT INTO webInterfaceJSON (ident, recipient, json) VALUES ('modVersions','panel','" .. escape(yajl.to_string(modVersions)) .. "')") end

				if server.allocs and server.botman then
					botMaintenance.modsInstalled = true
				else
					botMaintenance.modsInstalled = false
				end

				if botman.dbConnected then conn:execute("DELETE FROM webInterfaceJSON WHERE ident = 'modVersions'") end
				if botman.dbConnected then conn:execute("INSERT INTO webInterfaceJSON (ident, recipient, json) VALUES ('modVersions','panel','" .. escape(yajl.to_string(modVersions)) .. "')") end
				saveBotMaintenance()

				-- automatically register command help and create a new help.txt file in the temp folder of the bot's daily logs web folder.
				botman.registerHelp	= true
				gmsg(server.commandPrefix .. "register help")
			end
		end

		if echoConsole and echoConsoleTo then
			line = line:gsub(",", "") -- strip out commas
			irc_chat(echoConsoleTo, line)
		end
	end


	-- grab steam ID of player joining server if the server is using reserved slots
	if tonumber(server.reservedSlots) > 0 then
		if string.find(line, "INF Steam authentication successful, allowing user") then
			temp = string.split(line, ",")
			pid = string.sub(temp[3], 12, string.len(temp[3]) -1)

			playerConnected(line)

			return
		end
	end


	if string.find(line, "PlayerSpawnedInWorld") then
		tmp = {}

		tmp.coords = string.sub(line, string.find(line, "position:") + 10, string.find(line, ")") -1)
		tmp.coords = tmp.coords:gsub(",", "")
		tmp.spawnedReason = "N/A"

		temp = string.split(line, ", ")
		tmp.pid = string.match(temp[5], "(-?%d+)")

		if igplayers[tmp.pid] then
			igplayers[tmp.pid].spawnedInWorld = true

			if igplayers[tmp.pid].spawnedCoordsOld == "0 0 0" then
				igplayers[tmp.pid].spawnedCoordsOld = igplayers[tmp.pid].spawnedCoords
				igplayers[tmp.pid].spawnedCoords = tmp.coords
				igplayers[tmp.pid].spawnChecked = true
			else
				igplayers[tmp.pid].spawnedCoords = tmp.coords

				if igplayers[tmp.pid].spawnedCoordsOld ~= igplayers[tmp.pid].spawnedCoords then
					igplayers[tmp.pid].tp = tonumber(igplayers[tmp.pid].tp) - 1
				end

				if string.sub(players[tmp.pid].lastCommand, 2, 4) == "bag" then
					igplayers[tmp.pid].tp = tonumber(igplayers[tmp.pid].tp) + 1
					igplayers[tmp.pid].spawnChecked = true
				end
			end

			temp = string.split(tmp.coords, " ")
			igplayers[tmp.pid].spawnedXPos = temp[1]
			igplayers[tmp.pid].spawnedYPos = temp[2]
			igplayers[tmp.pid].spawnedZPos = temp[3]
		end

		if string.find(line, "reason: Died") then
			tmp.spawnedReason = "died"
			igplayers[tmp.pid].spawnChecked = true
			igplayers[tmp.pid].teleCooldown = 3
		end

		if string.find(line, "reason: JoinMultiplayer") then
			tmp.spawnedReason = "joined"
			igplayers[tmp.pid].spawnChecked = true
			igplayers[tmp.pid].teleCooldown = 3
			irc_chat(server.ircMain, "Player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " spawned at " .. igplayers[tmp.pid].spawnedXPos .. " " .. igplayers[tmp.pid].spawnedYPos .. " " .. igplayers[tmp.pid].spawnedZPos)
			irc_chat(server.ircAlerts, "Player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " spawned at " .. igplayers[tmp.pid].spawnedXPos .. " " .. igplayers[tmp.pid].spawnedYPos .. " " .. igplayers[tmp.pid].spawnedZPos)

			if players[tmp.pid].accessLevel == 0 and not server.allocs then
				message("pm " .. tmp.pid .. " [" .. server.warnColour .. "]ALERT! The bot requires Alloc's mod but it appears to be missing. The bot will not work well without it.[-]")
			end

			if server.botman then
				if players[tmp.pid].nameOverride ~= "" then
					setOverrideChatName(tmp.pid, players[tmp.pid].nameOverride)
				end

				tmp.namePrefix = LookupSettingValue(tmp.pid, "namePrefix")

				if tmp.namePrefix ~= "" then
					setOverrideChatName(tmp.pid, tmp.namePrefix .. players[tmp.pid].name)
				end
			end
		end

		if string.find(line, "reason: Teleport") then
			tmp.spawnedReason = "teleport"

			if igplayers[tmp.pid].spawnPending then
				igplayers[tmp.pid].spawnChecked = true
			else
				igplayers[tmp.pid].spawnChecked = false
			end
		end

		igplayers[tmp.pid].spawnPending = false
		igplayers[tmp.pid].spawnedReason = tmp.spawnedReason
	end


	if string.find(line, "GamePref.", nil, true) then
		if not botman.readGG then
			GamePrefs = {}
		end

		botman.readGG = true
	end


	if string.find(line, "type=Entity") then
		listEntities(line)

		return
	end

if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	-- look for general stuff
	died = false
	if (string.find(line, "INF GMSG") and string.find(line, "eliminated")) then
		nameStart = string.find(line, "eliminated ") + 11
		pname = stripQuotes(string.trim(string.sub(line, nameStart)))
		died = true
	end

	if (string.find(line, "INF GMSG") and string.find(line, "killed by")) then
		nameStart = string.sub(line, string.find(line, "Player ") + 8, string.find(line, "killed by ") - 1)
		pname = stripQuotes(string.trim(nameStart))
		died = true
	end

if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end


	if (string.find(line, "GMSG: Player") and string.find(line, " died")) then
		pname = string.sub(line, string.find(line, "GMSG") + 14, string.len(line) - 6)
		pname = stripQuotes(string.trim(pname))
		died = true
	end

	if died then
		pid = LookupPlayer(pname, "all")

		if (pid ~= 0) then
			if botman.dbConnected then conn:execute("INSERT INTO events (x, y, z, serverTime, type, event, steam) VALUES (" .. igplayers[pid].xPos .. "," .. igplayers[pid].yPos .. "," .. igplayers[pid].zPos .. ",'" .. botman.serverTime .. "','death','" .. escape(pname) .. " died'," .. pid .. ")") end

			igplayers[pid].tp = 1
			igplayers[pid].hackerTPScore = 0
			igplayers[pid].deadX = igplayers[pid].xPos
			igplayers[pid].deadY = igplayers[pid].yPos
			igplayers[pid].deadZ = igplayers[pid].zPos
			igplayers[pid].teleCooldown = 1000
			igplayers[pid].spawnedInWorld = false

			players[pid].deathX = igplayers[pid].xPos
			players[pid].deathY = igplayers[pid].yPos
			players[pid].deathZ = igplayers[pid].zPos

			tmp.deathCost = LookupSettingValue(pid, "deathCost")

			if tonumber(tmp.deathCost) > 0 then
				players[pid].cash = tonumber(players[pid].cash) - tmp.deathCost

				if tonumber(players[pid].cash) < 0 then
					players[pid].cash = 0
				end
			end

			irc_chat(server.ircMain, "Player " .. pid .. " name: " .. pname .. "'s death recorded at " .. igplayers[pid].deadX .. " " .. igplayers[pid].deadY .. " " .. igplayers[pid].deadZ)
			irc_chat(server.ircAlerts, "Player " .. pid .. " name: " .. pname .. "'s death recorded at " .. igplayers[pid].deadX .. " " .. igplayers[pid].deadY .. " " .. igplayers[pid].deadZ)

			tmp.packCooldown = LookupSettingValue(pid, "packCooldown")
			players[pid].packCooldown = os.time() + tmp.packCooldown

			-- nuke their gimme queue of zeds
			for k, v in pairs(gimmeQueuedCommands) do
				if (v.steam == pid) and (string.find(v.cmd, "se " .. pid)) then
					gimmeQueuedCommands[k] = nil
				end
			end
		end

		return
	end

if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	if string.find(line, "INF BloodMoon starting") and not isChat then
		server.delayReboot = true

		if botman.scheduledRestart then
			if tonumber(server.feralRebootDelay) == 0 then
				botman.scheduledRestartTimestamp = os.time() + ((server.DayLightLength + server.DayNightLength) * 60)
			else
				botman.scheduledRestartTimestamp = os.time() + (server.feralRebootDelay * 60)
			end
		end
	end

	if (string.find(line, "ServerMaxPlayerCount set to")) then
		number = tonumber(string.match(line, " (%d+)"))
		server.ServerMaxPlayerCount = number

		if server.maxPlayers == 0 then
			server.maxPlayers = tonumber(server.ServerMaxPlayerCount)

			if botman.dbConnected then
				conn:execute("UPDATE server SET maxPlayers = " .. server.maxPlayers)
			end

			-- if tonumber(server.reservedSlots) > 0 then
				-- sendCommand("sg ServerMaxPlayerCount " .. server.maxPlayers + 1) -- add a slot so reserved slot players can join even when the server is full
			-- end
		else
			if tonumber(server.maxPlayers) ~= tonumber(server.ServerMaxPlayerCount) - 1 then
				server.maxPlayers = tonumber(server.ServerMaxPlayerCount)

				if botman.dbConnected then
					conn:execute("UPDATE server SET maxPlayers = " .. server.maxPlayers)
				end

				-- if tonumber(server.reservedSlots) > 0 then
					-- sendCommand("sg ServerMaxPlayerCount " .. server.maxPlayers + 1) -- add a slot so reserved slot players can join even when the server is full
				-- end
			end
		end

		return
	end

if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	if not server.useAllocsWebAPI then
		if getAdminList then
			if string.sub(line, 1, 3) ~= "   " or string.find(line, "Defined Group Permissions") or string.find(line, 1, 8) == "Total of" then
				getAdminList = nil

				return
			end
		end

if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

		if readBotmanConfig then
			if string.find(line, "</Botman>", nil, true) then
				readBotmanConfig = nil
				table.insert(botman.config, line)
				processBotmanConfig()

				return
			end

			table.insert(botman.config, line)
		end


		if getAdminList then
			temp = string.split(line, ":")
			temp[1] = string.trim(temp[1])
			temp[2] = string.trim(string.sub(temp[2], 1, 18))

			number = tonumber(temp[1])
			pid = temp[2]

			if number < 90 then
				if tonumber(pid) > 0 then
					-- add the steamid to the staffList table
					staffList[pid] = {}
					staffList[pid].adminLevel = number

					if players[pid] then
						players[pid].accessLevel = number
						players[pid].newPlayer = false
						players[pid].silentBob = false
						players[pid].walkies = false
						players[pid].timeout = false
						players[pid].botTimeout = false
						players[pid].prisoner = false
						players[pid].exiled = false
						players[pid].canTeleport = true
						players[pid].botHelp = true
						players[pid].hackerScore = 0
						players[pid].testAsPlayer = nil

						if botman.dbConnected then conn:execute("UPDATE players SET newPlayer = 0, silentBob = 0, walkies = 0, exiled = 0, canTeleport = 1, botHelp = 1, accessLevel = " .. number .. " WHERE steam = " .. pid) end
						if botman.dbConnected then conn:execute("INSERT INTO staff (steam, adminLevel) VALUES (" .. pid .. "," .. number .. ") ON DUPLICATE KEY UPDATE adminLevel = " .. number) end
					end
				end
			end

			return
		end


		if playerListItems ~= nil then
			if string.find(line, "Listed ") then
				playerListItems = nil
			end

			return
		end


		if ircListItems ~= nil then
			if string.sub(string.trim(line), 1, 5) == "Slot " then
				ircListItems = nil
			end

			return
		end


		if ircListItems ~= nil then
			if string.sub(line,1,4) == "    " and string.sub(line,5,5) ~= " " then
				irc_chat(players[ircListItems].ircAlias, string.trim(line))
			end
		end


		if playerListItems ~= nil then
			if string.sub(line,1,4) == "    " and string.sub(line,5,5) ~= " " then
				message("pm " .. playerListItems .. " [" .. server.chatColour .. "]" .. string.trim(line) .. "[-]")
			end
		end


		-- collect the ban list
		if collectBans then
			if not string.find(line, "Reason") then
				if string.find(line, "-") then
					temp = string.split(line, "-")

					bannedTo = string.trim(temp[1] .. "-" .. temp[2] .. "-" .. temp[3])
					steam = string.trim(temp[4])
					reason = string.trim(temp[5])

					if botman.dbConnected then
						conn:execute("INSERT INTO bans (BannedTo, steam, reason, expiryDate) VALUES ('" .. bannedTo .. "'," .. steam .. ",'" .. escape(reason) .. "',STR_TO_DATE('" .. bannedTo .. "', '%Y-%m-%d %H:%i:%s'))")

						if players[steam] then
							-- also insert the steam owner (will only work if the steam id is different)
							conn:execute("INSERT INTO bans (BannedTo, steam, reason, expiryDate) VALUES ('" .. bannedTo .. "'," .. players[steam].steamOwner .. ",'" .. escape(reason) .. "',STR_TO_DATE('" .. bannedTo .. "', '%Y-%m-%d %H:%i:%s'))")
						end
					end
				end
			end
		end


		-- get zombies into table gimmeZombies
		if getZombies ~= nil then
			if string.find(line, "ombie") then
				temp = string.split(line, "-")

				local entityID = string.trim(temp[1])
				local zombie = string.trim(temp[2])

				if botman.dbConnected then conn:execute("INSERT INTO gimmeZombies (zombie, entityID) VALUES ('" .. zombie .. "'," .. entityID .. ") ON DUPLICATE KEY UPDATE remove = 0") end
				updateGimmeZombies(entityID, zombie)
			else
				if (string.sub(line, 1, 4) ~= os.date("%Y")) then
					temp = string.split(line, "-")

					local entityID = string.trim(temp[1])
					local entity = string.trim(temp[2])

					if botman.dbConnected then conn:execute("INSERT INTO otherEntities (entity, entityID) VALUES ('" .. entity .. "'," .. entityID .. ")") end
					updateOtherEntities(entityID, entity)
				end
			end
		end


		if botman.listItems then
			if string.find(line, " matching items.") then
				botman.listItems = false

				if not server.useAllocsWebAPI then
					send("pm bot_RemoveInvalidItems \"Test\"")
				end
			else
				if botman.dbConnected then
					temp = string.trim(line)
					spawnableItems[temp] = {}
				end
			end
		end


		if string.find(line, "INF Executing command") then
			botman.serverStarting = false
		end


		if string.find(line, "Executing command 'version") or string.find(line, "Game version:", nil, true) then
			readVersion = true
			resetVersion = true
		end


		if echoConsoleTo ~= nil then
			if string.find(line, "Executing command 'webpermission list") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'bm-listplayerfriends") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'bm-listplayerbed") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'lps") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'SystemInfo") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'traderlist") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'help") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'version") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'le'") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'li ") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'se'") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'si ") and string.find(line, echoConsoleTrigger) then
				echoConsole = true
			end

			if string.find(line, "Executing command 'gg'") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'ggs'") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'llp") then
				echoConsole = true
				connSQL:execute("DELETE FROM keystones WHERE x = 0 AND y = 0 AND z = 0")
			end

			if string.find(line, "Executing command 'ban list'") then
				echoConsole = true
			end

			if string.find(line, "Executing command 'admin list'") then
				echoConsole = true
			end
		end
	end


	if server.botman and not server.playersCanFly then
		if string.find(line, "PUG: entity_id") then
			words = {}
			tmp = {}

			for word in string.gmatch(line, "(-?%d+)") do
				table.insert(words, word)
			end

			tmp.pid = words[1]
			tmp.pid = LookupPlayer(tmp.pid)

			tmp.x = igplayers[tmp.pid].xPos
			tmp.y = igplayers[tmp.pid].yPos
			tmp.z = igplayers[tmp.pid].zPos

			if string.find(line, "isUnderGround=True") and not isAdmin(tmp.pid) then
				igplayers[tmp.pid].noclip = true

				if tonumber(igplayers[tmp.pid].noclipX) == 0 and tonumber(igplayers[tmp.pid].noclipZ) == 0 then
					igplayers[tmp.pid].noclipX = tmp.x
					igplayers[tmp.pid].noclipY = tmp.y
					igplayers[tmp.pid].noclipZ = tmp.z

					igplayers[tmp.pid].hackerDetection = "noclipping"
					players[tmp.pid].hackerScore = tonumber(players[tmp.pid].hackerScore) + 10
				else
					-- distance traveled since last detection
					tmp.dist = distancexyz(tmp.x, tmp.y, tmp.z, igplayers[tmp.pid].noclipX, igplayers[tmp.pid].noclipY, igplayers[tmp.pid].noclipZ)

					-- update coords
					igplayers[tmp.pid].noclipX = tmp.x
					igplayers[tmp.pid].noclipY = tmp.y
					igplayers[tmp.pid].noclipZ = tmp.z

					if igplayers[tmp.pid].noclipCount == nil then
						igplayers[tmp.pid].noclipCount = 1
					end

					if tonumber(tmp.dist) > 0 then
						igplayers[tmp.pid].hackerDetection = "noclipping"
						players[tmp.pid].hackerScore = tonumber(players[tmp.pid].hackerScore) + 10

						alertAdmins("Player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected noclipping (count: " .. igplayers[tmp.pid].noclipCount .. ") (hacker score: " .. players[tmp.pid].hackerScore .. ") " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z, "warn")
						irc_chat(server.ircMain, "Player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected noclipping (count: " .. igplayers[tmp.pid].noclipCount .. ") (session: " .. players[tmp.pid].session .. " hacker score: " .. players[tmp.pid].hackerScore .. ") " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z .. " moved " .. string.format("%d", tmp.dist))
						irc_chat(server.ircAlerts, "Player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected noclipping (count: " .. igplayers[tmp.pid].noclipCount .. ") (session: " .. players[tmp.pid].session .. " hacker score: " .. players[tmp.pid].hackerScore .. ") " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z .. " moved " .. string.format("%d", tmp.dist))
					else
						if igplayers[tmp.pid].noclipX == tmp.x and igplayers[tmp.pid].noclipY == tmp.y and igplayers[tmp.pid].noclipZ == tmp.z then
							if igplayers[tmp.pid].lastHackerAlert == nil then
								igplayers[tmp.pid].lastHackerAlert = os.time()

								irc_chat(server.ircMain, "Player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected noclipping (count: " .. igplayers[tmp.pid].noclipCount .. ") (session: " .. players[tmp.pid].session .. " hacker score: " .. players[tmp.pid].hackerScore .. ") " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z .. " moved " .. string.format("%d", tmp.dist))
								irc_chat(server.ircAlerts, server.gameDate .. " player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected noclipping (count: " .. igplayers[tmp.pid].noclipCount .. ") (session: " .. players[tmp.pid].session .. " hacker score: " .. players[tmp.pid].hackerScore .. ") " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z .. " moved " .. string.format("%d", tmp.dist))
								alertAdmins("Player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected noclipping (count: " .. igplayers[tmp.pid].noclipCount .. ") (hacker score: " .. players[tmp.pid].hackerScore .. ") " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z .. " moved " .. string.format("%d", tmp.dist), "warn")
							end

							if tonumber(os.time() - igplayers[tmp.pid].lastHackerAlert) > 120 then
								igplayers[tmp.pid].lastHackerAlert = os.time()
								irc_chat(server.ircAlerts, server.gameDate .. " player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected noclipping (count: " .. igplayers[tmp.pid].noclipCount .. ") (session: " .. players[tmp.pid].sessionCount .. " hacker score: " .. players[tmp.pid].hackerScore .. ") " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z .. " moved " .. string.format("%d", tmp.dist))
								alertAdmins("Player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected noclipping (count: " .. igplayers[tmp.pid].noclipCount .. ") (hacker score: " .. players[tmp.pid].hackerScore .. ") " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z ..  " moved " .. string.format("%d", tmp.dist), "warn")
							end
						end
					end

					igplayers[tmp.pid].noclipCount = tonumber(igplayers[tmp.pid].noclipCount) + 1
				end
			else
				igplayers[tmp.pid].noclip = false

				-- update coords anyway
				igplayers[tmp.pid].noclipX = tmp.x
				igplayers[tmp.pid].noclipY = tmp.y
				igplayers[tmp.pid].noclipZ = tmp.z
			end

			return
		end


		if string.find(line, "PGD: entity_id", nil, true) and string.find(line, "vehicle=", nil, true) then
			words = {}
			tmp = {}

			for word in string.gmatch(line, "(-?%d+)") do
				table.insert(words, word)
			end

			tmp.pid = LookupPlayer(words[1])

			igplayers[tmp.pid].flying = false
			igplayers[tmp.pid].inVehicle = false
			tmp.dist = tonumber(words[2]) -- distance above ground

			if tonumber(tmp.dist) > 3 then
				if igplayers[tmp.pid].flyingHeight == nil then
					igplayers[tmp.pid].flyingHeight = tmp.dist
				end

				if string.find(line, "vehicle=False") and not isAdmin(tmp.pid) and tmp.dist > 10 and (tmp.dist - igplayers[tmp.pid].flyingHeight >= 0) then
					igplayers[tmp.pid].flyingHeight = tmp.dist
					tmp.x = igplayers[tmp.pid].xPos
					tmp.y = igplayers[tmp.pid].yPos
					tmp.z = igplayers[tmp.pid].zPos

					if not players[tmp.pid].timeout and not players[tmp.pid].botTimeout and igplayers[tmp.pid].lastTP == nil and not players[tmp.pid].ignorePlayer then
						igplayers[tmp.pid].flying = true
						igplayers[tmp.pid].flyCount = igplayers[tmp.pid].flyCount + 1

						if igplayers[tmp.pid].flyingX == 0 then
							igplayers[tmp.pid].flyingX = tmp.x
							igplayers[tmp.pid].flyingY = tmp.y
							igplayers[tmp.pid].flyingZ = tmp.z

							igplayers[tmp.pid].hackerDetection = "flying"
							players[tmp.pid].hackerScore = tonumber(players[tmp.pid].hackerScore) + 10
						else
							-- distance of travel
							tmp.dist = distancexyz(tmp.x, tmp.y, tmp.z, igplayers[tmp.pid].flyingX, igplayers[tmp.pid].flyingY, igplayers[tmp.pid].flyingZ)

							-- update coords
							igplayers[tmp.pid].flyingX = tmp.x
							igplayers[tmp.pid].flyingY = tmp.y
							igplayers[tmp.pid].flyingZ = tmp.z

							igplayers[tmp.pid].hackerDetection = "flying"
							players[tmp.pid].hackerScore = tonumber(players[tmp.pid].hackerScore) + 10

							if tonumber(igplayers[tmp.pid].flyCount) > 1 then
								irc_chat(server.ircMain, "Player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected flying (count: " .. igplayers[tmp.pid].flyCount .. ") (session: " .. players[tmp.pid].sessionCount .. " hacker score: " .. players[tmp.pid].hackerScore .. ") @ " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z)
								irc_chat(server.ircAlerts, server.gameDate .. " player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected flying (count: " .. igplayers[tmp.pid].flyCount .. ") (session: " .. players[tmp.pid].sessionCount .. " hacker score: " .. players[tmp.pid].hackerScore .. ") @ " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z .. " moved " .. string.format("%d", tmp.dist))
								alertAdmins("Player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " is flying (count: " .. igplayers[tmp.pid].flyCount .. ") (hacker score: " .. players[tmp.pid].hackerScore .. ") @ " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z .. " moved " .. string.format("%d", tmp.dist), "warn")
							else
								if igplayers[tmp.pid].flyingX == tmp.x and igplayers[tmp.pid].flyingY == tmp.y and igplayers[tmp.pid].flyingZ == tmp.z then
									if igplayers[tmp.pid].lastHackerAlert == nil then
										igplayers[tmp.pid].lastHackerAlert = os.time()

										alertAdmins("Player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected flying (count: " .. igplayers[tmp.pid].flyCount .. ") (hacker score: " .. players[tmp.pid].hackerScore .. ") @ " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z .. " moved " .. string.format("%d", tmp.dist), "warn")
										irc_chat(server.ircMain, "Player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected flying (count: " .. igplayers[tmp.pid].flyCount .. ") (session: " .. players[tmp.pid].session .. " hacker score: " .. players[tmp.pid].hackerScore .. ") @ " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z)
										irc_chat(server.ircAlerts, server.gameDate .. " player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected flying (count: " .. igplayers[tmp.pid].flyCount .. ") (session: " .. players[tmp.pid].session .. " hacker score: " .. players[tmp.pid].hackerScore .. ") @ " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z .. " moved " .. string.format("%d", tmp.dist))
									end

									if os.time() - igplayers[tmp.pid].lastHackerAlert > 120 then
										alertAdmins("Player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected flying (count: " .. igplayers[tmp.pid].flyCount .. ") (hacker score: " .. players[tmp.pid].hackerScore .. ") @ " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z .. " moved " .. string.format("%d", tmp.dist), "warn")
										irc_chat(server.ircAlerts, server.gameDate .. " player " .. tmp.pid .. " " .. igplayers[tmp.pid].name .. " detected flying (count: " .. igplayers[tmp.pid].flyCount .. ") (session: " .. players[tmp.pid].session .. " hacker score: " .. players[tmp.pid].hackerScore .. ") @ " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z .. " moved " .. string.format("%d", tmp.dist))
									end
								end
							end
						end
					end
				else
					igplayers[tmp.pid].inVehicle = true
				end
			end

			if not igplayers[tmp.pid].noclip and not igplayers[tmp.pid].flying then
				if tonumber(players[tmp.pid].hackerScore) > 0 then
					players[tmp.pid].hackerScore = tonumber(players[tmp.pid].hackerScore) - 5
				end

				if tonumber(igplayers[tmp.pid].flyCount) > 0 then
					igplayers[tmp.pid].flyCount  = igplayers[tmp.pid].flyCount - 1
				end
			end

			return
		end
	end

	-- ===================================
	-- infrequent telnet events below here
	-- ===================================

	if string.find(line, "No spawn point found near player!") then
		for k,v in pairs(igplayers) do
			if v.voteRewarded then
				if os.time() - v.voteRewarded < 10 then
					v.voteRewardOwing = 1
					message("pm " .. k .. " [" .. server.warnColour .. "]Oh no! Your reward failed to spawn.  Move outside to somewhere more open and try again by typing {#}claim vote[-]")
					message("pm " .. k .. " [" .. server.warnColour .. "]Claim it before you leave the server.[-]")
					break
				end
			end
		end
	end

--if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	if not server.useAllocsWebAPI then
		if string.find(line, "Executing command 'le'") then
			botman.listEntities = true
			botman.lastListEntities = os.time()
			connMEM:execute("DELETE FROM entities")

			return
		end


		if string.find(line, "Executing command 'li ") then
			botman.listItems = true
			spawnableItems = {}

			return
		end


		if (string.find(line, "Banned until -")) then
			collectBans = true
			conn:execute("TRUNCATE bans")

			return
		end

		-- update owners, admins and mods
		if string.find(line, "Level: SteamID (Player name if online", nil, true) then
			--flagAdminsForRemoval()
			getAdminList = true

			return
		end
	end

--if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	if botman.readGG and not string.find(line, "GamePref.", nil, true) then
		botman.readGG = false
	end

	if botman.readGG then
		number = tonumber(string.match(line, " (%d+)"))

		temp = string.split(line, " = ")
		pref = string.sub(temp[1], 10)

		if not temp[2] then
			return
		end

		value = string.sub(line, string.find(line, " = ") + 3)
		GamePrefs[pref] = value

		if (string.find(line, "HideCommandExecutionLog =")) then
			server.HideCommandExecutionLog = number

			return
		end

		if (string.find(line, "MaxSpawnedZombies set to")) then
			server.MaxSpawnedZombies = number

			return
		end

		if (string.find(line, "MaxSpawnedAnimals set to")) then
			server.MaxSpawnedAnimals = number

			return
		end

		if (string.find(line, "LootRespawnDays =")) then
			server.LootRespawnDays = number

			return
		end

		if (string.find(line, "BlockDurabilityModifier =")) then
			server.BlockDurabilityModifier = number

			return
		end

		if (string.find(line, "DayNightLength =")) then
			server.DayNightLength = number

			return
		end

		if (string.find(line, "DayLightLength =")) then
			server.DayLightLength = number

			return
		end

		if (string.find(line, "DropOnDeath =")) then
			server.DropOnDeath = number

			return
		end

		if (string.find(line, "DropOnQuit =")) then
			server.DropOnQuit = number

			return
		end

		if (string.find(line, "EnemyDifficulty =")) then
			server.EnemyDifficulty = number

			return
		end

		if (string.find(line, "LandClaimSize =")) then
			server.LandClaimSize = number

			return
		end

		if (string.find(line, "LandClaimExpiryTime =")) then
			server.LandClaimExpiryTime = number

			return
		end

		if (string.find(line, "LootAbundance =")) then
			server.LootAbundance = number

			return
		end

		if (string.find(line, "LootRespawnDays =")) then
			server.LootRespawnDays = number

			return
		end

		if (string.find(line, "ServerPort =")) then
			server.ServerPort = number
			if botman.dbConnected then
				conn:execute("UPDATE server SET ServerPort = " .. server.ServerPort)
			end

			if botman.botsConnected then
				connBots:execute("UPDATE servers SET ServerPort = " .. server.ServerPort .. " WHERE botID = " .. server.botID)
			end

			return
		end

		if (string.find(line, "ZombiesRun =")) then
			server.ZombiesRun = number

			return
		end

		if (string.find(line, "ZombieMove =")) then
			server.ZombiesRun = -1
			server.ZombieMove = number

			return
		end

		if (string.find(line, "ZombieMoveNight =")) then
			server.ZombieMoveNight = number

			return
		end

		if (string.find(line, "ZombieBMMove =")) then
			server.ZombieBMMove = number

			return
		end

		if (string.find(line, "ZombieFeralMove =")) then
			server.ZombieFeralMove = number

			return
		end

		if (string.find(line, "BloodMoonFrequency =")) then
			server.BloodMoonFrequency = number
			server.hordeNight = number

			return
		end

		if (string.find(line, "BloodMoonRange =")) then
			server.BloodMoonRange = number

			return
		end

		if (string.find(line, "ServerName =")) then
			server.serverName = string.trim(string.sub(line, 22))

			if botman.dbConnected then
				conn:execute("UPDATE server SET serverName = '" .. escape(server.serverName) .. "'")
			end

			if botman.botsConnected then
				connBots:execute("UPDATE servers SET serverName = '" .. escape(server.serverName) .. "' WHERE botID = " .. server.botID)
			end

			if string.find(string.lower(server.serverName), "pvp") and not string.find(string.lower(server.serverName), "pve") then
				server.gameType = "pvp"

				if server.northeastZone == "" then
					server.northeastZone = "pvp"
				end

				if server.northwestZone == "" then
					server.northwestZone = "pvp"
				end

				if server.southeastZone == "" then
					server.southeastZone = "pvp"
				end

				if server.southwestZone == "" then
					server.southwestZone = "pvp"
				end
			else
				if server.northeastZone == "" then
					server.northeastZone = "pve"
				end

				if server.northwestZone == "" then
					server.northwestZone = "pve"
				end

				if server.southeastZone == "" then
					server.southeastZone = "pve"
				end

				if server.southwestZone == "" then
					server.southwestZone = "pve"
				end
			end

			return
		end

--if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

		if (string.find(line, "GameName =")) then
			server.GameName = string.trim(string.sub(line, 20))

			return
		end

--if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

		if (string.find(line, "ServerMaxPlayerCount =")) then
			number = tonumber(string.match(line, " (%d+)"))
			server.ServerMaxPlayerCount = number

			if server.maxPlayers == 0 then
				server.maxPlayers = tonumber(server.ServerMaxPlayerCount)

				if botman.dbConnected then
					conn:execute("UPDATE server SET maxPlayers = " .. server.maxPlayers)
				end

				-- if server.reservedSlots > 0 then
					-- sendCommand("sg ServerMaxPlayerCount " .. server.maxPlayers + 1) -- add a slot so reserved slot players can join even when the server is full
				-- end
			else
				if tonumber(server.maxPlayers) ~= tonumber(server.ServerMaxPlayerCount) - 1 then
					if tonumber(server.reservedSlots) > 0 then
						if tonumber(server.maxPlayers) > tonumber(server.ServerMaxPlayerCount) then
							server.maxPlayers = tonumber(server.ServerMaxPlayerCount)

							if botman.dbConnected then
								conn:execute("UPDATE server SET maxPlayers = " .. server.maxPlayers)
							end

	--display("bump max players by 1")
							--sendCommand("sg ServerMaxPlayerCount " .. server.maxPlayers + 1) -- add a slot so reserved slot players can join even when the server is full

							return
						end

						if tonumber(server.maxPlayers) < tonumber(server.ServerMaxPlayerCount) -1 then
							server.maxPlayers = tonumber(server.ServerMaxPlayerCount)

							if botman.dbConnected then
								conn:execute("UPDATE server SET maxPlayers = " .. server.maxPlayers)
							end

	--display("bump max players by 1")
							--sendCommand("sg ServerMaxPlayerCount " .. server.maxPlayers + 1) -- add a slot so reserved slot players can join even when the server is full
						end
					else
						server.maxPlayers = tonumber(server.ServerMaxPlayerCount)

						if botman.dbConnected then
							conn:execute("UPDATE server SET maxPlayers = " .. server.maxPlayers)
						end
					end
				end
			end

			return
		end

--if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

		if (string.find(line, "MaxSpawnedZombies =")) then
			server.MaxSpawnedZombies = number
			-- If we detect this line it means we are receiving data from the server so we set a flag to let us know elsewhere that we got server data ok.
			serverDataLoaded = true

			return
		end
	end

--if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	if string.sub(line, 1, 4) == "Mod " then
		if resetVersion and not server.useAllocsWebAPI then
			modVersions = {}
			server.allocs = false
			server.botman = false
			server.otherManager = false
			resetVersion = nil
		end

--dbug("debug matchAll line " .. debugger.getinfo(1).currentline)

		modVersions[line] = {}
	end


	-- detect CSMM Patrons Mod
	if string.find(line, "Mod CSMM Patrons") then
		server.otherManager = true

		return
	end


	-- detect Alloc's Mod
	if string.find(line, "Mod Allocs server fixes") then
		server.allocs = true
		temp = string.split(line, ":")
		server.allocsServerFixes = temp[2]

		return
	end


	if string.find(line, "Mod Allocs command extensions") then
		server.allocs = true
		temp = string.split(line, ":")
		server.allocsCommandExtensions = temp[2]

		return
	end


	if string.find(line, "Mod Allocs MapRendering") then
		server.allocs = true
		temp = string.split(line, ":")
		server.allocsMap = temp[2]

		return
	end


	if (string.find(line, "please specify one of the entities")) then
		-- flag all the zombies for removal so we can detect deleted zeds
		if botman.dbConnected then conn:execute("UPDATE gimmeZombies SET remove = 1") end
		if botman.dbConnected then conn:execute("UPDATE otherEntities SET remove = 1") end

		getZombies = true

		return
	end


	if string.find(line, "ERROR: unknown command 'bm-playerunderground'") then
		server.scanNoclip = false

		return
	end


	-- detect server version
	if string.find(line, "Game version:") then
		temp = string.sub(line, string.find(line, "Game version:") + 13)
		modVersions["Server " .. string.trim(temp)] = {}

		server.gameVersion = string.trim(string.sub(line, string.find(line, "Game version:") + 14, string.find(line, "Compatibility") - 2))
		if botman.dbConnected then conn:execute("UPDATE server SET gameVersion = '" .. escape(server.gameVersion) .. "'") end

		temp = string.split(server.gameVersion, " ")
		server.gameVersionNumber = tonumber(temp[2])

		if server.gameVersionNumber == 17 and server.updateBranch == "stable" then
			server.updateBranch = "a17"
		end

		return
	end

	-- detect Botman mod
	if string.find(line, "Mod Botman:") then
		server.botman = true
		temp = string.split(line, ":")
		server.botmanVersion = temp[2]
		modBotman.version = temp[2]

		if botman.dbConnected then conn:execute("UPDATE modBotman SET version = '" .. temp[2] .. "'") end

		return
	end


	if (string.find(line, "Process chat error")) then
		irc_chat(server.ircAlerts, "Server error detected. Re-validate to fix: " .. line)
	end


	if string.find(line, "Playername or entity ID not found.") then
		return
	end


	if string.find(line, "bot_RemoveInvalidItems") then
		removeInvalidItems()
		spawnableItems = {}
		tempTimer(3, [[loadShop()]])

		return
	end


	if string.find(line, "Version mismatch") then
		irc_chat(server.ircAlerts, line)

		return
	end


	if string.find(line, "ERR EXCEPTION:") and string.find(line, "Cannot expand this MemoryStream") and not botman.serverErrorReported then
		-- report memory error
		botman.serverErrorReported = true
		irc_chat(server.ircAlerts, "Server error detected.")
		irc_chat(server.ircAlerts, line)

		return
	end

	if string.find(line, "INF Server shutting down", nil, true) and not string.find(line, "Chat") then
		serverShutdown()

		return
	end

	if string.find(line, "INF World.Unload", nil, true) and not string.find(line, "Chat") then
		serverShutdown()

		return
	end

	if string.find(line, 'kickall "Server restarting"',nil, true) and not server.readLogUsingTelnet then
		serverShutdown()

		return
	end


	if string.find(line, "ERROR: Command") then
		if string.find(line, "game is started") and not string.find(line, "Chat") then
			botman.gameStarted = false
		end
	end


	if string.find(line, "StartGame done") and not string.find(line, "Chat") then
		botman.gameStarted = true
		botman.serverStarting = false
		botman.worldGenerating = nil
		botman.APIOffline = false
		toggleTriggers("api offline")
		botman.playersOnline = 0
		server.serverStartTimestamp = os.time() -- near enough to correct :P
		server.uptime = 0
		processServerCommandQueue()

		-- move these out of here and don't put them on timers
		send("gt")
		tempTimer( 2, [[sendCommand("admin list")]] )
		tempTimer( 5, [[sendCommand("version")]] )
		tempTimer( 7, [[sendCommand("gg")]] )

		if server.botman then
			tempTimer( 10, [[sendCommand("bm-resetregions list")]] )
		end

		irc_chat(server.ircMain, "Players can now join the server :D")

		return
	end

--if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	if string.find(line, "INF Reloading serveradmin.xml") then
		sendCommand("admin list")

		return
	end


	if string.find(line, "INF BlockAdded") then
		temp = string.split(line, " ")
		pid = string.match(temp[5], "(-?%d+)")
		x = string.match(temp[6], "(-?%d+)")
		y = string.match(temp[7], "(-?%d+)")
		z = string.match(temp[8], "(-?%d+)")
		claimRemoved = false

		if not isAdmin(pid) then
			region = getRegion(x, z)
			loc, reset = inLocation(x, z)

			if (resetRegions[region] or reset or players[pid].removeClaims) and not players[pid].testAsPlayer then
				claimRemoved = true
				if botman.dbConnected then connSQL:execute("INSERT INTO persistentQueue (steam, command, timerDelay) VALUES ('" .. pid .. "','" .. connMEM:escape("rlp " .. x .. " " .. y .. " " .. z) .. "','" .. os.time() + 5 .. "')") end
			else
				if botman.dbConnected then connSQL:execute("INSERT INTO keystones (steam, x, y, z, expired, remove, removed) VALUES ('" .. pid .. "'," .. x .. "," .. y .. "," .. z .. "," .. dbBool(expired) .. ",0,0) ON DUPLICATE KEY UPDATE expired = " .. dbBool(expired) .. ", remove = 0, removed = 0") end
			end

			if not claimRemoved then
				if not keystones[x .. y .. z] then
					keystones[x .. y .. z] = {}
					keystones[x .. y .. z].x = x
					keystones[x .. y .. z].y = y
					keystones[x .. y .. z].z = z
					keystones[x .. y .. z].steam = pid
				end
			end
		else
			if botman.dbConnected then connSQL:execute("INSERT INTO keystones (steam, x, y, z, expired, remove, removed) VALUES ('" .. pid .. "'," .. x .. "," .. y .. "," .. z .. "," .. dbBool(expired) .. ",0,0) ON DUPLICATE KEY UPDATE expired = " .. dbBool(expired) .. ", remove = 0, removed = 0") end
		end

		return
	end


	if getuptime then
		getuptime = nil
		temp = string.split(line, ":")

		-- hours
		tmp  = tonumber(string.match(temp[1], "(%d+)"))
		server.uptime = tmp * 60 * 60

		-- minutes
		tmp  = tonumber(string.match(temp[2], "(%d+)"))
		server.uptime = server.uptime + (tmp * 60)

		-- seconds
		tmp  = tonumber(string.match(temp[3], "(%d+)"))
		server.uptime = server.uptime + tmp
		server.serverStartTimestamp = os.time() - server.uptime
		return
	end


	if string.find(line, "INF Executing command 'bm-uptime'", nil, true) and not server.useAllocsWebAPI then
		getuptime = true
		return
	end


	if string.find(line, "BotStartupCheck")  then
		if string.find(line, "by Telnet from ") then
			temp = string.sub(line, string.find(line, "by Telnet from ") + 15)
			temp = string.split(temp, ":")
			server.botsIP = temp[1]

			conn:execute("UPDATE server SET botsIP = '" .. server.botsIP .. "'")
			return
		end
	end


	if string.find(line, "Server IP:") and not string.find(line, "Chat") then
		if server.IP == "0.0.0.0" then
			temp = string.split(line, ": ")
			server.IP = string.trim(temp[2])
			conn:execute("UPDATE server SET IP = '" .. server.IP .. "'")
		end
	end


	if string.find(line, "INF Started Webserver") then
		botman.worldGenerating = nil
		temp = string.sub(line, string.find(line, " on ") + 4)
		temp = tonumber(temp) - 2
		server.webPanelPort = temp
		conn:execute("UPDATE server set webPanelPort = " .. server.webPanelPort)
		anticheatBans = {}

		-- if tonumber(server.webPanelPort) == 0 then
			-- if not server.useAllocsWebAPI then
				-- server.allocsWebAPIPassword = generatePassword(20)
				-- conn:execute("UPDATE server set allocsWebAPIUser = 'bot', allocsWebAPIPassword = '" .. escape(server.allocsWebAPIPassword) .. "', useAllocsWebAPI = 1")
				-- os.remove(homedir .. "/temp/apitest.txt")
				-- server.useAllocsWebAPI = true

				-- botman.APIOffline = false
				-- toggleTriggers("api offline")
				-- send("webtokens add bot " .. server.allocsWebAPIPassword .. " 0")
				-- botman.lastBotCommand = "webtokens add bot"
				-- botman.webTokenLastAdded = os.timer()
			-- else
				-- botman.APIOffline = false
				-- startUsingAllocsWebAPI()
			-- end
		-- end

		stackLimits = {}
		tempTimer( 20, [[fixShop()]] )
	end


	if string.find(line, "INF WorldGenerator:Generating", nil, true) then
		if not botman.worldGenerating then
			botman.worldGenerating = true
			irc_chat(server.ircMain, "The bot is temporarily paused while the world is being generated.  If it is still paused by the time you can join the server type " .. server.commandPrefix .. "unpause bot")
		end
	end


	if botman.worldGenerating then
		temp = string.sub(line, string.find(line, "INF") + 4)
		irc_chat(server.ircMain, temp)
	end


	if string.find(line, "Reset Status:", nil, true) then
		temp = string.sub(line, string.find(line, "INF") + 4)
		irc_chat(server.ircMain, temp)
	end


	if server.botman then
		if (readAnticheat or string.find(line,"~Botman AntiCheat~", nil, true)) and (not string.find(line, "unauthorized locked container")) then
			tmp = {}
			tmp.name = string.sub(line, string.find(line, "-NAME:") + 6, string.find(line, "--ID:") - 2)
			tmp.id = string.sub(line, string.find(line, "-ID:") + 4, string.find(line, "--LVL:") - 2)
			tmp.hack = ""
			tmp.level = string.sub(line, string.find(line, "-LVL:") + 5)
			tmp.level = string.match(tmp.level, "(-?%d+)")
			tmp.alert = string.sub(line, string.find(line, "-LVL:") + 5)
			tmp.alert = string.sub(tmp.alert, string.find(tmp.alert, " ") + 1)

			if (not staffList[tmp.id]) and (not players[tmp.id].testAsPlayer) and (not bans[tmp.id]) and (not anticheatBans[tmp.id]) then
				if string.find(line, " spawned ") then
					temp = string.split(tmp.alert, " ")
					tmp.entity = stripQuotes(temp[3])
					tmp.x = string.match(temp[4], "(-?\%d+)")
					tmp.y = string.match(temp[5], "(-?\%d+)")
					tmp.z = string.match(temp[6], "(-?\%d+)")
					tmp.hack = "spawned " .. tmp.entity .. " at " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z

					if tonumber(tmp.level) > 2 then
						irc_chat(server.ircMain, "ALERT! Unauthorised admin detected. Player " .. tmp.name .. " Steam: " .. tmp.id .. " Permission level: " .. tmp.level .. " " .. tmp.alert)
						irc_chat(server.ircAlerts, "ALERT! Unauthorised admin detected. Player " .. tmp.name .. " Steam: " .. tmp.id .. " Permission level: " .. tmp.level .. " " .. tmp.alert)
					end
				else
					tmp.x = players[tmp.id].xPos
					tmp.y = players[tmp.id].yPos
					tmp.z = players[tmp.id].zPos
					tmp.hack = "using dm at " .. tmp.x .. " " .. tmp.y .. " " .. tmp.z

					if tonumber(tmp.level) > 2 then
						irc_chat(server.ircMain, "ALERT! Unauthorised admin detected. Player " .. tmp.name .. " Steam: " .. tmp.id .. " Permission level: " .. tmp.level .. " " .. tmp.alert)
						irc_chat(server.ircAlerts, "ALERT! Unauthorised admin detected. Player " .. tmp.name .. " Steam: " .. tmp.id .. " Permission level: " .. tmp.level .. " " .. tmp.alert)
					end
				end

				if tonumber(tmp.level) > 2 then
					anticheatBans[tmp.id] = {}
					banPlayer(tmp.id, "10 years", "hacking", "")
					logHacker(botman.serverTime, "Botman anticheat detected " .. tmp.id .. " " .. tmp.name .. " " .. tmp.hack)
					message("say [" .. server.chatColour .. "]Banning player " .. tmp.name .. " 10 years for using hacks.[-]")
					irc_chat("#hackers", "[BANNED] Player " .. tmp.id .. " " .. tmp.name .. " has has been banned for hacking by anticheat.")
					irc_chat("#hackers", line)
					irc_chat(server.ircMain, "[BANNED] Player " .. tmp.id .. " " .. tmp.name .. " has has been banned for hacking.")
					irc_chat(server.ircAlerts, botman.serverTime .. " " .. server.gameDate .. " [BANNED] Player " .. tmp.id .. " " .. tmp.name .. " has has been banned for 10 years for hacking.")
					conn:execute("INSERT INTO events (x, y, z, serverTime, type, event, steam) VALUES (" .. tmp.x .. "," .. tmp.y .. "," .. tmp.z .. ",'" .. botman.serverTime .. "','ban','Player " .. tmp.id .. " " .. escape(tmp.name) .. " has has been banned for 10 years for hacking.'," .. tmp.id .. ")")
					--connBots:execute("INSERT INTO events (server, serverTime, type, event, steam) VALUES ('" .. escape(server.serverName) .. "','" .. botman.serverTime .. "','player banned','Player banned by anticheat " .. escape(tmp.name) .. "'," .. tmp.id .. ")")
				end
			end
		end
	end


	if readWebTokens and not string.find(line, "Defined") then
		if server.allocsWebAPIUser ~= "" and server.allocsWebAPIUser ~= "bot" then
			if string.find(line, " " .. server.allocsWebAPIUser .. " ") then
				readWebTokens = nil
				botTokenFound = nil
				server.useAllocsWebAPI = true
				server.allocsWebAPIPassword = string.sub(line, string.find(line, " / ") + 3)
				conn:execute("UPDATE server allocsWebAPIPassword = '" .. escape(server.allocsWebAPIPassword) .. "', useAllocsWebAPI = 1")
				botman.APIOffline = false
				toggleTriggers("api online")
			end
		else
			if string.find(line, " bot ") then
				readWebTokens = nil
				botTokenFound = nil
				server.useAllocsWebAPI = true
				server.allocsWebAPIUser = "bot"
				server.allocsWebAPIPassword = string.sub(line, string.find(line, " / ") + 3)
				conn:execute("UPDATE server set allocsWebAPIUser = 'bot', allocsWebAPIPassword = '" .. escape(server.allocsWebAPIPassword) .. "', useAllocsWebAPI = 1")
				botman.APIOffline = false
				toggleTriggers("api online")
			end
		end
	end

--if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	if string.find(line, "webtokens list", nil, true) then
		botTokenFound = false
		readWebTokens = true
	end

	if string.find(line, "bm-anticheat report", nil, true) then
		readAnticheat = true
	end

--if (debug) then dbug("debug matchAll line " .. debugger.getinfo(1).currentline) end

	if string.find(line, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>", nil, true) then
		readBotmanConfig = true
		botman.config = {}
	end

	if string.find(line, "Web user with name=bot and password") and string.find(line, "added with permission level of 0.")  then
		temp = string.sub(line, string.find(line, "password=") + 9, string.find(line, "added with permission") - 1)
		temp = string.trim(temp)
		server.useAllocsWebAPI = true
		server.allocsWebAPIUser = "bot"
		server.allocsWebAPIPassword = temp
		conn:execute("UPDATE server set allocsWebAPIUser = 'bot', allocsWebAPIPassword = '" .. escape(server.allocsWebAPIPassword) .. "', useAllocsWebAPI = 1")
		botman.APIOffline = false
		toggleTriggers("api online")
	end

	if badPlayerJoined then
		if string.find(line, "INF Player set to online") or string.find(line, "INF PlayerSpawnedInWorld") then
			-- abort!  abort!
			badPlayerJoined = false
			badJoinLine = ""
		end

		if badPlayerJoined and not string.find(line, "INF Player connected") then
			playerConnected(badJoinLine .. line)
		end
	end

	-- if Allocs webmap has this error, force the bot to use telnet mode
	if string.find(line, "at AllocsFixes.NetConnections.Servers.Web.Web.HandleRequest") then
		if server.useAllocsWebAPI then
			server.useAllocsWebAPI = false
			conn:execute("UPDATE server set useAllocsWebAPI = 0")
		end
	end

	if readResetRegions then
		if string.find(line, "There are currently no reset regions") then
			readResetRegions = nil
			return
		end

		if string.sub(line, 1, 2) == "r." then
			temp = string.split(v, "%.")
			x = temp[2]
			z = temp[3]

			if not resetRegions[v .. ".7rg"] then
				resetRegions[v .. ".7rg"] = {}
			end

			resetRegions[v .. ".7rg"].x = x
			resetRegions[v .. ".7rg"].z = z
			resetRegions[v .. ".7rg"].inConfig = true
			conn:execute("INSERT INTO resetZones (region, x, z) VALUES ('" .. escape(v .. ".7rg") .. "'," .. x .. "," .. z .. ")")
		end
	end

	if string.find(line, "bm-resetregions list", nil, true) then
		readResetRegions = true

		for k,v in pairs(resetRegions) do
			v.inConfig = false
		end
	end

	if string.find(line, "ERROR") and string.find(line, "can only be executed") and not isChat then
		botman.serverStarting = true
	end

end

