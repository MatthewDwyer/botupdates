--[[
    Botman - A collection of scripts for managing 7 Days to Die servers
    Copyright (C) 2020  Matthew Dwyer
	           This copyright applies to the Lua source code in this Mudlet profile.
    Email     smegzor@gmail.com
    URL       https://botman.nz
    Source    https://bitbucket.org/mhdwyer/botman
--]]

function playerInfo(faultyInfo)
	-- EDIT THIS FUNCTION WITH CARE.  This function is central to player management.  Some lines need to be run before others.
	-- Lua will stop execution wherever it strikes a fault (usually trying to use a non-existing variable)
	-- enable debugging to see roughly where the bot gets to.  It should reach 'end playerinfo'.
	-- Good luck :)

	local tmp = {}

	faultyPlayerinfo = true
	faultyPlayerinfoID = 0
	faultyPlayerinfoLine = line

	local debug, id, name, posX, posY, posZ, lastX, lastY, lastZ, lastDist, mapCenterDistance, regionX, regionZ, chunkX, chunkZ, exile, prison
	local deaths, zombies, kills, score, level, steam, steamtest, admin, lastGimme, lastLogin, playerAccessLevel, temp, settings
	local xPosOld, yPosOld, zPosOld, rawPosition, rawRotation, outsideMap, fields, values, flag, cmd
	local k, v, key
	local timestamp = os.time()
	local region = ""
	local resetZone = false
	local ping, dist, IP, hotspot, currentLocation
	local skipTPtest = false
	local badData = false -- no biscuit!

	if customPlayerInfo ~= nil then
		-- read the note on overriding bot code in custom/custom_functions.lua
		if customPlayerInfo(line) then
			return
		end
	end

	debug = false -- should be false unless testing

if debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if debugPlayerInfo == nil then debugPlayerInfo = 0 end

	-- Set debugPlayerInfo to the steam id or player name that you want to monitor.  If the player is not on the server, the bot will reset debugPlayerInfo to zero.
	debugPlayerInfo = 0 -- should be 0 unless testing against a steam id

	if (debugPlayerInfo ~= 0) then
		if debug then
			dbug("debug playerinfo " .. debugPlayerInfo, true)
			dbug(line, true)
		end
	end

	exile = LookupLocation("exile")
	prison = LookupLocation("prison")

	flag = ""
	name_table = string.split(line, ", ")

	if string.find(name_table[3], "pos") then
		name = string.trim(name_table[2])
	else
		temp = name_table[1] .. ", name" .. string.sub(line, string.find(line, ", pos="), string.len(line))
		name_table = string.split(temp, ", ")
		name = string.trim(string.sub(line, string.find(line, ",") + 2, string.find(line, ", pos=") - 1))
	end

	-- stop processing this player if we don't have 18 parts to the line after splitting on comma
	-- it is probably a read error
	if (table.maxn(name_table) < 18) then
		faultyPlayerinfoID = 0
		if debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end
		return
	end

	temp = string.split(name_table[1], "=")
	id = temp[2]

	num = tonumber(string.sub(name_table[3], 6))
	if (num == nil) then badData = true end
	posX = num

	num = tonumber(name_table[4])
	if (num == nil) then badData = true end
	posY = num

	temp = string.split(name_table[5], ")")
	num = tonumber(temp[1])
	if (num == nil) then badData = true end
	posZ = num

	num = tonumber(name_table[7])
	if (num == nil) then badData = true end
	rotY = num

	temp = string.split(name_table[11], "=")
	num = tonumber(temp[2])
	if (num == nil) then badData = true end
	deaths = num

	temp = string.split(name_table[12], "=")
	num = tonumber(temp[2])
	if (num == nil) then badData = true end
	zombies = num

	temp = string.split(name_table[13], "=")
	num = tonumber(temp[2])
	if (num == nil) then badData = true end
	kills = num

	temp = string.split(name_table[14], "=")
	num = tonumber(temp[2])
	if (num == nil) then badData = true end
	score = num

	temp = string.split(name_table[15], "=")
	num = tonumber(temp[2])
	if (num == nil) then badData = true end
	level = num

	temp = string.split(name_table[16], "=")
	if (num == nil) then badData = true end
	steam = temp[2]

	steam = tostring(steam)

	faultyPlayerinfoID = steam

	temp = string.split(name_table[17], "=")
	IP = temp[2]
	IP = IP:gsub("::ffff:","")

	temp = string.split(name_table[18], "=")
	ping = tonumber(temp[2])

	if badData then
		if debug then
			dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true)
			dbug("Bad lp line: " .. line .. "\n", true)
		end

		return
	end

if  debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	rawPosition = posX .. posY .. posZ
	rawRotation = rotY

	posX = math.floor(posX)
	posY = math.floor(posY)
	posZ = math.floor(posZ)

	intX = posX
	intY = posY
	intZ = posZ

	region = getRegion(intX, intZ)
	regionX, regionZ, chunkX, chunkZ = getRegionChunkXZ(intX, intZ)

	if (resetRegions[region]) then
		resetZone = true
	else
		resetZone = false
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

if  debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- check for invalid or missing steamid.  kick if not passed
	steamtest = tonumber(steam)
	if (steamtest == nil) then
		sendCommand("kick " .. id)
		irc_chat(server.ircMain, "Player " .. name .. " kicked for invalid Steam ID: " .. steam)
		faultyPlayerinfo = false
		return
	end

if  debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if (string.len(steam) < 17) then
		sendCommand("kick " .. id)
		irc_chat(server.ircMain, "Player " .. name .. " kicked for invalid Steam ID: " .. steam)
		faultyPlayerinfo = false
		return
	end

if  debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- add to in-game players table
	if (igplayers[steam] == nil) then
		igplayers[steam] = {}
		igplayers[steam].id = id
		igplayers[steam].name = name
		igplayers[steam].steam = steam
		igplayers[steam].steamOwner = steam

		fixMissingIGPlayer(steam)
	end

	if igplayers[steam].readCounter == nil then
		igplayers[steam].readCounter = 0
	else
		igplayers[steam].readCounter = igplayers[steam].readCounter + 1
	end

	if igplayers[steam].checkNewPlayer == nil then
		fixMissingIGPlayer(steam)
	end

	-- if player is missing from player lua table, try to load them from the database.
	if (players[steam] == nil) then
		loadPlayers(steam)

		-- exit here if the bot started up less than 2 minutes ago.
		-- this is an attempt to fix a bug/issue where a non-new player isn't found in the data and is reset as new when they actually exist already.
		-- hopefully it gives the bot time to sort that out and not stuff up :O
		if os.time() - botman.botStarted < 120 then
			return
		end
	end

	-- add to players table
	if (players[steam] == nil) then
		players[steam] = {}
		players[steam].id = id
		players[steam].name = name
		players[steam].steam = steam

		if tonumber(score) == 0 and tonumber(zombies) == 0 and tonumber(deaths) == 0 then
			players[steam].newPlayer = true
		else
			players[steam].newPlayer = false
		end

		players[steam].watchPlayer = true
		players[steam].watchPlayerTimer = os.time() + 2419200 -- stop watching in one month or until no longer a new player
		players[steam].ip = IP
		players[steam].exiled = false

		irc_chat(server.ircMain, "###  New player joined " .. player .. " steam: " .. steam.. " id: " .. id .. " ###")
		irc_chat(server.ircAlerts, "New player joined " .. server.gameDate .. " " .. line:gsub("%,", ""))

		if botman.dbConnected then
			conn:execute("INSERT INTO events (x, y, z, serverTime, type, event, steam) VALUES (" .. posX .. "," .. posY .. "," .. posZ .. ",'" .. botman.serverTime .. "','new player','New player joined (player info) " .. name .. " steam: " .. steam.. " id: " .. id .. "'," .. steam .. ")")
			conn:execute("INSERT INTO players (steam, name, id, IP, newPlayer, watchPlayer, watchPlayerTimer) VALUES (" .. steam .. ",'" .. escape(name) .. "'," .. id .. "," .. IP .. ",1,1, " .. os.time() + 2419200 .. ")")
		end

		fixMissingPlayer(steam)

		-- don't initially warn the player about pvp or pve zone.  Too many players complain about it when the bot is restarted.  We can warn them next time their zone changes.
		if pvpZone(posX, posZ) then
			if players[steam].alertPVP == true then
				players[steam].alertPVP = false
			end
		else
			if players[steam].alertPVP == false then
				players[steam].alertPVP = true
			end
		end

		if players[steam].newPlayer then
			setGroupMembership(steam, "New Players", true)
		else
			setGroupMembership(steam, "New Players", false)
		end

		if not server.optOutGlobalBots then
			CheckBlacklist(steam, IP)
		end
	end

	settings = getSettings(steam)

	if igplayers[steam].greet then
		if tonumber(igplayers[steam].greetdelay) > 0 then
			igplayers[steam].greetdelay = igplayers[steam].greetdelay -1
		end
	end

if  debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if tonumber(ping) > 0 then
		igplayers[steam].ping = ping
		players[steam].ping = ping
	else
		igplayers[steam].ping = 0
		players[steam].ping = 0
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if faultyInfo == steam then
		-- Attempt to fix the fault assuming it set some stuff because of it
		if igplayers[steam].yPosLastOK == 0 then
			igplayers[steam].xPosLastOK = intX
			igplayers[steam].yPosLastOK = intY
			igplayers[steam].zPosLastOK = intZ
		end
	end

	playerAccessLevel = accessLevel(steam)

	if isAdmin(steam) then
		-- admins don't hack (no lie) ^^
		players[steam].hackerScore = 0
		admin = true
	else
		admin = false
	end

	if IP ~= "" and players[steam].ip == "" then
		players[steam].ip = IP

		if not server.optOutGlobalBots then
			CheckBlacklist(steam, IP)
		end
	end

if  debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- ping kick
	if not whitelist[steam] and not isDonor(steam) and not admin then
		if (server.pingKickTarget == "new" and players[steam].newPlayer) or server.pingKickTarget == "all" then
			if tonumber(ping) < tonumber(server.pingKick) and tonumber(server.pingKick) > 0 then
				igplayers[steam].highPingCount = tonumber(igplayers[steam].highPingCount) - 1
				if tonumber(igplayers[steam].highPingCount) < 0 then igplayers[steam].highPingCount = 0 end
			end

			if tonumber(ping) > tonumber(server.pingKick) and tonumber(server.pingKick) > 0 then
				igplayers[steam].highPingCount = tonumber(igplayers[steam].highPingCount) + 1

				if tonumber(igplayers[steam].highPingCount) > 15 then
					irc_chat(server.ircMain, "Kicked " .. name .. " steam: " .. steam.. " for high ping " .. ping)
					kick(steam, "High ping kicked.")
					return
				end
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if tonumber(intY) > 0 and tonumber(intY) < 500 then
		igplayers[steam].lastTP = nil
		forgetLastTP(steam)
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if players[steam].location ~= "" and igplayers[steam].spawnedInWorld then --  and igplayers[steam].teleCooldown < 1
		igplayers[steam].teleCooldown = 0

		-- spawn the player at location
		if (locations[players[steam].location]) then
			temp = players[steam].location
			irc_chat(server.ircMain, "Player " .. steam .. " " .. name .. " is being moved to " .. temp)
			irc_chat(server.ircAlerts, "Player " .. steam .. " " .. name .. " is being moved to " .. temp)
			players[steam].location = ""
			if botman.dbConnected then conn:execute("UPDATE players SET location = '' WHERE steam = " .. steam) end

			message(string.format("pm %s [%s]You are being moved to %s[-]", steam, server.chatColour, temp))
			randomTP(steam, temp, true)
		end

		if (players[steam].location == "return player") then
			if players[steam].xPosTimeout ~= 0 and players[steam].zPosTimeout ~= 0 then
				cmd = "tele " .. steam .. " " .. players[steam].xPosTimeout .. " " .. players[steam].yPosTimeout .. " " .. players[steam].zPosTimeout
				players[steam].xPosTimeout = 0
				players[steam].yPosTimeout = 0
				players[steam].zPosTimeout = 0
			else
				cmd = "tele " .. steam .. " " .. players[steam].xPosOld .. " " .. players[steam].yPosOld .. " " .. players[steam].zPosOld
			end

			players[steam].location = ""
			if botman.dbConnected then conn:execute("UPDATE players SET location = '' WHERE steam = " .. steam) end
			teleport(cmd, steam)
		end
	end

	if tonumber(players[steam].hackerScore) >= 10000 then
		players[steam].hackerScore = 0

		if igplayers[steam].hackerDetection ~= nil then
			message(string.format("say [%s]Banning %s. Hacking suspected. Evidence: " .. igplayers[steam].hackerDetection .. "[-]", server.chatColour, players[steam].name))
		else
			message(string.format("say [%s]Banning %s. Detected possible evidence of hacking.[-]", server.chatColour, players[steam].name))
		end

		banPlayer(steam, "1 year", "Automatic ban for suspected hacking. Admins have been alerted.", "")

		-- if the player has any pending global bans, activate them
		connBots:execute("UPDATE bans set GBLBanActive = 1 WHERE GBLBan = 1 AND steam = " .. steam)
	else
		if tonumber(players[steam].hackerScore) >= 49  then
			-- if the player has pending global bans recorded against them, we ban them early and also activate the global ban
			if tonumber(players[steam].pendingBans) > 0 then
				players[steam].hackerScore = 0
				if igplayers[steam].hackerDetection ~= nil then
					message(string.format("say [%s]Temp banning %s. May be hacking. Detected " .. igplayers[steam].hackerDetection .. "[-]", server.chatColour, players[steam].name))
				else
					message(string.format("say [%s]Temp banning %s 1 week. Detected clipping or flying too much. Admins have been alerted.[-]", server.chatColour, players[steam].name))
				end

				banPlayer(steam, "1 week", "Automatic ban for suspected hacking. Admins have been alerted.", "")

				-- activate the pending bans
				connBots:execute("UPDATE bans set GBLBanActive = 1 WHERE GBLBan = 1 AND steam = " .. steam)
			end
		end

		if tonumber(igplayers[steam].flyCount) > 2 and not isAdmin(steam)  then
			players[steam].hackerScore = 0
			if igplayers[steam].hackerDetection ~= nil then
				message(string.format("say [%s]Temp banning %s 1 week for suspected hacking. Detected " .. igplayers[steam].hackerDetection .. "[-]", server.chatColour, players[steam].name))
			else
				message(string.format("say [%s]Temp banning %s 1 week for suspected hacking.[-]", server.chatColour, players[steam].name))
			end

			banPlayer(steam, "1 week", "Automatic ban for suspected hacking. Admins have been alerted.", "")

			-- if the player has any pending global bans, activate them
			if botman.botsConnected then
				connBots:execute("UPDATE bans set GBLBanActive = 1 WHERE GBLBan = 1 AND steam = " .. steam)
			end
		end

		if tonumber(players[steam].hackerScore) >= 60 then
			players[steam].hackerScore = 0
			if igplayers[steam].hackerDetection ~= nil then
				message(string.format("say [%s]Temp banning %s 1 week for suspected hacking. Detected " .. igplayers[steam].hackerDetection .. "[-]", server.chatColour, players[steam].name))
			else
				message(string.format("say [%s]Temp banning %s 1 week for suspected hacking.[-]", server.chatColour, players[steam].name))
			end

			banPlayer(steam, "1 week", "Automatic ban for suspected hacking. Admins have been alerted.", "")

			-- if the player has any pending global bans, activate them
			connBots:execute("UPDATE bans set GBLBanActive = 1 WHERE GBLBan = 1 AND steam = " .. steam)
		end
	end


	-- test for hackers teleporting
	if server.hackerTPDetection and igplayers[steam].spawnChecked == false and not igplayers[steam].spawnPending then
		igplayers[steam].spawnChecked = true

		-- ignore tele spawns for 10 seconds after the last legit tp to allow for lag and extra tp commands on delayed tp servers.
		if (os.time() - igplayers[steam].lastTPTimestamp > 10) and (igplayers[steam].spawnedCoordsOld ~= igplayers[steam].spawnedCoords)then
			if not (players[steam].timeout or players[steam].botTimeout or players[steam].ignorePlayer) then
				if tonumber(intX) ~= 0 and tonumber(intZ) ~= 0 and tonumber(igplayers[steam].xPos) ~= 0 and tonumber(igplayers[steam].zPos) ~= 0 then
					dist = 0

					if igplayers[steam].spawnedInWorld and igplayers[steam].spawnedReason == "teleport" and igplayers[steam].spawnedCoordsOld ~= "0 0 0" then
						dist = distancexz(posX, posZ, igplayers[steam].xPos, igplayers[steam].zPos)
					end

					if (dist >= 900) then
						if tonumber(igplayers[steam].tp) < 1 then
							if players[steam].newPlayer == true then
								new = " [FF8C40]NEW player "
							else
								new = " [FF8C40]Player "
							end

							if not admin then
								irc_chat(server.ircMain, botman.serverTime .. " Player " .. id .. " " .. steam .. " name: " .. name .. " detected teleporting to " .. intX .. " " .. intY .. " " .. intZ .. " distance " .. string.format("%-8.2d", dist))
								irc_chat(server.ircAlerts, server.gameDate .. " player " .. id .. " " .. steam .. " name: " .. name .. " detected teleporting to " .. intX .. " " .. intY .. " " .. intZ .. " distance " .. string.format("%-8.2d", dist))

								igplayers[steam].hackerTPScore = tonumber(igplayers[steam].hackerTPScore) + 1
								players[steam].watchPlayer = true
								players[steam].watchPlayerTimer = os.time() + 259200 -- watch for 3 days
								if botman.dbConnected then conn:execute("UPDATE players SET watchPlayer = 1, watchPlayerTimer = " .. os.time() + 259200 .. " WHERE steam = " .. steam) end

								if players[steam].exiled == true or players[steam].newPlayer then
									igplayers[steam].hackerTPScore = tonumber(igplayers[steam].hackerTPScore) + 1
								end

								if igplayers[steam].hackerTPScore > 0 and players[steam].newPlayer and tonumber(players[steam].ping) > 180 then
									if locations[exile] and not players[steam].prisoner then
										players[steam].exiled = true
									else
										igplayers[steam].hackerTPScore = tonumber(igplayers[steam].hackerTPScore) + 1
									end
								end

								if tonumber(igplayers[steam].hackerTPScore) > 1 then
									igplayers[steam].hackerTPScore = 0
									igplayers[steam].tp = 0
									message(string.format("say [%s]Temp banning %s 1 week for unexplained teleporting. An admin will investigate the circumstances.[-]", server.chatColour, players[steam].name))
									banPlayer(steam, "1 week", "We detected unusual teleporting from you and are investigating the circumstances.", "")

									-- if the player has any pending global bans, activate them
									connBots:execute("UPDATE bans set GBLBanActive = 1 WHERE GBLBan = 1 AND steam = " .. steam)
								end

								alertAdmins(id .. " name: " .. name .. " detected teleporting! In fly mode, type " .. server.commandPrefix .. "near " .. id .. " to shadow them.", "warn")
							end
						end

						igplayers[steam].tp = 0
					else
						igplayers[steam].tp = 0
					end
				end
			end
		end

		igplayers[steam].spawnChecked = true
		igplayers[steam].spawnedCoordsOld = igplayers[steam].spawnedCoords
	end

	igplayers[steam].lastLP = os.time()

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	players[steam].id = id
	players[steam].name = name
	players[steam].steamOwner = igplayers[steam].steamOwner
	igplayers[steam].id = id
	igplayers[steam].name = name
	igplayers[steam].steam = steam

	if igplayers[steam].deaths ~= nil then
		if tonumber(igplayers[steam].deaths) < tonumber(deaths) then
			if tonumber(igplayers[steam].yPosLast) > 0 then
				players[steam].deathX = igplayers[steam].xPosLast
				players[steam].deathY = igplayers[steam].yPosLast
				players[steam].deathZ = igplayers[steam].zPosLast

				igplayers[steam].deadX = igplayers[steam].xPosLast
				igplayers[steam].deadY = igplayers[steam].yPosLast
				igplayers[steam].deadZ = igplayers[steam].zPosLast
				igplayers[steam].teleCooldown = 1000

				irc_chat(server.ircMain, "Player " .. steam .. " name: " .. name .. "'s death recorded at " .. igplayers[steam].deadX .. " " .. igplayers[steam].deadY .. " " .. igplayers[steam].deadZ)
				irc_chat(server.ircAlerts, server.gameDate .. " player " .. steam .. " name: " .. name .. "'s death recorded at " .. igplayers[steam].deadX .. " " .. igplayers[steam].deadY .. " " .. igplayers[steam].deadZ)

				message("say [" .. server.chatColour .. "]" .. name .. " has died.[-]")

				r = randSQL(14)
				if (r == 1) then message("say [" .. server.chatColour .. "]" .. name .. " removed themselves from the gene pool.[-]") end
				if (r == 2) then message("say [" .. server.chatColour .. "]LOL!  Didn't run far away enough did you " .. name .. "?[-]") end
				if (r == 3) then message("say [" .. server.chatColour .. "]And the prize for most creative way to end themselves goes to.. " .. name .. "[-]") end
				if (r == 4) then message("say [" .. server.chatColour .. "]" .. name .. " really shouldn't handle explosives.[-]") end
				if (r == 5) then message("say Oh no! " .. name .. " died.  What a shame.[-]") end
				if (r == 6) then message("say [" .. server.chatColour .. "]Great effort there " .. name .. ". I'm awarding " .. score .. " points.[-]") end
				if (r == 7) then message("say [" .. server.chatColour .. "]LOL! REKT[-]") end

				if (r == 8) then
					message("say [" .. server.chatColour .. "]We are gathered here today to remember with sadness the passing of " .. name .. ". Rest in pieces. Amen.[-]")
				end

				if (r == 9) then message("say [" .. server.chatColour .. "]" .. name .. " cut the wrong wire.[-]") end
				if (r == 10) then message("say [" .. server.chatColour .. "]" .. name .. " really showed that explosive who's boss![-]") end
				if (r == 11) then message("say [" .. server.chatColour .. "]" .. name .. " shouldn't play Russian Roulette with a fully loaded gun.[-]") end
				if (r == 12) then message("say [" .. server.chatColour .. "]" .. name .. " added a new stain to the floor.[-]") end
				if (r == 13) then message("say [" .. server.chatColour .. "]ISIS got nothing on " .. name .. "'s suicide bomber skillz.[-]") end
				if (r == 14) then message("say [" .. server.chatColour .. "]" .. name .. " reached a new low with that death. Six feet under.[-]") end

				players[steam].packCooldown = os.time() + settings.packCooldown
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	igplayers[steam].xPosLast = igplayers[steam].xPos
	igplayers[steam].yPosLast = igplayers[steam].yPos
	igplayers[steam].zPosLast = igplayers[steam].zPos
	igplayers[steam].xPos = posX
	igplayers[steam].yPos = posY
	igplayers[steam].zPos = posZ
	igplayers[steam].playerKills = kills
	igplayers[steam].deaths = deaths
	igplayers[steam].zombies = zombies
	igplayers[steam].score = score

	if igplayers[steam].oldLevel == nil then
		igplayers[steam].oldLevel = level
	end

	-- hacker detection
	if tonumber(igplayers[steam].oldLevel) ~= -1 then
		if tonumber(level) - tonumber(igplayers[steam].oldLevel) > 50 and not admin and server.alertLevelHack then
			alertAdmins(id .. " name: " .. name .. " detected possible level hacking!  Old level was " .. igplayers[steam].oldLevel .. " new level is " .. level .. " an increase of " .. tonumber(level) - tonumber(igplayers[steam].oldLevel), "alert")
			irc_chat(server.ircAlerts, server.gameDate .. " " .. steam .. " name: " .. name .. " detected possible level hacking!  Old level was " .. igplayers[steam].oldLevel .. " new level is " .. level .. " an increase of " .. tonumber(level) - tonumber(igplayers[steam].oldLevel))
		end

		if server.checkLevelHack then
			if tonumber(level) - tonumber(igplayers[steam].oldLevel) > 50 and not admin then
				players[steam].hackerScore = 10000
				igplayers[steam].hackerDetection = "Suspected level hack. (" .. level .. ") an increase of " .. tonumber(level) - tonumber(igplayers[steam].oldLevel)
			end
		end
	end

	players[steam].level = level
	igplayers[steam].level = level
	igplayers[steam].oldLevel = level
	igplayers[steam].killTimer = 0 -- to help us detect a player that has disconnected unnoticed
	igplayers[steam].raiding = false
	igplayers[steam].regionX = regionX
	igplayers[steam].regionZ = regionZ
	igplayers[steam].chunkX = chunkX
	igplayers[steam].chunkZ = chunkZ

	if pvpZone(posX, posZ) then
		igplayers[steam].currentLocationPVP = true
	else
		igplayers[steam].currentLocationPVP = false
	end

	if (igplayers[steam].xPosLast == nil) then
		igplayers[steam].xPosLast = posX
		igplayers[steam].yPosLast = posY
		igplayers[steam].zPosLast = posZ
		igplayers[steam].xPosLastOK = intX
		igplayers[steam].yPosLastOK = intY
		igplayers[steam].zPosLastOK = intZ
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	atHome(steam)
	currentLocation = inLocation(intX, intZ)

	if currentLocation ~= false then
		igplayers[steam].currentLocationPVP = locations[currentLocation].pvp
		igplayers[steam].inLocation = currentLocation
		players[steam].inLocation = currentLocation

		resetZone = locations[currentLocation].resetZone

		if locations[currentLocation].killZombies then
			server.scanZombies = true
		end
	else
		players[steam].inLocation = ""
		igplayers[steam].inLocation = ""
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if server.showLocationMessages then
		if igplayers[steam].alertLocation ~= currentLocation and currentLocation ~= false then
			if (locations[currentLocation].public) or admin then
				message(string.format("pm %s [%s]Welcome to %s[-]", steam, server.chatColour, currentLocation))
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if currentLocation == false then
		if server.showLocationMessages then
			if igplayers[steam].alertLocation ~= "" then
				if not locations[igplayers[steam].alertLocation] then
					igplayers[steam].alertLocation = ""
				else
					if locations[igplayers[steam].alertLocation].public or admin then
						message(string.format("pm %s [%s]You have left %s[-]", steam, server.chatColour, igplayers[steam].alertLocation))
					end
				end
			end
		end

		igplayers[steam].alertLocation = ""
	else
		igplayers[steam].alertLocation = currentLocation
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- fix weird cash bug
	if tonumber(players[steam].cash) < 0 then
		players[steam].cash = 0
	end

	-- convert zombie kills to cash
	if (tonumber(igplayers[steam].zombies) > tonumber(players[steam].zombies)) and (math.abs(igplayers[steam].zombies - players[steam].zombies) < 20) then
		if server.allowBank then
			players[steam].cash = tonumber(players[steam].cash) + math.abs(igplayers[steam].zombies - players[steam].zombies) * settings.zombieKillReward

			if (players[steam].watchCash) then
				message(string.format("pm %s [%s]+%s %s $%s in the bank[-]", steam, server.chatColour, math.abs(igplayers[steam].zombies - players[steam].zombies) * settings.zombieKillReward, server.moneyPlural, string.format("%d", players[steam].cash)))
			end
		end

		if igplayers[steam].doge then
			dogePhrase = dogeWOW() .. " " .. dogeWOW() .. " "

			r = randSQL(10)
			if r == 1 then dogePhrase = dogePhrase .. "WOW" end
			if r == 3 then dogePhrase = dogePhrase .. "Excite" end
			if r == 5 then dogePhrase = dogePhrase .. "Amaze" end
			if r == 7 then dogePhrase = dogePhrase .. "OMG" end
			if r == 9 then dogePhrase = dogePhrase .. "Respect" end

			message(string.format("pm %s [%s]" .. dogePhrase .. "[-]", steam, server.chatColour))
		end

		if server.allowBank then
			-- update the lottery prize pool
			server.lottery = server.lottery + (math.abs(igplayers[steam].zombies - players[steam].zombies) * settings.lotteryMultiplier)
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- update player record of zombies
	players[steam].zombies = igplayers[steam].zombies

	if tonumber(players[steam].playerKills) < tonumber(kills) then
		players[steam].playerKills = kills
	end

	if tonumber(players[steam].deaths) < tonumber(deaths) then
		players[steam].deaths = deaths
	end

	if tonumber(players[steam].score) < tonumber(score) then
		players[steam].score = score
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	players[steam].xPos = posX
	players[steam].yPos = posY
	players[steam].zPos = posZ

	mapCenterDistance = distancexz(intX,intZ,0,0)
	outsideMap = squareDistance(intX, intZ, settings.mapSize)

	if (players[steam].alertReset == nil) then
		players[steam].alertReset = true
	end

	if (igplayers[steam].greet) then
		if tonumber(igplayers[steam].greetdelay) == 0 then
			igplayers[steam].greet = false

			if not server.noGreetingMessages then
				if server.welcome ~= nil and server.welcome ~= "" then
					message(string.format("pm %s [%s]%s[-]", steam, server.chatColour, server.welcome))
				else
					message("pm " .. steam .. " [" .. server.chatColour .. "]Welcome to " .. server.serverName .. "!  Type " .. server.commandPrefix .. "info, " .. server.commandPrefix .. "rules or " .. server.commandPrefix .. "help for commands.[-]")
					message(string.format("pm %s [%s]We have a server manager bot called %s[-]", steam, server.chatColour, server.botName))
				end

				if (tonumber(igplayers[steam].zombies) ~= 0) then
					if isDonor(steam) then
						welcome = "pm " .. steam .. " [" .. server.chatColour .. "]Welcome back " .. name .. "! Thanks for supporting us. =D[-]"
					else
						welcome = "pm " .. steam .. " [" .. server.chatColour .. "]Welcome back " .. name .. "![-]"
					end

					if (string.find(botman.serverTime, "02-14", 5, 10)) then welcome = "pm " .. steam .. " [" .. server.chatColour .. "]Happy Valentines Day " .. name .. "! ^^[-]" end

					message(welcome)
				else
					message("pm " .. steam .. " [" .. server.chatColour .. "]Welcome " .. name .. "![-]")
				end

				if (players[steam].timeout == true) then
					message("pm " .. steam .. " [" .. server.warnColour .. "]You are in timeout, not glitched or lagged.  You will stay here until released by an admin.[-]")
				end

				if (botman.scheduledRestart) then
					message("pm " .. steam .. " [" .. server.alertColour .. "]<!>[-][" .. server.warnColour .. "] SERVER WILL REBOOT SHORTLY [-][" .. server.alertColour .. "]<!>[-]")
				end

				if server.MOTD ~= "" then
					if botman.dbConnected then connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]" .. server.MOTD .. "[-]") .. "')") end
				end

				if tonumber(players[steam].removedClaims) > 0 then
					if botman.dbConnected then connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]I am holding " .. players[steam].removedClaims .. " land claim blocks for you. Type " .. server.commandPrefix .. "give claims to receive them.[-]") .. "')") end
				end

				if botman.dbConnected then
					cursor,errorString = connSQL:execute("SELECT count(*) FROM mail WHERE recipient = '" .. steam .. "' AND status = 0")
					rowSQL = cursor:fetch({}, "a")
					rowCount = rowSQL["count(*)"]

					if rowCount > 0 then
						if botman.dbConnected then connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]NEW MAIL HAS ARRIVED!  Type " .. server.commandPrefix .. "read mail to read it now or " .. server.commandPrefix .. "help mail for more options.[-]") .. "')") end
					end
				end

				if players[steam].newPlayer == true and server.rules ~= "" then
					if botman.dbConnected then connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]" .. server.rules .."[-]") .. "')") end
				end

				if server.warnBotReset == true and playerAccessLevel == 0 then
					if botman.dbConnected then
						connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]ALERT!  It appears that the server has been reset.[-]") .. "')")
						connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]To reset me type " .. server.commandPrefix .. "reset bot.[-]") .. "')")
						connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]To dismiss this alert type " .. server.commandPrefix .. "no reset.[-]") .. "')")
					end
				end

				if (not players[steam].santa) and specialDay == "christmas" then
					if botman.dbConnected then connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]HO HO HO! Merry Christmas!  Type " .. server.commandPrefix .. "santa to open your Christmas stocking![-]") .. "')") end
				end
			else
				if (players[steam].timeout == true) then
					message("pm " .. steam .. " [" .. server.warnColour .. "]You are in timeout, not glitched or lagged.  You will stay here until released by an admin.[-]")
				end

				if botman.dbConnected then
					cursor,errorString = connSQL:execute("SELECT count(*) FROM mail WHERE recipient = '" .. steam .. "' AND status = 0")
					rowSQL = cursor:fetch({}, "a")
					rowCount = rowSQL["count(*)"]

					if rowCount > 0 then
						if botman.dbConnected then connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]NEW MAIL HAS ARRIVED!  Type " .. server.commandPrefix .. "read mail to read it now or " .. server.commandPrefix .. "help mail for more options.[-]") .. "')") end
					end
				end

				if (botman.scheduledRestart) then
					message("pm " .. steam .. " [" .. server.alertColour .. "]<!>[-][" .. server.warnColour .. "] SERVER WILL REBOOT SHORTLY [-][" .. server.alertColour .. "]<!>[-]")
				end
			end

			-- run commands from the connectQueue now that the player has spawned and hopefully paying attention to chat
			tempTimer( 3, [[processConnectQueue("]].. steam .. [[")]] )
			-- also check for removed claims
			tempTimer(10, [[CheckClaimsRemoved("]] .. steam .. [[")]] )
		end
	end


	if igplayers[steam].alertLocation == "" and currentLocation ~= false then
		if botman.dbConnected then connSQL:execute("INSERT INTO messageQueue (sender, recipient, message) VALUES (0,'" .. steam .. "','" .. connMEM:escape("[" .. server.chatColour .. "]Welcome to " .. currentLocation .. "[-]") .. "')") end
		igplayers[steam].alertLocation = currentLocation
	end


	if (igplayers[steam].teleCooldown > 0) then
		igplayers[steam].teleCooldown = tonumber(igplayers[steam].teleCooldown) - 1
	end

	igplayers[steam].sessionPlaytime = os.time() - igplayers[steam].sessionStart

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if players[steam].newPlayer == true then
		if (igplayers[steam].sessionPlaytime + players[steam].timeOnServer > (server.newPlayerTimer * 60) or tonumber(level) > tonumber(server.newPlayerMaxLevel)) then
			players[steam].newPlayer = false
			players[steam].watchPlayer = false
			players[steam].watchPlayerTimer = 0

			if botman.dbConnected then conn:execute("UPDATE players SET newPlayer = 0, watchPlayer = 0, watchPlayerTimer = 0 WHERE steam = " .. steam) end

			if string.upper(players[steam].chatColour) == "FFFFFF" then
				setChatColour(steam, players[steam].accessLevel)
			end

			setGroupMembership(steam, "New Players", false)
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- if we are following a player and they move more than 50 meters away, teleport us close to them.
	if igplayers[steam].following ~= nil then
		if igplayers[igplayers[steam].following] and players[igplayers[steam].following].timeout == false and players[igplayers[steam].following].botTimeout == false then
			followDistance = 50
			if igplayers[steam].followDistance ~= nil then followDistance = tonumber(igplayers[steam].followDistance) end

			dist = distancexz(igplayers[steam].xPos, igplayers[steam].zPos, igplayers[igplayers[steam].following].xPos, igplayers[igplayers[steam].following].zPos)
			if dist > followDistance and igplayers[igplayers[steam].following].yPos > 0 then
				-- teleport close to the player
				igplayers[steam].tp = 1
				igplayers[steam].hackerTPScore = 0
				sendCommand("tele " .. steam .. " " .. igplayers[igplayers[steam].following].xPos .. " " .. igplayers[igplayers[steam].following].yPos - 30 .. " " .. igplayers[igplayers[steam].following].zPos)
			end
		end
	end


	if (igplayers[steam].alertLocationExit ~= nil) then
		dist = distancexz(igplayers[steam].xPos, igplayers[steam].zPos, locations[igplayers[steam].alertLocationExit].x, locations[igplayers[steam].alertLocationExit].z)
		size = tonumber(locations[igplayers[steam].alertLocationExit].size)

		if (dist > tonumber(locations[igplayers[steam].alertLocationExit].size) + 100) then
			igplayers[steam].alertLocationExit = nil

			message("pm " .. steam .. " [" .. server.chatColour .. "]You have moved too far away from the location. If you still wish to do " .. server.commandPrefix .. "protect location, please start again.[-]")
			faultyPlayerinfo = false
			return
		end

		if (dist > tonumber(locations[igplayers[steam].alertLocationExit].size) + 10) and (dist <  tonumber(locations[igplayers[steam].alertLocationExit].size) + 30) then
			locations[igplayers[steam].alertLocationExit].exitX = intX
			locations[igplayers[steam].alertLocationExit].exitY = intY
			locations[igplayers[steam].alertLocationExit].exitZ = intZ
			locations[igplayers[steam].alertLocationExit].protected = true

			if botman.dbConnected then conn:execute("UPDATE locations SET exitX = " .. intX .. ", exitY = " .. intY .. ", exitZ = " .. intZ .. ", protected = 1 WHERE name = '" .. escape(igplayers[steam].alertLocationExit) .. "'") end
			message("pm " .. steam .. " [" .. server.chatColour .. "]You have enabled protection for " .. igplayers[steam].alertLocationExit .. ".[-]")

			igplayers[steam].alertLocationExit = nil

			faultyPlayerinfo = false
			return
		end
	end


	if (igplayers[steam].alertVillageExit ~= nil) then
		dist = distancexz(igplayers[steam].xPos, igplayers[steam].zPos, locations[igplayers[steam].alertVillageExit].x, locations[igplayers[steam].alertVillageExit].z)
		size = tonumber(locations[igplayers[steam].alertVillageExit].size)

		if (dist > tonumber(locations[igplayers[steam].alertVillageExit].size) + 100) then
			igplayers[steam].alertVillageExit = nil

			message("pm " .. steam .. " [" .. server.chatColour .. "]You have moved too far away from " .. igplayers[steam].alertVillageExit .. ". Return to " .. igplayers[steam].alertVillageExit .. " and type " .. server.commandPrefix .. "protect village " .. igplayers[steam].alertVillageExit .. " again.[-]")
			faultyPlayerinfo = false
			return
		end

		if (dist >  tonumber(locations[igplayers[steam].alertVillageExit].size) + 20) and (dist <  tonumber(locations[igplayers[steam].alertVillageExit].size) + 100) then
			locations[igplayers[steam].alertVillageExit].exitX = intX
			locations[igplayers[steam].alertVillageExit].exitY = intY
			locations[igplayers[steam].alertVillageExit].exitZ = intZ
			locations[igplayers[steam].alertVillageExit].protected = true

			if botman.dbConnected then conn:execute("UPDATE locations SET exitX = " .. intX .. ", exitY = " .. intY .. ", exitZ = " .. intZ .. ", protected = 1 WHERE name = '" .. escape(igplayers[steam].alertVillageExit) .. "'") end
			message("pm " .. steam .. " [" .. server.chatColour .. "]You have enabled protection for " .. igplayers[steam].alertVillageExit .. "[-]")

			igplayers[steam].alertVillageExit = nil

			faultyPlayerinfo = false
			return
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if (igplayers[steam].alertBaseExit) then
		tmp.key = igplayers[steam].alertBaseKey
		tmp.dist = distancexz(intX, intZ, bases[tmp.key].x, bases[tmp.key].z)
		tmp.size = tonumber(bases[tmp.key].size)

		if (tmp.dist > 200) then
			igplayers[steam].alertBaseExit = nil
			igplayers[steam].alertBaseKey = nil

			message("pm " .. steam .. " [" .. server.chatColour .. "]You have moved too far away from the base. If you still wish to do " .. server.commandPrefix .. "protect, please start again.[-]")
			faultyPlayerinfo = false
			return
		end

		if (tmp.dist > tmp.size + 15) and (tmp.dist < tmp.size + 50) then
			bases[tmp.key].exitX = intX
			bases[tmp.key].exitY = intY + 1
			bases[tmp.key].exitZ = intZ
			bases[tmp.key].protect = true
			if botman.dbConnected then conn:execute("UPDATE bases SET protect = 1 WHERE steam = " .. bases[tmp.key].steam .. " and baseNumber = " .. bases[tmp.key].baseNumber) end

			if (admin and steam ~= bases[tmp.key].steam) then
				message("pm " .. steam .. " [" .. server.chatColour .. "]You have set an exit teleport for " .. players[bases[tmp.key].steam].name .. "'s base.[-]")
			else
				message("pm " .. steam .. " [" .. server.chatColour .. "]You have set an exit teleport for your base.  You can test it with " .. server.commandPrefix .. "test base.[-]")
			end

			igplayers[steam].alertBaseExit = nil
			igplayers[steam].alertBaseKey = nil

			faultyPlayerinfo = false
			return
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	x = math.floor(igplayers[steam].xPos / 512)
	z = math.floor(igplayers[steam].zPos / 512)

	if admin and server.enableRegionPM then
		if (igplayers[steam].region ~= "r." .. x .. "." .. z .. ".7rg") then
			message("pm " .. steam .. " [" .. server.chatColour .. "]Region " .. x .. "." .. z .. "[-]")
		end
	end

	igplayers[steam].region = region
	igplayers[steam].regionX = x
	igplayers[steam].regionZ = z

	-- timeout
	if (players[steam].timeout == true or players[steam].botTimeout == true) and igplayers[steam].spawnedInWorld then
		if (intY < 30000) then
			igplayers[steam].tp = 1
			igplayers[steam].hackerTPScore = 0
			sendCommand("tele " .. steam .. " " .. intX .. " " .. 60000 .. " " .. intZ)
		end

		faultyPlayerinfo = false
		return
	end

	-- emergency return from timeout
	if (not players[steam].timeout and not  players[steam].botTimeout) and intY > 1000 and not admin then
		igplayers[steam].tp = 1
		igplayers[steam].hackerTPScore = 0

		if players[steam].yPosTimeout == 0 then
			sendCommand("tele " .. steam .. " " .. intX .. " -1 " .. intZ)
		else
			sendCommand("tele " .. steam .. " " .. players[steam].xPosTimeout .. " " .. players[steam].yPosTimeout .. " " .. players[steam].zPosTimeout)
		end

		players[steam].xPosTimeout = 0
		players[steam].yPosTimeout = 0
		players[steam].zPosTimeout = 0

		faultyPlayerinfo = false
		return
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- add to tracker table
	dist = distancexyz(intX, intY, intZ, igplayers[steam].xPosLast, igplayers[steam].yPosLast, igplayers[steam].zPosLast)

	if (dist > 2) and tonumber(intY) < 10000 then
		-- record the players position
		if igplayers[steam].raiding then
			flag = flag .. "R"
		end

		if igplayers[steam].illegalInventory then
			flag = flag .. "B"
		end

		if igplayers[steam].flying or igplayers[steam].noclip then
			flag = flag .. "F"
		end

		--if tonumber(botman.trackingTicker) == 3 then
			connTRAK:execute("INSERT INTO tracker (steam, timestamp, x, y, z, session, flag) VALUES (" .. steam .. "," .. botman.serverTimeStamp .. "," .. intX .. "," .. intY .. "," .. intZ .. "," .. players[steam].sessionCount .. ",'" .. flag .. "')")
		--end

		if igplayers[steam].location ~= nil then
			connSQL:execute("INSERT INTO locationSpawns (location, x, y, z) VALUES ('" .. igplayers[steam].location .. "'," .. intX .. "," .. intY .. "," .. intZ .. ")")
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- prevent player exceeding the map limit unless they are an admin except when ignoreadmins is false
	if not isDestinationAllowed(steam, intX, intZ) then
		message("pm " .. steam .. " [" .. server.warnColour .. "]This map is restricted to " .. (settings.mapSize / 1000) .. " km from the center.[-]")

		igplayers[steam].tp = 1
		igplayers[steam].hackerTPScore = 0

		if not isDestinationAllowed(steam, igplayers[steam].xPosLastOK, igplayers[steam].zPosLastOK) then
			sendCommand("tele " .. steam .. " 1 -1 0") -- if we don't know where to send the player, send them to the middle of the map. This should only happen rarely.
			message("pm " .. steam .. " [" .. server.warnColour .. "]You have been moved to the center of the map.[-]")
		else
			sendCommand("tele " .. steam .. " " .. igplayers[steam].xPosLastOK .. " " .. igplayers[steam].yPosLastOK .. " " .. igplayers[steam].zPosLastOK)
		end

		faultyPlayerinfo = false
		return
	end

	if players[steam].exiled == true and locations[exile] and not players[steam].prisoner then
		if (distancexz( intX, intZ, locations[exile].x, locations[exile].z ) > tonumber(locations[exile].size)) then
			randomTP(steam, exile, true)
			faultyPlayerinfo = false
			return
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- left prison zone warning
	if (locations[prison]) then
		if (distancexz( intX, intZ, locations[prison].x, locations[prison].z ) > tonumber(locations[prison].size)) then
			if (players[steam].alertPrison == false) then
				players[steam].alertPrison = true
			end
		end

		if (players[steam].prisoner) then
			if (locations[prison]) then
				if (squareDistanceXZXZ(locations[prison].x, locations[prison].z, intX, intZ, locations[prison].size)) then
					players[steam].alertPrison = false
					randomTP(steam, prison, true)
				end
			end

			faultyPlayerinfo = false
			return
		end

		-- entered prison zone warning
		if (distancexz( intX, intZ, locations[prison].x, locations[prison].z ) < tonumber(locations[prison].size)) then
			if (players[steam].alertPrison == true) then
				if (not players[steam].prisoner) and server.showLocationMessages then
					message("pm " .. steam .. " [" .. server.warnColour .. "]You have entered the prison.  Continue at your own risk.[-]")
				end
				players[steam].alertPrison = false
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- freeze!
	if (players[steam].freeze == true) then
		dist = distancexz(posX, posZ, players[steam].prisonxPosOld, players[steam].prisonzPosOld)

		if dist > 2 then
			igplayers[steam].tp = 1
			igplayers[steam].hackerTPScore = 0
			sendCommand("tele " .. steam .. " " .. players[steam].prisonxPosOld .. " " .. players[steam].prisonyPosOld .. " " .. players[steam].prisonzPosOld)
		end

		faultyPlayerinfo = false
		return
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- remove player from location if the location is closed or their level is outside level restrictions
	if currentLocation ~= false then
		tmp = {}
		tmp.bootPlayer = false

		if not locations[currentLocation].open and not admin then
			tmp.bootPlayer = true
		end

		-- check player level restrictions on the location
		if (tonumber(locations[currentLocation].minimumLevel) > 0 or tonumber(locations[currentLocation].maximumLevel) > 0) and not admin then
			if tonumber(locations[currentLocation].minimumLevel) > 0 and level < tonumber(locations[currentLocation].minimumLevel) then
				tmp.bootPlayer = true
			end

			if tonumber(locations[currentLocation].minimumLevel) > 0 and tonumber(locations[currentLocation].maximumLevel) > 0 and (level < tonumber(locations[currentLocation].minimumLevel) or level > tonumber(locations[currentLocation].maximumLevel)) then
				tmp.bootPlayer = true
			end

			if tonumber(locations[currentLocation].maximumLevel) > 0 and level > tonumber(locations[currentLocation].maximumLevel) then
				tmp.bootPlayer = true
			end
		end

		-- check player access level restrictions on the location
		if playerAccessLevel > tonumber(locations[currentLocation].playerAccessLevel) and not admin then
			tmp.bootPlayer = true
		end

		if tmp.bootPlayer then
			tmp = {}
			tmp.side = randSQL(4)
			tmp.offset = randSQL(50)

			if tmp.side == 1 then
				tmp.x = locations[currentLocation].x - (locations[currentLocation].size + 20 + tmp.offset)
				tmp.z = locations[currentLocation].z
			end

			if tmp.side == 2 then
				tmp.x = locations[currentLocation].x + (locations[currentLocation].size + 20 + tmp.offset)
				tmp.z = locations[currentLocation].z
			end

			if tmp.side == 3 then
				tmp.x = locations[currentLocation].x
				tmp.z = locations[currentLocation].z - (locations[currentLocation].size + 20 + tmp.offset)
			end

			if tmp.side == 4 then
				tmp.x = locations[currentLocation].x
				tmp.z = locations[currentLocation].z + (locations[currentLocation].size + 20 + tmp.offset)
			end

			tmp.cmd = "tele " .. steam .. " " .. tmp.x .. " -1 " .. tmp.z
			teleport(tmp.cmd, steam)
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- teleport lookup
	if (igplayers[steam].teleCooldown < 1) and (players[steam].prisoner == false) then
		tp = ""
		tp, match = LookupTeleport(posX, posY, posZ)
		if (tp ~= nil and teleports[tp].active == true) then
			ownerid = LookupOfflinePlayer(teleports[tp].owner)
			if (players[steam].walkies ~= true) then
				if (admin or (teleports[tp].owner == igplayers[steam].steam or teleports[tp].public == true or isFriend(ownerid, steam))) and teleports[tp].active then
					if match == 1 then
						-- check access level restrictions on the teleport
						if (playerAccessLevel >= tonumber(teleports[tp].maximumAccess) and playerAccessLevel <= tonumber(teleports[tp].minimumAccess)) or admin then
							if isDestinationAllowed(steam, teleports[tp].dx, teleports[tp].dz) then
								igplayers[steam].teleCooldown = 4
								cmd = "tele " .. steam .. " " .. teleports[tp].dx .. " " .. teleports[tp].dy .. " " .. teleports[tp].dz
								teleport(cmd, steam)

								faultyPlayerinfo = false
								return
							end
						end
					end

					if match == 2 and teleports[tp].oneway == false then
						-- check access level restrictions on the teleport
						if (playerAccessLevel >= tonumber(teleports[tp].maximumAccess) and playerAccessLevel <= tonumber(teleports[tp].minimumAccess)) or admin then
							if isDestinationAllowed(steam, teleports[tp].x, teleports[tp].z) then
								igplayers[steam].teleCooldown = 4
								cmd = "tele " .. steam .. " " .. teleports[tp].x .. " " .. teleports[tp].y .. " " .. teleports[tp].z
								teleport(cmd, steam)

								faultyPlayerinfo = false
								return
							end
						end
					end
				end
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- linked waypoint lookup
	if (igplayers[steam].teleCooldown < 1) and (players[steam].prisoner == false) then
		tmp = {}
		tmp.wpid = LookupWaypoint(posX, posY, posZ)

		if tonumber(tmp.wpid) > 0 then
			tmp.linkedID = waypoints[tmp.wpid].linked

			if (waypoints[tmp.wpid].shared and isFriend(waypoints[tmp.wpid].steam, steam) or waypoints[tmp.wpid].steam == steam) and tonumber(tmp.linkedID) > 0 then
				-- reject if not an admin and player teleporting has been disabled
				if settings.allowTeleporting and not server.disableLinkedWaypoints then
					if isDestinationAllowed(steam, waypoints[tmp.linkedID].x, waypoints[tmp.linkedID].z) then
						if players[steam].waypointCooldown < os.time() then
							if not admin then
								if tonumber(settings.waypointCost) > 0 then
									if tonumber(players[steam].cash) >= tonumber(settings.waypointCost) then
										igplayers[steam].teleCooldown = 3
										players[steam].waypointCooldown = os.time() + settings.waypointCooldown
										players[steam].cash = tonumber(players[steam].cash) - settings.waypointCost

										cmd = "tele " .. steam .. " " .. waypoints[tmp.linkedID].x .. " " .. waypoints[tmp.linkedID].y .. " " .. waypoints[tmp.linkedID].z
										teleport(cmd, steam)

										faultyPlayerinfo = false
										return
									end
								else
									igplayers[steam].teleCooldown = 3
									players[steam].waypointCooldown = os.time() + settings.waypointCooldown
									cmd = "tele " .. steam .. " " .. waypoints[tmp.linkedID].x .. " " .. waypoints[tmp.linkedID].y .. " " .. waypoints[tmp.linkedID].z
									teleport(cmd, steam)

									faultyPlayerinfo = false
									return
								end
							else
								igplayers[steam].teleCooldown = 3
								cmd = "tele " .. steam .. " " .. waypoints[tmp.linkedID].x .. " " .. waypoints[tmp.linkedID].y .. " " .. waypoints[tmp.linkedID].z
								teleport(cmd, steam)

								faultyPlayerinfo = false
								return
							end
						end
					end
				else
					if admin then
						igplayers[steam].teleCooldown = 3
						cmd = "tele " .. steam .. " " .. waypoints[tmp.linkedID].x .. " " .. waypoints[tmp.linkedID].y .. " " .. waypoints[tmp.linkedID].z
						teleport(cmd, steam)

						faultyPlayerinfo = false
						return
					end
				end
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- left reset zone warning
	if (not resetZone) then
		if (players[steam].alertReset == false) then
			message("pm " .. steam .. " [" .. server.chatColour .. "]You are out of the reset zone.[-]")
			players[steam].alertReset = true
			faultyPlayerinfo = false
		end
	end


	-- entered reset zone warning
	if (resetZone) then
		if (players[steam].alertReset == true) then
			message("pm " .. steam .. " [" .. server.warnColour .. "]You are in a reset zone. Don't build here.[-]")
			players[steam].alertReset = false
			faultyPlayerinfo = false

			-- check for claims in the reset zone not owned by staff and remove them
			checkRegionClaims(x, z)
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if	baseProtection(steam, posX, posY, posZ) and not resetZone then
		faultyPlayerinfo = false
		return
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if (igplayers[steam].deadX ~= nil) and igplayers[steam].spawnedInWorld and igplayers[steam].spawnedReason ~= "fake reason" then
		dist = math.abs(distancexz(igplayers[steam].deadX, igplayers[steam].deadZ, posX, posZ))
		if (dist > 2) then
			igplayers[steam].deadX = nil
			igplayers[steam].deadY = nil
			igplayers[steam].deadZ = nil

			if players[steam].bed ~= "" then
				if tonumber(players[steam].bedX) ~= 0 and tonumber(players[steam].bedY) ~= 0 and tonumber(players[steam].bedZ) ~= 0 then
					cmd = "tele " .. steam .. " " .. players[steam].bedX .. " " .. players[steam].bedY .. " " .. players[steam].bedZ
					teleport(cmd, steam)
				end
			end
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- hotspot lookup
	hotspot = LookupHotspot(posX, posY, posZ)

	if (hotspot ~= nil) then
		tmp.skipHotspot = false

		if (igplayers[steam].lastHotspot ~= hotspot) then
			for k, v in pairs(lastHotspots[steam]) do
				if v == hotspot then -- don't add or display this hotspot yet.  we've seen it recently
					tmp.skipHotspot = true
				end
			end

			if not tmp.skipHotspot then
				igplayers[steam].lastHotspot = hotspot
				message("pm " .. steam .. " [" .. server.chatColour .. "]" .. hotspots[hotspot].hotspot .. "[-]")

				if (lastHotspots[steam] == nil) then lastHotspots[steam] = {} end
				if (table.maxn(lastHotspots[steam]) > 4) then
					table.remove(lastHotspots[steam], 1)
				end

				table.insert(lastHotspots[steam],  hotspot)
			end
		end
	end


	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if igplayers[steam].rawPosition ~= rawPosition then
		igplayers[steam].afk = os.time() + tonumber(server.idleKickTimer)
		igplayers[steam].rawPosition = rawPosition
	end

	if (igplayers[steam].rawRotation ~= rawRotation) and rawRotation ~= nil then
		igplayers[steam].rawRotation = rawRotation
	end


	if (tonumber(botman.playersOnline) >= tonumber(server.maxPlayers) or server.idleKickAnytime) and not admin and server.idleKick then
		if (igplayers[steam].afk - os.time() < 0) then
			kick(steam, "You were kicked because you idled too long, but you can rejoin at any time.")
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	if igplayers[steam].spawnedInWorld then
		if igplayers[steam].greet then
			if tonumber(igplayers[steam].greetdelay) > 0 then
				-- Player has spawned.  We can greet them now and do other stuff that waits for spawn
				igplayers[steam].greetdelay = 0
			end
		end

		if tonumber(igplayers[steam].teleCooldown) > 100 then
			igplayers[steam].teleCooldown = 3
		end

		if igplayers[steam].doFirstSpawnedTasks then
			igplayers[steam].doFirstSpawnedTasks = nil

			if server.botman then
				if players[steam].mute then
					mutePlayerChat(steam , "true")
				end

				if players[steam].chatColour ~= "" then
					if string.upper(string.sub(players[steam].chatColour, 1, 6)) ~= "FFFFFF" then
						setPlayerColour(steam, stripAllQuotes(players[steam].chatColour))
					else
						setChatColour(steam, players[steam].accessLevel)
					end
				else
					setChatColour(steam, players[steam].accessLevel)
				end

				-- limit ingame chat length to block chat bombs.
				cmd = steam .. ", 300"
				setPlayerChatLimit(cmd)
			end
		end
	end

	if igplayers[steam].currentLocationPVP then
		if players[steam].alertPVP == true then
			message("pm " .. steam .. " [" .. server.alertColour .. "]You have entered a PVP zone!  Players are allowed to kill you![-]")
			players[steam].alertPVP = false
			faultyPlayerinfo = false
		end
	else
		if players[steam].alertPVP == false then
			message("pm " .. steam .. " [" .. server.warnColour .. "]You have entered a PVE zone.  Do not kill other players![-]")
			players[steam].alertPVP = true
			faultyPlayerinfo = false
		end
	end

	if (steam == debugPlayerInfo) and debug then dbug("debug playerinfo line " .. debugger.getinfo(1).currentline, true) end

	-- stuff to do after everything else

	-- record this coord as the last one that the player was allowed to be at.  if their next step is not allowed, they get returned to this one.
	igplayers[steam].xPosLastOK = intX
	igplayers[steam].yPosLastOK = intY
	igplayers[steam].zPosLastOK = intZ

	faultyPlayerinfo = false

	if (steam == debugPlayerInfo) then
		if debug then dbug("end playerinfo", true) end
	end
end


function playerInfoTrigger(line)
	if players[faultyPlayerinfoID] == nil then
		faultyPlayerinfoID = 0
	end

	if botman.botDisabled then
		return
	end

	if server.useAllocsWebAPI then
		return
	end

	if (faultyPlayerinfoID == debugPlayerInfo) or not igplayers[faultyPlayerinfoID] then
		debugPlayerInfo = 0
	end

	if string.find(line, ", health=") then
		if faultyPlayerinfo == true and tonumber(faultyPlayerinfoID) > 0 then
			fixMissingPlayer(faultyPlayerinfoID)

			if igplayers[faultyPlayerinfoID] then
				fixMissingIGPlayer(faultyPlayerinfoID)
			end

			if debug then dbug("debug playerinfo faulty player " .. faultyPlayerinfoID, true) end

			windowMessage(server.windowDebug, "!! Fault detected in playerinfo trigger\n")
			windowMessage(server.windowDebug, faultyPlayerinfoLine .. "\n")
		end

		playersOnlineList[faultyPlayerinfoID] = {}
		playerInfo(faultyPlayerinfoID)
	end
end
