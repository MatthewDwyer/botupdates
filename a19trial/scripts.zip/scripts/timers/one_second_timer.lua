--[[
    Botman - A collection of scripts for managing 7 Days to Die servers
    Copyright (C) 2020  Matthew Dwyer
	           This copyright applies to the Lua source code in this Mudlet profile.
    Email     smegzor@gmail.com
    URL       https://botman.nz
    Source    https://bitbucket.org/mhdwyer/botman
--]]

function OneSecondTimer()
	if botman.serverTimeSync then
		botman.serverTimeStamp = calculateServerTime(os.time())

		if server.serverStartTimestamp then
			server.uptime = os.time() - server.serverStartTimestamp
		end
	end
end