--[[
    Botman - A collection of scripts for managing 7 Days to Die servers
    Copyright (C) 2020  Matthew Dwyer
	           This copyright applies to the Lua source code in this Mudlet profile.
    Email     smegzor@gmail.com
    URL       https://botman.nz
    Source    https://bitbucket.org/mhdwyer/botman
--]]

function FiveSecondTimer()
	-- this is just here to catch and fix a possible fault
	botman.registerHelp = nil

	if telnetLogFileName then
		-- force writes to the telnet log to save to disk
		telnetLogFile:flush()
	end

	if botman and server then
		if tonumber(botman.playersOnline) > 0 then
			for k,v in pairs(igplayers) do
				if v.protectTest then
					if v.protectTestEnd - os.time() < 0 then
						v.protectTest = nil
					end
				end
			end

			if server.botman and tonumber(botman.playersOnline) > 0 then
				if server.scanNoclip then
					sendCommand("bm-playerunderground")
				end

				if not server.playersCanFly then
					sendCommand("bm-playergrounddistance")
				end
			end
		end
	end
end
