--[[
    Botman - A collection of scripts for managing 7 Days to Die servers
    Copyright (C) 2024  Matthew Dwyer
	           This copyright applies to the Lua source code in this Mudlet profile.
    Email     smegzor@gmail.com
    URL       https://botman.nz
    Source    https://bitbucket.org/mhdwyer/botman
--]]


function baseProtection(steam, posX, posY, posZ)
	local userID

	calledFunction = "baseProtection"

	if server.disableBaseProtection then
		return
	end

	local k, v, testMode, dist, size, alert, cmd, msg

	testMode = false
	players[steam].inABase = false
	userID = players[steam].userID

	-- check for and record any non-friend who gets within protectSize meters of a players /setbase coord
	for k, v in pairs(bases) do
		if (math.abs(tonumber(v.x)) > 100 or math.abs(tonumber(v.z)) > 100) then
			dist = distancexz(posX, posZ, v.x, v.z)
			size = tonumber(v.size)

			if (dist < size) then
				players[steam].inABase = true
			end

			if (v.steam == steam and players[v.steam].protectPaused) then
				if (dist > 100) then
					players[v.steam].protectPaused = nil
					message("pm " .. userID .. " [" .. server.chatColour .. "]Your base protection has re-activated.[-]")
				end
			end

			if igplayers[steam].protectTest then
				testMode = true
			end

			if (v.steam ~= steam or testMode) and (v.size ~= nil) and not igplayers[steam].inVehicle then
				if isFriend(v.steam, steam) == false or testMode or v.keepOut then
					if (dist < size) then
						if (not isAdmin(steam, userID)) or (not botman.ignoreAdmins) or testMode then
							if (players[steam].watchPlayer == true) then
								alert = false

								if (players[steam].lastBaseRaid == nil) then
									players[steam].lastBaseRaid = os.time()
									alert = true
									-- spam prevention
									igplayers[steam].xPosLastAlert = 0
									igplayers[steam].yPosLastAlert = 0
									igplayers[steam].zPosLastAlert = 0
								end

								if (os.time() - tonumber(players[steam].lastBaseRaid) > 15) and ((posX ~= igplayers[steam].xPosLastAlert) or (posY ~= igplayers[steam].yPosLastAlert) or (posZ ~= igplayers[steam].zPosLastAlert)) then
									alert = true
								end

								if (alert == true) then
									-- spam prevention
									igplayers[steam].xPosLastAlert = posX
									igplayers[steam].yPosLastAlert = posY
									igplayers[steam].zPosLastAlert = posZ

									if (dist < 20) then
										if v.title ~= "" then
											msg = "Watched player " .. players[steam].id .. " " .. players[steam].name .. " is " .. string.format("%-8.2d", dist) .. " meters from " .. players[v.steam].name .. "'s base " .. v.baseNumber .. " called " .. v.title
										else
											msg = "Watched player " .. players[steam].id .. " " .. players[steam].name .. " is " .. string.format("%-8.2d", dist) .. " meters from " .. players[v.steam].name .. "'s base " .. v.baseNumber
										end

										if not server.disableWatchAlerts then
											alertAdmins(msg)
										end

										irc_chat(server.ircAlerts, server.gameDate .. " " .. msg)
									end

									players[steam].lastBaseRaid = os.time()
								end
							end

							igplayers[steam].raiding = true
							igplayers[steam].raidingBase = k

							-- do the base protection magic
							if (v.protect == true and not players[v.steam].protectPaused) then
								irc_chat(server.ircAlerts, "base protection triggered for base " .. v.baseNumber .. " of " .. players[v.steam].name .. " against " .. players[steam].name .. " " .. steam)

								if (igplayers[v.steam]) and not igplayers[v.steam].currentLocationPVP then
									message("pm " .. players[v.steam].userID .. " [" .. server.chatColour .. "]" .. igplayers[steam].name .. " has been bounced away from your base.[-]")
								end

								if not server.disableWatchAlerts then
									alertAdmins(igplayers[steam].name .. " has been ejected from " .. players[v.steam].name  .."'s base # " .. v.baseNumber)
								end

								dist = distancexz(igplayers[steam].xPosLastOK, igplayers[steam].zPosLastOK, v.x, v.z)

								if dist > size then
									message("pm " .. userID .. " [" .. server.chatColour .. "]You are too close to a protected player base. The base owner needs to add you to their friends list.[-]")
									cmd = "tele " .. userID .. " " .. igplayers[steam].xPosLastOK .. " " .. igplayers[steam].yPosLastOK .. " " .. igplayers[steam].zPosLastOK

									teleport(cmd, steam, userID)
								else
									cmd = "tele " .. userID .. " " .. v.exitX .. " -1 " .. v.exitZ

									teleport(cmd, steam, userID)
									message("pm " .. userID .. " [" .. server.chatColour .. "]You are too close to a protected player base.  The base owner needs to add you to their friends list.[-]")
								end

								return true
							end
						end
					end
				end
			end
		end
	end


	-- location/village protection
	if (not isAdmin(steam, userID)) or (not botman.ignoreAdmins) or testMode and not igplayers[steam].inVehicle then
		for k, v in pairs(locations) do
			if (v.protected and tonumber(v.x) ~= 0 and tonumber(v.y) ~= 0 and tonumber(v.z) ~= 0) then
				if (not LookupVillager(steam, k) ) and steam ~= v.owner then
					dist = distancexz(posX, posZ, v.x, v.z)

					if v.size == nil then
						size = tonumber(server.baseSize)
					else
						size = tonumber(v.size)
					end

					if tonumber(dist) < tonumber(size) then
						igplayers[steam].raiding = true
						dist = distancexz(igplayers[steam].xPosLastOK, igplayers[steam].zPosLastOK, v.x, v.z)

						-- do the base protection magic
						if dist > size then
							if v.village then
								message("pm " .. userID .. " [" .. server.chatColour .. "]You are too close to the protected village called " .. k .. ".[-]")
							else
								message("pm " .. userID .. " [" .. server.chatColour .. "]You are too close to the protected location called " .. k .. ".[-]")
							end

							cmd = "tele " .. userID .. " " .. igplayers[steam].xPosLastOK .. " " .. igplayers[steam].yPosLastOK .. " " .. igplayers[steam].zPosLastOK
							igplayers[steam].lastTP = cmd
							teleport(cmd, steam, userID)
						else
							cmd = "tele " .. userID .. " " .. v.exitX .. " -1 " .. v.exitZ
							igplayers[steam].lastTP = cmd
							teleport(cmd, steam, userID)

							if v.village then
								message("pm " .. userID .. " [" .. server.chatColour .. "]You are too close to the protected village called " .. k .. ".[-]")
							else
								message("pm " .. userID .. " [" .. server.chatColour .. "]You are too close to the protected location called " .. k .. ".[-]")
							end
						end

						return true
					end
				end
			end
		end
	end

end
