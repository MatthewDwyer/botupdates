--[[
	Put code that you are testing in here so you don't need to touch the bot's profile XML file.
	You can output to the bot's lists window with dbug("display some value " .. someValue)
	Or you can out to IRC in the watch channel with dbugi("display some value " .. someValue)

	When you have finished your edits and uploaded trialCode.lua again type /reload code or just say reload code, then you can press the Trial Code button on the right side of Mudlet's screen.
--]]

function trialCode()
	local tmp = {}

end